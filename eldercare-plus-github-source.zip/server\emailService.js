import { Resend } from 'resend';
import dotenv from 'dotenv';
dotenv.config();

const RESEND_API_KEY = process.env.RESEND_API_KEY || '';
const FROM_EMAIL = process.env.RESEND_FROM_EMAIL || 'ElderCare+ <onboarding@resend.dev>';

const resendClient = RESEND_API_KEY ? new Resend(RESEND_API_KEY) : null;

/**
 * Sends an email notification using Resend if configured,
 * otherwise records an accurate 'pending_config' status with clear setup guidance.
 * NEVER fakes successful delivery.
 */
export async function sendNotificationEmail({ to, subject, htmlBody, textBody, category = 'notification' }) {
  const timestamp = new Date().toISOString();

  // If no Resend API key is configured
  if (!RESEND_API_KEY || RESEND_API_KEY.trim() === '' || RESEND_API_KEY.includes('your_resend_api_key_here')) {
    console.log(`[Email Service - Notice] Resend API key is not configured. Email to "${to}" was logged as pending configuration.`);
    return {
      success: false,
      status: 'pending_config',
      recipient: to,
      subject,
      timestamp,
      message: 'Resend API key is not configured. Add RESEND_API_KEY in server/.env to transmit live emails to inboxes.',
      emailId: null,
    };
  }

  try {
    const response = await resendClient.emails.send({
      from: FROM_EMAIL,
      to: Array.isArray(to) ? to : [to],
      subject,
      html: htmlBody,
      text: textBody,
    });

    if (response.error) {
      console.error(`[Email Service - Error] Resend error for "${to}":`, response.error);
      return {
        success: false,
        status: 'failed',
        recipient: to,
        subject,
        timestamp,
        error: response.error.message || 'Unknown Resend error',
        emailId: null,
      };
    }

    console.log(`[Email Service - Success] Email sent to "${to}". Resend ID: ${response.data?.id}`);
    return {
      success: true,
      status: 'delivered',
      recipient: to,
      subject,
      timestamp,
      emailId: response.data?.id,
    };
  } catch (err) {
    console.error(`[Email Service - Exception] Error sending to "${to}":`, err.message);
    return {
      success: false,
      status: 'failed',
      recipient: to,
      subject,
      timestamp,
      error: err.message,
      emailId: null,
    };
  }
}

/**
 * HTML Email Template Generator with ElderCare+ calm green branding
 */
export function buildEmailTemplate({ title, subtitle, badgeText, contentHtml, actionButtonText, actionButtonUrl, alertLevel = 'normal' }) {
  const badgeColors = {
    normal: { bg: '#ecfdf5', text: '#047857', border: '#a7f3d0' },
    warning: { bg: '#fffbeb', text: '#b45309', border: '#fde68a' },
    urgent: { bg: '#fef2f2', text: '#b91c1c', border: '#fecaca' },
  }[alertLevel] || { bg: '#ecfdf5', text: '#047857', border: '#a7f3d0' };

  return `
  <!DOCTYPE html>
  <html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${title}</title>
  </head>
  <body style="margin: 0; padding: 0; background-color: #f8fafc; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #1e293b;">
    <table width="100%" cellpadding="0" cellspacing="0" style="padding: 24px 12px; background-color: #f8fafc;">
      <tr>
        <td align="center">
          <table width="600" cellpadding="0" cellspacing="0" style="max-width: 600px; width: 100%; background-color: #ffffff; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05); border: 1px solid #e2e8f0;">
            <!-- Header -->
            <tr>
              <td style="padding: 28px 32px; background: linear-gradient(135deg, #059669 0%, #047857 100%); color: #ffffff;">
                <div style="font-size: 24px; font-weight: 800; letter-spacing: -0.5px; display: flex; align-items: center;">
                  ElderCare+
                </div>
                <div style="font-size: 13px; opacity: 0.9; margin-top: 4px; font-weight: 500;">
                  Healthcare Without Communication or Accessibility Barriers
                </div>
              </td>
            </tr>

            <!-- Body -->
            <tr>
              <td style="padding: 32px;">
                ${badgeText ? `
                <div style="display: inline-block; padding: 4px 12px; border-radius: 9999px; background-color: ${badgeColors.bg}; color: ${badgeColors.text}; border: 1px solid ${badgeColors.border}; font-size: 12px; font-weight: 700; text-transform: uppercase; margin-bottom: 16px;">
                  ${badgeText}
                </div>` : ''}

                <h1 style="font-size: 22px; font-weight: 700; color: #0f172a; margin: 0 0 8px 0;">
                  ${title}
                </h1>
                ${subtitle ? `<p style="font-size: 15px; color: #64748b; margin: 0 0 24px 0;">${subtitle}</p>` : ''}

                <div style="font-size: 15px; line-height: 1.6; color: #334155; margin-bottom: 28px;">
                  ${contentHtml}
                </div>

                ${actionButtonText && actionButtonUrl ? `
                <div style="margin-top: 24px; margin-bottom: 20px;">
                  <a href="${actionButtonUrl}" style="display: inline-block; background-color: #059669; color: #ffffff; text-decoration: none; padding: 14px 28px; border-radius: 8px; font-weight: 600; font-size: 15px;">
                    ${actionButtonText}
                  </a>
                </div>` : ''}

                <hr style="border: 0; border-top: 1px solid #e2e8f0; margin: 28px 0 20px 0;" />

                <p style="font-size: 13px; color: #94a3b8; margin: 0;">
                  This is an automated notification from ElderCare+ for your linked elderly healthcare ecosystem.
                </p>
              </td>
            </tr>

            <!-- Footer -->
            <tr>
              <td style="padding: 20px 32px; background-color: #f1f5f9; text-align: center; font-size: 12px; color: #64748b;">
                ElderCare+ Platform • Keeping elderly individuals at the center of their healthcare decisions.
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
  </body>
  </html>
  `;
}
