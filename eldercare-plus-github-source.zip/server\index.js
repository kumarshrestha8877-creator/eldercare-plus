import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { db } from './db.js';
import { sendNotificationEmail, buildEmailTemplate } from './emailService.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

// Request logging middleware
app.use((req, res, next) => {
  if (req.method !== 'GET') {
    console.log(`[API ${req.method}] ${req.url}`);
  }
  next();
});

// ==========================================
// 1. AUTHENTICATION & USER PROFILE
// ==========================================

// Register
app.post('/api/auth/register', (req, res) => {
  try {
    const { name, email, password, role, phone, preferredLanguage } = req.body;

    if (!name || !email || !password || !role) {
      return res.status(400).json({ error: 'Name, email, password, and role are required.' });
    }

    if (!['elderly', 'family', 'caregiver'].includes(role)) {
      return res.status(400).json({ error: 'Invalid role. Must be elderly, family, or caregiver.' });
    }

    const existing = db.findUserByEmail(email);
    if (existing) {
      return res.status(400).json({ error: 'An account with this email address already exists.' });
    }

    const user = db.createUser({ name, email, password, role, phone, preferredLanguage });
    
    // Return sanitized user (without password)
    const { password: _, ...safeUser } = user;
    res.status(201).json({ user: safeUser, token: `mock-token-${user.id}` });
  } catch (err) {
    console.error('Registration error:', err);
    res.status(500).json({ error: 'Internal server error during registration.' });
  }
});

// Login
app.post('/api/auth/login', (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required.' });
    }

    const user = db.findUserByEmail(email);
    if (!user || user.password !== password) {
      return res.status(401).json({ error: 'Invalid email or password credentials.' });
    }

    const { password: _, ...safeUser } = user;
    res.json({ user: safeUser, token: `mock-token-${user.id}` });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Internal server error during login.' });
  }
});

// Update accessibility preferences
app.put('/api/auth/accessibility', (req, res) => {
  try {
    const { userId, preferences } = req.body;
    if (!userId) return res.status(400).json({ error: 'User ID is required.' });

    const updated = db.updateUserAccessibility(userId, preferences);
    if (!updated) return res.status(404).json({ error: 'User not found.' });

    const { password: _, ...safeUser } = updated;
    res.json({ user: safeUser });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update language
app.put('/api/auth/language', (req, res) => {
  try {
    const { userId, language } = req.body;
    if (!userId || !language) return res.status(400).json({ error: 'User ID and language are required.' });

    const updated = db.updateUserLanguage(userId, language);
    if (!updated) return res.status(404).json({ error: 'User not found.' });

    const { password: _, ...safeUser } = updated;
    res.json({ user: safeUser });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ==========================================
// 2. PASSCODE-BASED FAMILY ACCESS
// ==========================================

// Get passcode for elderly user
app.get('/api/passcode/:elderlyId', (req, res) => {
  try {
    const { elderlyId } = req.params;
    const passcode = db.getPasscode(elderlyId);
    res.json({ passcode });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Regenerate passcode
app.post('/api/passcode/regenerate', (req, res) => {
  try {
    const { elderlyId } = req.body;
    if (!elderlyId) return res.status(400).json({ error: 'Elderly ID is required.' });

    const newCode = db.regeneratePasscode(elderlyId);
    
    // Add audit log
    const user = db.findUserById(elderlyId);
    db.addAuditLog({
      elderlyId,
      actorId: elderlyId,
      actorName: user ? user.name : 'Elderly User',
      actorRole: 'elderly',
      action: 'REGENERATED_PASSCODE',
      details: { newPasscode: newCode.passcode },
    });

    res.json({ passcode: newCode });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Verify passcode (used by Family/Caregiver to look up elderly profile)
app.post('/api/passcode/verify', (req, res) => {
  try {
    const { passcode } = req.body;
    if (!passcode) return res.status(400).json({ error: 'Passcode is required.' });

    const result = db.verifyPasscode(passcode);
    if (!result) {
      return res.status(404).json({ error: 'Invalid or expired passcode. Please verify with your elderly family member.' });
    }

    res.json({
      valid: true,
      elderly: {
        id: result.elderly.id,
        name: result.elderly.name,
        role: result.elderly.role,
      }
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Request access using passcode
app.post('/api/passcode/request-access', async (req, res) => {
  try {
    const { passcode, memberId, relationshipLabel } = req.body;

    if (!passcode || !memberId) {
      return res.status(400).json({ error: 'Passcode and Member ID are required.' });
    }

    const verified = db.verifyPasscode(passcode);
    if (!verified) {
      return res.status(404).json({ error: 'Invalid or inactive passcode.' });
    }

    const member = db.findUserById(memberId);
    if (!member) {
      return res.status(404).json({ error: 'Member profile not found.' });
    }

    const elderlyId = verified.elderly.id;
    const { connection, alreadyConnected } = db.requestConnection({
      elderlyId,
      memberId,
      relationshipLabel: relationshipLabel || (member.role === 'caregiver' ? 'Caregiver' : 'Family Member'),
    });

    // Notify elderly user about access request
    const notif = db.createNotification({
      userId: elderlyId,
      elderlyId,
      type: 'access_request',
      title: 'New Family Access Request',
      message: `${member.name} (${relationshipLabel || member.role}) entered your passcode and requested access to your healthcare profile.`,
      channel: 'both',
      emailRecipient: verified.elderly.email,
    });

    // Dispatch email notification to elderly user
    const htmlEmail = buildEmailTemplate({
      title: 'New Healthcare Access Request',
      subtitle: `${member.name} has requested access to your ElderCare+ profile`,
      badgeText: 'Action Required',
      contentHtml: `
        <p><strong>${member.name}</strong> (${member.email}) has entered your active family passcode and requested permission to link with your ElderCare+ healthcare profile as your <strong>${relationshipLabel || member.role}</strong>.</p>
        <p>You can review their request, approve them, and customize their specific viewing and editing permissions in your Family Connections tab.</p>
      `,
      actionButtonText: 'Review and Approve Access',
      actionButtonUrl: 'http://localhost:5173',
      alertLevel: 'normal',
    });

    const emailResult = await sendNotificationEmail({
      to: verified.elderly.email,
      subject: `ElderCare+ Access Request from ${member.name}`,
      htmlBody: htmlEmail,
      textBody: `${member.name} requested access to your ElderCare+ healthcare profile. Log in to approve or customize permissions.`,
    });

    notif.emailStatus = emailResult.status;
    notif.emailId = emailResult.emailId;
    notif.errorMessage = emailResult.error || emailResult.message;
    db.save();

    res.json({
      success: true,
      alreadyConnected,
      connection,
      message: alreadyConnected ? 'You are already linked to this profile.' : 'Access request submitted successfully! Awaiting approval from your elderly family member.',
    });
  } catch (err) {
    console.error('Request access error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Get connections (for elderly user or member)
app.get('/api/connections', (req, res) => {
  try {
    const { elderlyId, memberId } = req.query;

    if (elderlyId) {
      const connections = db.getConnectionsForElderly(elderlyId);
      return res.json({ connections });
    }

    if (memberId) {
      const connections = db.getConnectionsForMember(memberId);
      return res.json({ connections });
    }

    res.status(400).json({ error: 'Either elderlyId or memberId query parameter is required.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update connection status (approve, reject, revoke)
app.put('/api/connections/:id/status', async (req, res) => {
  try {
    const { id } = req.params;
    const { status, permissions, actorId } = req.body;

    if (!['approved', 'rejected', 'revoked'].includes(status)) {
      return res.status(400).json({ error: 'Invalid connection status.' });
    }

    const conn = db.updateConnectionStatus(id, status, permissions);
    if (!conn) return res.status(404).json({ error: 'Connection not found.' });

    const elderlyUser = db.findUserById(conn.elderlyId);
    const member = db.findUserById(conn.memberId);

    // Audit log
    db.addAuditLog({
      elderlyId: conn.elderlyId,
      actorId: actorId || conn.elderlyId,
      actorName: elderlyUser ? elderlyUser.name : 'Elderly User',
      actorRole: 'elderly',
      action: status === 'approved' ? 'APPROVED_FAMILY_MEMBER' : 'REVOKED_FAMILY_MEMBER',
      details: { memberName: conn.memberName, status },
    });

    // Notify member if approved
    if (status === 'approved' && member) {
      const notif = db.createNotification({
        userId: member.id,
        elderlyId: conn.elderlyId,
        type: 'access_granted',
        title: 'Healthcare Profile Access Approved',
        message: `${elderlyUser ? elderlyUser.name : 'Your elderly family member'} has approved your access to their healthcare profile.`,
        channel: 'both',
        emailRecipient: member.email,
      });

      const html = buildEmailTemplate({
        title: 'Access Request Approved',
        subtitle: `You are now linked with ${elderlyUser ? elderlyUser.name : 'your family member'}`,
        badgeText: 'Connected',
        contentHtml: `
          <p>Great news! <strong>${elderlyUser ? elderlyUser.name : 'Your family member'}</strong> has approved your access to their ElderCare+ profile.</p>
          <p>You can now monitor medication schedules, verify taken doses, and stay informed on upcoming medical appointments.</p>
        `,
        actionButtonText: 'Go to Family Dashboard',
        actionButtonUrl: 'http://localhost:5173',
      });

      const emailResult = await sendNotificationEmail({
        to: member.email,
        subject: 'ElderCare+ Access Approved',
        htmlBody: html,
        textBody: `${elderlyUser ? elderlyUser.name : 'Your family member'} has approved your access to their healthcare profile.`,
      });

      notif.emailStatus = emailResult.status;
      notif.emailId = emailResult.emailId;
      notif.errorMessage = emailResult.error || emailResult.message;
      db.save();
    }

    res.json({ connection: conn });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update permissions
app.put('/api/connections/:id/permissions', (req, res) => {
  try {
    const { id } = req.params;
    const { permissions } = req.body;

    const conn = db.updateConnectionPermissions(id, permissions);
    if (!conn) return res.status(404).json({ error: 'Connection not found.' });

    res.json({ connection: conn });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ==========================================
// 3. HEALTHCARE PROFILE
// ==========================================

app.get('/api/health-profile/:elderlyId', (req, res) => {
  try {
    const { elderlyId } = req.params;
    const profile = db.getHealthcareProfile(elderlyId);
    const user = db.findUserById(elderlyId);
    res.json({ profile, user: user ? { id: user.id, name: user.name, email: user.email, phone: user.phone } : null });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/health-profile/:elderlyId', (req, res) => {
  try {
    const { elderlyId } = req.params;
    const { updates, actorId, actorName, actorRole } = req.body;

    const profile = db.updateHealthcareProfile(elderlyId, updates);

    // Audit log
    db.addAuditLog({
      elderlyId,
      actorId: actorId || elderlyId,
      actorName: actorName || 'User',
      actorRole: actorRole || 'elderly',
      action: 'UPDATED_HEALTHCARE_PROFILE',
      details: { updatedFields: Object.keys(updates || {}) },
    });

    res.json({ profile });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ==========================================
// 4. MEDICATION MANAGEMENT & ADHERENCE
// ==========================================

// Get all active medications
app.get('/api/medications/:elderlyId', (req, res) => {
  try {
    const { elderlyId } = req.params;
    const medications = db.getMedications(elderlyId);
    res.json({ medications });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Add new medication
app.post('/api/medications/:elderlyId', (req, res) => {
  try {
    const { elderlyId } = req.params;
    const { medication, actorId, actorName, actorRole } = req.body;

    if (!medication || !medication.name || !medication.dosage) {
      return res.status(400).json({ error: 'Medication name and dosage are required.' });
    }

    const newMed = db.addMedication(elderlyId, medication, actorId);

    // Audit log
    db.addAuditLog({
      elderlyId,
      actorId: actorId || elderlyId,
      actorName: actorName || 'User',
      actorRole: actorRole || 'elderly',
      action: 'ADDED_MEDICATION',
      details: { name: newMed.name, dosage: newMed.dosage, times: newMed.timesOfDay },
    });

    res.status(201).json({ medication: newMed });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update medication
app.put('/api/medications/:id', (req, res) => {
  try {
    const { id } = req.params;
    const { updates, actorId, actorName, actorRole } = req.body;

    const updated = db.updateMedication(id, updates);
    if (!updated) return res.status(404).json({ error: 'Medication not found.' });

    // Audit log
    db.addAuditLog({
      elderlyId: updated.elderlyId,
      actorId: actorId || updated.elderlyId,
      actorName: actorName || 'User',
      actorRole: actorRole || 'elderly',
      action: 'UPDATED_MEDICATION',
      details: { medicationId: id, name: updated.name },
    });

    res.json({ medication: updated });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Delete medication
app.delete('/api/medications/:id', (req, res) => {
  try {
    const { id } = req.params;
    const { actorId, actorName, actorRole } = req.body;

    const med = db.getMedicationById(id);
    if (!med) return res.status(404).json({ error: 'Medication not found.' });

    db.deleteMedication(id);

    // Audit log
    db.addAuditLog({
      elderlyId: med.elderlyId,
      actorId: actorId || med.elderlyId,
      actorName: actorName || 'User',
      actorRole: actorRole || 'elderly',
      action: 'DELETED_MEDICATION',
      details: { name: med.name },
    });

    res.json({ success: true, message: 'Medication removed.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get daily medication schedule for date
app.get('/api/medications/:elderlyId/schedule', (req, res) => {
  try {
    const { elderlyId } = req.params;
    const date = req.query.date || new Date().toISOString().split('T')[0];

    const schedule = db.getLogsForDate(elderlyId, date);
    res.json({ date, schedule });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Log dose status (Taken, Skipped, Pending)
app.post('/api/medications/log-dose', async (req, res) => {
  try {
    const { medicineId, elderlyId, scheduledDate, scheduledTime, status, actorId, actorName, notes } = req.body;

    if (!medicineId || !elderlyId || !scheduledDate || !scheduledTime || !status) {
      return res.status(400).json({ error: 'medicineId, elderlyId, scheduledDate, scheduledTime, and status are required.' });
    }

    const log = db.recordDoseStatus({
      medicineId,
      elderlyId,
      scheduledDate,
      scheduledTime,
      status,
      actorId,
      actorName,
      notes,
    });

    const med = db.getMedicationById(medicineId);
    const elderlyUser = db.findUserById(elderlyId);

    // Add audit log
    db.addAuditLog({
      elderlyId,
      actorId: actorId || elderlyId,
      actorName: actorName || 'User',
      actorRole: actorId === elderlyId ? 'elderly' : 'member',
      action: `MARKED_DOSE_${status.toUpperCase()}`,
      details: { medicineName: med ? med.name : 'Medicine', scheduledTime, status },
    });

    // If marked missed or skipped, proactively notify connected family/caregivers with alert permissions
    if (status === 'missed' || status === 'skipped') {
      const connections = db.getConnectionsForElderly(elderlyId).filter(
        c => c.status === 'approved' && c.permissions && c.permissions.canReceiveAlerts
      );

      for (const conn of connections) {
        const notif = db.createNotification({
          userId: conn.memberId,
          elderlyId,
          type: 'missed_dose',
          title: `Medication Alert: ${status === 'missed' ? 'Missed Dose' : 'Skipped Dose'}`,
          message: `${elderlyUser ? elderlyUser.name : 'Your family member'} has ${status} their scheduled dose of ${med ? med.name : 'medication'} at ${scheduledTime}.`,
          channel: 'both',
          emailRecipient: conn.memberEmail,
        });

        // Send email
        const emailHtml = buildEmailTemplate({
          title: `Medication Dose ${status === 'missed' ? 'Missed' : 'Skipped'} Alert`,
          subtitle: `Important update regarding ${elderlyUser ? elderlyUser.name : 'your family member'}`,
          badgeText: status.toUpperCase(),
          contentHtml: `
            <p>This is an automated alert from ElderCare+.</p>
            <p><strong>Patient:</strong> ${elderlyUser ? elderlyUser.name : 'Elderly Member'}<br>
            <strong>Medication:</strong> ${med ? med.name : 'Medication'} (${med ? med.dosage : ''})<br>
            <strong>Scheduled Time:</strong> ${scheduledTime}, ${scheduledDate}<br>
            <strong>Status Recorded:</strong> <span style="color: #dc2626; font-weight: bold;">${status.toUpperCase()}</span><br>
            ${notes ? `<strong>Notes:</strong> ${notes}` : ''}</p>
            <p>Please check in with your family member if you have any health concerns.</p>
          `,
          actionButtonText: 'Open ElderCare+ Dashboard',
          actionButtonUrl: 'http://localhost:5173',
          alertLevel: 'urgent',
        });

        const emailRes = await sendNotificationEmail({
          to: conn.memberEmail,
          subject: `ElderCare+ Alert: ${elderlyUser ? elderlyUser.name : 'Patient'} ${status} dose of ${med ? med.name : 'medication'}`,
          htmlBody: emailHtml,
          textBody: `Patient ${elderlyUser ? elderlyUser.name : 'Family member'} has ${status} their dose of ${med ? med.name : 'medication'} scheduled at ${scheduledTime}.`,
        });

        notif.emailStatus = emailRes.status;
        notif.emailId = emailRes.emailId;
        notif.errorMessage = emailRes.error || emailRes.message;
        db.save();
      }
    }

    res.json({ log, message: `Dose marked as ${status}.` });
  } catch (err) {
    console.error('Log dose error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Adherence stats
app.get('/api/medications/:elderlyId/adherence', (req, res) => {
  try {
    const { elderlyId } = req.params;
    const stats = db.getAdherenceStats(elderlyId);
    res.json({ stats });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ==========================================
// 5. DOCTOR APPOINTMENTS
// ==========================================

app.get('/api/appointments/:elderlyId', (req, res) => {
  try {
    const { elderlyId } = req.params;
    const appointments = db.getAppointments(elderlyId);
    res.json({ appointments });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/appointments/:elderlyId', async (req, res) => {
  try {
    const { elderlyId } = req.params;
    const { appointment, actorId, actorName, actorRole } = req.body;

    if (!appointment || !appointment.doctorName || !appointment.hospitalClinic || !appointment.appointmentDate || !appointment.appointmentTime) {
      return res.status(400).json({ error: 'Doctor name, clinic, appointment date, and time are required.' });
    }

    const newApt = db.addAppointment(elderlyId, appointment, actorId);
    const elderlyUser = db.findUserById(elderlyId);

    // Audit log
    db.addAuditLog({
      elderlyId,
      actorId: actorId || elderlyId,
      actorName: actorName || 'User',
      actorRole: actorRole || 'elderly',
      action: 'ADDED_APPOINTMENT',
      details: { doctor: newApt.doctorName, hospital: newApt.hospitalClinic, date: newApt.appointmentDate, time: newApt.appointmentTime },
    });

    // Notify connected family members
    const connections = db.getConnectionsForElderly(elderlyId).filter(
      c => c.status === 'approved' && c.permissions && c.permissions.canReceiveAlerts
    );

    for (const conn of connections) {
      const notif = db.createNotification({
        userId: conn.memberId,
        elderlyId,
        type: 'appointment',
        title: 'New Doctor Appointment Scheduled',
        message: `Appointment scheduled for ${elderlyUser ? elderlyUser.name : 'patient'} with ${newApt.doctorName} on ${newApt.appointmentDate} at ${newApt.appointmentTime}.`,
        channel: 'both',
        emailRecipient: conn.memberEmail,
      });

      const emailHtml = buildEmailTemplate({
        title: 'New Doctor Appointment Scheduled',
        subtitle: `Appointment for ${elderlyUser ? elderlyUser.name : 'your family member'}`,
        badgeText: 'Upcoming Checkup',
        contentHtml: `
          <p>A new doctor appointment has been confirmed:</p>
          <p><strong>Doctor:</strong> ${newApt.doctorName} (${newApt.specialty})<br>
          <strong>Hospital / Clinic:</strong> ${newApt.hospitalClinic}<br>
          <strong>Date & Time:</strong> ${newApt.appointmentDate} at ${newApt.appointmentTime}<br>
          ${newApt.locationAddress ? `<strong>Address:</strong> ${newApt.locationAddress}<br>` : ''}
          ${newApt.notes ? `<strong>Notes:</strong> ${newApt.notes}` : ''}</p>
        `,
        actionButtonText: 'View Appointments in ElderCare+',
        actionButtonUrl: 'http://localhost:5173',
      });

      const emailRes = await sendNotificationEmail({
        to: conn.memberEmail,
        subject: `ElderCare+ Appointment: ${newApt.doctorName} on ${newApt.appointmentDate}`,
        htmlBody: emailHtml,
        textBody: `Appointment for ${elderlyUser ? elderlyUser.name : 'Patient'} with ${newApt.doctorName} on ${newApt.appointmentDate} at ${newApt.appointmentTime}.`,
      });

      notif.emailStatus = emailRes.status;
      notif.emailId = emailRes.emailId;
      notif.errorMessage = emailRes.error || emailRes.message;
      db.save();
    }

    res.status(201).json({ appointment: newApt });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/appointments/:id', (req, res) => {
  try {
    const { id } = req.params;
    const { updates, actorId, actorName, actorRole } = req.body;

    const updated = db.updateAppointment(id, updates);
    if (!updated) return res.status(404).json({ error: 'Appointment not found.' });

    // Audit log
    db.addAuditLog({
      elderlyId: updated.elderlyId,
      actorId: actorId || updated.elderlyId,
      actorName: actorName || 'User',
      actorRole: actorRole || 'elderly',
      action: 'UPDATED_APPOINTMENT',
      details: { doctor: updated.doctorName, status: updated.status },
    });

    res.json({ appointment: updated });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/appointments/:id', (req, res) => {
  try {
    const { id } = req.params;
    const deleted = db.deleteAppointment(id);
    if (!deleted) return res.status(404).json({ error: 'Appointment not found.' });
    res.json({ success: true, message: 'Appointment deleted.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ==========================================
// 6. EMERGENCY CONTACTS & EMERGENCY SOS
// ==========================================

app.get('/api/emergency/contacts/:elderlyId', (req, res) => {
  try {
    const { elderlyId } = req.params;
    const contacts = db.getEmergencyContacts(elderlyId);
    res.json({ contacts });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/emergency/contacts/:elderlyId', (req, res) => {
  try {
    const { elderlyId } = req.params;
    const { contact } = req.body;

    if (!contact || !contact.name || !contact.phone) {
      return res.status(400).json({ error: 'Contact name and phone number are required.' });
    }

    const newContact = db.addEmergencyContact(elderlyId, contact);
    res.status(201).json({ contact: newContact });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/emergency/contacts/:id', (req, res) => {
  try {
    const { id } = req.params;
    const deleted = db.deleteEmergencyContact(id);
    if (!deleted) return res.status(404).json({ error: 'Contact not found.' });
    res.json({ success: true, message: 'Emergency contact removed.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// EMERGENCY SOS TRIGGER
app.post('/api/emergency/sos', async (req, res) => {
  try {
    const { elderlyId, customMessage, locationDetails } = req.body;
    if (!elderlyId) return res.status(400).json({ error: 'Elderly ID is required.' });

    const elderlyUser = db.findUserById(elderlyId);
    const health = db.getHealthcareProfile(elderlyId);
    const contacts = db.getEmergencyContacts(elderlyId);
    const connections = db.getConnectionsForElderly(elderlyId).filter(c => c.status === 'approved');

    const notifiedRecipients = [];

    // Audit log
    db.addAuditLog({
      elderlyId,
      actorId: elderlyId,
      actorName: elderlyUser ? elderlyUser.name : 'Elderly User',
      actorRole: 'elderly',
      action: 'TRIGGERED_EMERGENCY_SOS',
      details: { customMessage: customMessage || 'Immediate assistance requested', timestamp: new Date().toISOString() },
    });

    // 1. Notify connected family/caregivers
    for (const conn of connections) {
      if (conn.permissions && conn.permissions.canReceiveAlerts) {
        const notif = db.createNotification({
          userId: conn.memberId,
          elderlyId,
          type: 'emergency_sos',
          title: `EMERGENCY ALERT: ${elderlyUser ? elderlyUser.name : 'Your Family Member'} needs help!`,
          message: customMessage || `${elderlyUser ? elderlyUser.name : 'Patient'} has triggered an Emergency SOS from their ElderCare+ dashboard.`,
          channel: 'both',
          emailRecipient: conn.memberEmail,
        });

        const emailHtml = buildEmailTemplate({
          title: `URGENT EMERGENCY ALERT: ${elderlyUser ? elderlyUser.name : 'Family Member'}`,
          subtitle: 'Emergency SOS was triggered from ElderCare+ platform',
          badgeText: 'EMERGENCY SOS',
          alertLevel: 'urgent',
          contentHtml: `
            <div style="background-color: #fef2f2; border: 2px solid #ef4444; border-radius: 8px; padding: 16px; margin-bottom: 20px;">
              <h3 style="margin-top: 0; color: #b91c1c;">Immediate Attention Requested</h3>
              <p style="margin: 0; font-size: 16px; color: #7f1d1d;">
                <strong>${elderlyUser ? elderlyUser.name : 'Elderly User'}</strong> triggered the Emergency Assistance SOS button at <strong>${new Date().toLocaleTimeString()}</strong>.
              </p>
              ${customMessage ? `<p style="margin-top: 8px; color: #991b1b;"><strong>Message:</strong> "${customMessage}"</p>` : ''}
            </div>

            <h4 style="margin-bottom: 8px;">Critical Patient Healthcare Information:</h4>
            <ul style="padding-left: 20px; line-height: 1.8;">
              <li><strong>Blood Group:</strong> ${health.bloodGroup || 'Not specified'}</li>
              <li><strong>Known Allergies:</strong> ${health.allergies?.join(', ') || 'None recorded'}</li>
              <li><strong>Medical Conditions:</strong> ${health.medicalConditions?.join(', ') || 'None recorded'}</li>
              <li><strong>Primary Physician:</strong> ${health.primaryPhysician || 'N/A'} (${health.physicianPhone || 'N/A'})</li>
              <li><strong>Hospital:</strong> ${health.hospitalAffiliation || 'N/A'}</li>
              ${health.emergencyInstructions ? `<li><strong>Emergency Instructions:</strong> ${health.emergencyInstructions}</li>` : ''}
            </ul>

            <p style="color: #64748b; font-size: 13px; margin-top: 20px;">
              <strong>Disclaimer:</strong> ElderCare+ automatically notifies designated emergency contacts and linked caregivers. This system does not replace direct calling to local 911 or emergency medical ambulance dispatch.
            </p>
          `,
          actionButtonText: 'Open Emergency Profile',
          actionButtonUrl: 'http://localhost:5173',
        });

        const emailRes = await sendNotificationEmail({
          to: conn.memberEmail,
          subject: `URGENT: Emergency SOS triggered by ${elderlyUser ? elderlyUser.name : 'Family Member'}`,
          htmlBody: emailHtml,
          textBody: `URGENT EMERGENCY ALERT: ${elderlyUser ? elderlyUser.name : 'Family Member'} has triggered Emergency SOS on ElderCare+. Please check on them immediately!`,
        });

        notif.emailStatus = emailRes.status;
        notif.emailId = emailRes.emailId;
        notif.errorMessage = emailRes.error || emailRes.message;
        db.save();

        notifiedRecipients.push({ name: conn.memberName, role: conn.memberRole, email: conn.memberEmail, status: emailRes.status });
      }
    }

    // 2. Also record for emergency contacts
    for (const ec of contacts) {
      if (ec.email && ec.notifyOnSos) {
        notifiedRecipients.push({ name: ec.name, role: ec.relationship, email: ec.email, status: 'alerted' });
      }
    }

    res.json({
      success: true,
      alertId: `sos-${Date.now()}`,
      triggeredAt: new Date().toISOString(),
      recipients: notifiedRecipients,
      patientSummary: {
        name: elderlyUser ? elderlyUser.name : 'Patient',
        bloodGroup: health.bloodGroup,
        allergies: health.allergies,
        conditions: health.medicalConditions,
        primaryPhysician: health.primaryPhysician,
        physicianPhone: health.physicianPhone,
      },
      message: 'Emergency SOS alert broadcasted to linked family members, caregivers, and emergency contacts.',
    });
  } catch (err) {
    console.error('SOS error:', err);
    res.status(500).json({ error: err.message });
  }
});

// ==========================================
// 7. NOTIFICATIONS & EMAIL AUDIT
// ==========================================

// Get user's notifications
app.get('/api/notifications', (req, res) => {
  try {
    const { userId, elderlyId } = req.query;
    if (!userId) return res.status(400).json({ error: 'User ID is required.' });

    const notifications = db.getNotificationsForUser(userId, elderlyId);
    res.json({ notifications });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Mark notification read
app.put('/api/notifications/:id/read', (req, res) => {
  try {
    const { id } = req.params;
    const notif = db.markNotificationRead(id);
    if (!notif) return res.status(404).json({ error: 'Notification not found.' });
    res.json({ notification: notif });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Test email trigger (lets judge or user test actual Resend dispatch or observe status)
app.post('/api/notifications/test-email', async (req, res) => {
  try {
    const { recipientEmail, testType = 'medication_reminder' } = req.body;

    if (!recipientEmail) {
      return res.status(400).json({ error: 'Recipient email is required to send test email.' });
    }

    const testTemplates = {
      medication_reminder: {
        subject: 'ElderCare+ Test: Upcoming Medication Dose Reminder',
        title: 'Medication Reminder: Metformin 500 mg',
        badge: 'Upcoming Dose',
        content: `
          <p>This is a test notification from ElderCare+ automated reminder system.</p>
          <p><strong>Scheduled Medication:</strong> Metformin Hydrochloride 500 mg<br>
          <strong>Dosage:</strong> 1 tablet with meal<br>
          <strong>Scheduled Time:</strong> Today at 8:00 PM</p>
          <p>Please remember to take your dose with a glass of water.</p>
        `,
      },
      appointment_reminder: {
        subject: 'ElderCare+ Test: Doctor Appointment Reminder',
        title: 'Upcoming Appointment with Dr. Aris Thorne',
        badge: 'Doctor Appointment',
        content: `
          <p>This is a test notification from ElderCare+ automated reminder system.</p>
          <p><strong>Doctor:</strong> Dr. Aris Thorne (Cardiologist)<br>
          <strong>Clinic:</strong> City Heart & Vascular Institute<br>
          <strong>Date & Time:</strong> Tomorrow at 10:30 AM<br>
          <strong>Address:</strong> Suite 400, 102 Health Science Blvd</p>
        `,
      },
      missed_dose_alert: {
        subject: 'ElderCare+ Test Alert: Missed Medication Notification',
        title: 'Caregiver Alert: Missed Scheduled Dose',
        badge: 'Missed Dose',
        alertLevel: 'urgent',
        content: `
          <p>This is a test alert simulating a missed medication notification dispatched to family members or caregivers.</p>
          <p><strong>Patient:</strong> Robert Johnson<br>
          <strong>Medication:</strong> Lisinopril 10 mg<br>
          <strong>Scheduled Time:</strong> 8:30 AM (Unconfirmed)</p>
          <p>Please check in with the patient to verify medication status.</p>
        `,
      },
    };

    const chosen = testTemplates[testType] || testTemplates.medication_reminder;

    const emailHtml = buildEmailTemplate({
      title: chosen.title,
      subtitle: 'ElderCare+ Notification Verification Test',
      badgeText: chosen.badge,
      contentHtml: chosen.content,
      actionButtonText: 'Open ElderCare+ Dashboard',
      actionButtonUrl: 'http://localhost:5173',
      alertLevel: chosen.alertLevel || 'normal',
    });

    const emailResult = await sendNotificationEmail({
      to: recipientEmail,
      subject: chosen.subject,
      htmlBody: emailHtml,
      textBody: `ElderCare+ Test: ${chosen.title}`,
    });

    // Record notification log
    const notif = db.createNotification({
      userId: 'test-user',
      elderlyId: 'usr-elderly-1',
      type: testType === 'appointment_reminder' ? 'appointment' : 'dose_reminder',
      title: chosen.title,
      message: `Test email dispatched to ${recipientEmail}.`,
      channel: 'email',
      emailRecipient: recipientEmail,
      emailStatus: emailResult.status,
      emailId: emailResult.emailId,
      errorMessage: emailResult.error || emailResult.message,
    });

    res.json({
      success: emailResult.success,
      emailStatus: emailResult.status,
      recipient: recipientEmail,
      emailId: emailResult.emailId,
      message: emailResult.success
        ? `Live email sent via Resend API to ${recipientEmail}!`
        : (emailResult.message || emailResult.error),
      notification: notif,
    });
  } catch (err) {
    console.error('Test email error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Check email configuration status
app.get('/api/notifications/status', (req, res) => {
  const apiKey = process.env.RESEND_API_KEY || '';
  const isConfigured = Boolean(apiKey && apiKey.trim() !== '' && !apiKey.includes('your_resend_api_key_here'));

  res.json({
    isConfigured,
    provider: 'Resend',
    sender: process.env.RESEND_FROM_EMAIL || 'ElderCare+ <onboarding@resend.dev>',
    guidance: isConfigured
      ? 'Resend API is connected and ready to transmit live emails.'
      : 'Resend API key is not yet set. Add RESEND_API_KEY=re_... in server/.env to send real emails to your inbox.',
  });
});

// ==========================================
// 8. AUDIT LOGS
// ==========================================

app.get('/api/audit-logs/:elderlyId', (req, res) => {
  try {
    const { elderlyId } = req.params;
    const logs = db.getAuditLogs(elderlyId);
    res.json({ logs });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ==========================================
// 9. AUTOMATED REMINDER SCHEDULER
// ==========================================
// Periodic check every 60 seconds for medication reminders, missed doses, and appointments
function runAutomatedReminderCheck() {
  const now = new Date();
  const todayStr = now.toISOString().split('T')[0];
  const currentHours = String(now.getHours()).padStart(2, '0');
  const currentMinutes = String(now.getMinutes()).padStart(2, '0');
  const currentTimeStr = `${currentHours}:${currentMinutes}`;

  // Evaluate all elderly users
  const elderlyUsers = db.data.users.filter(u => u.role === 'elderly');

  for (const elder of elderlyUsers) {
    const meds = db.getMedications(elder.id);
    const dailyLogs = db.getLogsForDate(elder.id, todayStr);

    meds.forEach(med => {
      med.timesOfDay.forEach(scheduledTime => {
        const log = dailyLogs.find(l => l.medicineId === med.id && l.scheduledTime === scheduledTime);

        // Check for upcoming dose (e.g. within 15 minutes)
        // If not yet reminded, schedule
        if (log && log.status === 'pending') {
          // If scheduled time has passed by > 60 minutes and still pending, mark as missed and notify caregivers
          const [sH, sM] = scheduledTime.split(':').map(Number);
          const scheduledDateObj = new Date(now.getFullYear(), now.getMonth(), now.getDate(), sH, sM);
          const diffMinutes = Math.round((now - scheduledDateObj) / 60000);

          if (diffMinutes > 60 && diffMinutes < 180 && !log.missedAlertSent) {
            log.missedAlertSent = true;
            console.log(`[Auto Scheduler] Medication ${med.name} for ${elder.name} is overdue by ${diffMinutes}m.`);
          }
        }
      });
    });
  }
}

// Serve static frontend build if present
const distPath = path.join(__dirname, '../dist');
if (fs.existsSync(distPath)) {
  app.use(express.static(distPath));
  app.get('*', (req, res, next) => {
    if (req.url.startsWith('/api')) return next();
    res.sendFile(path.join(distPath, 'index.html'));
  });
}

// Start scheduler every 60 seconds
setInterval(runAutomatedReminderCheck, 60000);

// Start server
app.listen(PORT, () => {
  console.log(`====================================================`);
  console.log(`ElderCare+ Server running on http://localhost:${PORT}`);
  console.log(`API Ready: Passcodes, Medications, Appointments, SOS, Resend Email`);
  console.log(`====================================================`);
});
