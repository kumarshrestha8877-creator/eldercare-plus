import React, { useEffect } from 'react';
import { 
  X, 
  Globe, 
  Type, 
  Sliders, 
  Moon, 
  Volume2, 
  VolumeX, 
  Check, 
  Sparkles, 
  Settings, 
  Lightbulb, 
  Eye, 
  Info,
  ShieldCheck,
  CheckCircle2
} from 'lucide-react';
import { useAccessibility } from '../context/AccessibilityContext';

interface AccessibilityHubModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenSettingsModal: () => void;
  onOpenNightBlindnessModal: () => void;
}

export const AccessibilityHubModal: React.FC<AccessibilityHubModalProps> = ({
  isOpen,
  onClose,
  onOpenSettingsModal,
  onOpenNightBlindnessModal,
}) => {
  const { 
    settings, 
    updateSettings, 
    speak, 
    playChime, 
    t, 
    availableVoices, 
    selectedVoiceName, 
    setSelectedVoiceName 
  } = useAccessibility();

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const currentLang = settings.language;

  const handleLanguageSelect = (lang: 'en' | 'hi' | 'bn') => {
    playChime('click');
    updateSettings({ language: lang });
    if (lang === 'hi') {
      speak('भाषा हिंदी चुनी गई है। एल्डरकेयर+ में आपका स्वागत है।', 'hi-IN');
    } else if (lang === 'bn') {
      speak('ভাষা বাংলা নির্বাচন করা হয়েছে। এল্ডারকেয়ার+ এ আপনাকে স্বাগতম।', 'bn-IN');
    } else {
      speak('Language set to English. Welcome to ElderCare+.', 'en-US');
    }
  };

  const handleFontSizeSelect = (scale: 100 | 125 | 150 | 175) => {
    playChime('click');
    updateSettings({ fontSizeScale: scale });
    speak(`Text size set to ${scale} percent`);
  };

  const handleToggleHighContrast = () => {
    playChime('click');
    const newVal = !settings.highContrast;
    updateSettings({ highContrast: newVal });
    speak(newVal ? 'High contrast mode enabled' : 'High contrast mode disabled');
  };

  const handleToggleNightBlindness = () => {
    playChime('click');
    const newVal = !settings.nightBlindnessMode;
    updateSettings({ nightBlindnessMode: newVal });
    speak(newVal ? 'Night blindness amber mode enabled' : 'Night blindness mode disabled');
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl my-6 border border-slate-200 transition-all max-h-[92vh] flex flex-col justify-between">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-5 border-b border-slate-100 sticky top-0 bg-white z-10">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 rounded-2xl bg-elder-green-100 text-elder-green-800 flex items-center justify-center font-bold">
              <Sliders className="w-6 h-6 text-elder-green-700" />
            </div>
            <div>
              <h2 className="text-2xl font-black text-slate-900">
                Accessibility & Display Hub
              </h2>
              <p className="text-xs text-slate-500 font-medium">
                Personalize language, text sizing, vision contrast, and voice assistance.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 font-extrabold text-xs transition-all shadow-xs cursor-pointer"
            aria-label="Close modal"
            title="Close (ESC)"
          >
            <X className="w-5 h-5 stroke-[2.5]" />
            <span>Close ✕</span>
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="py-5 space-y-6 overflow-y-auto pr-1">
          
          {/* 1. Language Selection */}
          <div className="space-y-2.5">
            <label className="block text-xs font-black uppercase tracking-wider text-slate-600 flex items-center gap-1.5">
              <Globe className="w-4 h-4 text-elder-green-700" />
              <span>Select Language / भाषा चुनें / ভাষা নির্বাচন করুন</span>
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <button
                type="button"
                onClick={() => handleLanguageSelect('en')}
                className={`p-4 rounded-2xl border text-left transition-all ${
                  currentLang === 'en'
                    ? 'border-elder-green-600 bg-elder-green-50 ring-2 ring-elder-green-500/20'
                    : 'border-slate-200 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-extrabold text-sm text-slate-900">English</span>
                  {currentLang === 'en' && <Check className="w-4 h-4 text-elder-green-700" />}
                </div>
                <p className="text-xs text-slate-500">English voice & UI</p>
              </button>

              <button
                type="button"
                onClick={() => handleLanguageSelect('hi')}
                className={`p-4 rounded-2xl border text-left transition-all ${
                  currentLang === 'hi'
                    ? 'border-elder-green-600 bg-elder-green-50 ring-2 ring-elder-green-500/20'
                    : 'border-slate-200 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-extrabold text-sm text-slate-900">हिंदी (Hindi)</span>
                  {currentLang === 'hi' && <Check className="w-4 h-4 text-elder-green-700" />}
                </div>
                <p className="text-xs text-slate-500">हिंदी आवाज़ व अनुवाद</p>
              </button>

              <button
                type="button"
                onClick={() => handleLanguageSelect('bn')}
                className={`p-4 rounded-2xl border text-left transition-all ${
                  currentLang === 'bn'
                    ? 'border-elder-green-600 bg-elder-green-50 ring-2 ring-elder-green-500/20'
                    : 'border-slate-200 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-extrabold text-sm text-slate-900">বাংলা (Bengali)</span>
                  {currentLang === 'bn' && <Check className="w-4 h-4 text-elder-green-700" />}
                </div>
                <p className="text-xs text-slate-500">বাংলা ভয়েস ও অনুবাদ</p>
              </button>
            </div>
          </div>

          {/* 2. Text Sizing */}
          <div className="space-y-2.5">
            <label className="block text-xs font-black uppercase tracking-wider text-slate-600 flex items-center gap-1.5">
              <Type className="w-4 h-4 text-elder-green-700" />
              <span>{t('fontSize')}: {settings.fontSizeScale}%</span>
            </label>
            <div className="grid grid-cols-4 gap-2.5">
              {([100, 125, 150, 175] as const).map((scale) => (
                <button
                  key={scale}
                  type="button"
                  onClick={() => handleFontSizeSelect(scale)}
                  className={`py-3 rounded-xl font-bold text-xs sm:text-sm border transition-all ${
                    settings.fontSizeScale === scale
                      ? 'bg-elder-green-700 text-white border-elder-green-700 shadow-sm'
                      : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                  }`}
                >
                  {scale}%
                </button>
              ))}
            </div>
          </div>

          {/* 3. Vision & Contrast Modes */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            
            {/* High Contrast */}
            <div className="p-4 rounded-2xl border border-slate-200 bg-slate-50/50 flex flex-col justify-between space-y-3">
              <div>
                <h4 className="font-extrabold text-sm text-slate-900 flex items-center gap-1.5">
                  <Sliders className="w-4 h-4 text-elder-blue-700" />
                  <span>{t('lowVisionMode')}</span>
                </h4>
                <p className="text-xs text-slate-500 mt-1">
                  Maximized black & yellow contrast for low-vision clarity.
                </p>
              </div>
              <button
                type="button"
                onClick={handleToggleHighContrast}
                className={`w-full py-2.5 rounded-xl font-bold text-xs transition-all ${
                  settings.highContrast
                    ? 'bg-amber-400 text-black border-2 border-black font-black'
                    : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-300'
                }`}
              >
                {settings.highContrast ? 'Enabled (ON)' : 'Enable High Contrast'}
              </button>
            </div>

            {/* Night Blindness (Nyctalopia) Mode */}
            <div className="p-4 rounded-2xl border border-slate-200 bg-slate-50/50 flex flex-col justify-between space-y-3">
              <div>
                <h4 className="font-extrabold text-sm text-slate-900 flex items-center gap-1.5">
                  <Moon className="w-4 h-4 text-amber-600" />
                  <span>{t('nightBlindnessShort')}</span>
                </h4>
                <p className="text-xs text-slate-500 mt-1">
                  Scotopic amber contrast (&gt;590nm) to eliminate glare at night.
                </p>
              </div>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={handleToggleNightBlindness}
                  className={`flex-1 py-2.5 rounded-xl font-bold text-xs transition-all ${
                    settings.nightBlindnessMode
                      ? 'bg-amber-500 text-black border-2 border-amber-400 font-black'
                      : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-300'
                  }`}
                >
                  {settings.nightBlindnessMode ? 'Active (ON)' : 'Turn On'}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenNightBlindnessModal();
                  }}
                  className="px-3 py-2.5 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-bold"
                  title="Open Bedside Amber Lantern & Night Console"
                >
                  <Lightbulb className="w-4 h-4" />
                </button>
              </div>
            </div>

          </div>

          {/* 4. Audio Sound Effects & Cadence */}
          <div className="p-4 rounded-2xl border border-slate-200 bg-slate-50/50 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-extrabold text-sm text-slate-900 flex items-center gap-1.5">
                  <Volume2 className="w-4 h-4 text-elder-green-700" />
                  <span>Audible Feedback & Chimes</span>
                </h4>
                <p className="text-xs text-slate-500">
                  Plays melodic sound cues when actions succeed or alerts trigger.
                </p>
              </div>

              <button
                type="button"
                onClick={() => {
                  const newVal = !settings.soundEffects;
                  updateSettings({ soundEffects: newVal });
                  if (newVal) playChime('success');
                }}
                className={`px-4 py-2 rounded-xl text-xs font-bold border transition-all ${
                  settings.soundEffects 
                    ? 'bg-elder-green-700 text-white border-elder-green-700' 
                    : 'bg-white text-slate-600 border-slate-300'
                }`}
              >
                {settings.soundEffects ? 'Sound ON' : 'Muted'}
              </button>
            </div>
          </div>

        </div>

        {/* Footer with Settings Shortcut */}
        <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
          <button
            type="button"
            onClick={() => {
              onClose();
              onOpenSettingsModal();
            }}
            className="text-xs font-bold text-slate-600 hover:text-elder-green-800 flex items-center gap-1.5"
          >
            <Settings className="w-4 h-4" />
            <span>Supabase & Resend API Credentials</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            className="px-6 py-2.5 rounded-xl bg-elder-green-700 hover:bg-elder-green-800 text-white font-extrabold text-xs shadow-sm"
          >
            Done
          </button>
        </div>

      </div>
    </div>
  );
};
