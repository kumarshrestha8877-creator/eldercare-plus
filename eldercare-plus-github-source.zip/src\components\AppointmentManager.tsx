import React, { useState } from 'react';
import { 
  Calendar as CalendarIcon, 
  Clock, 
  MapPin, 
  Plus, 
  Mail, 
  Trash2, 
  CheckCircle2, 
  XCircle, 
  Download, 
  FileText, 
  Check, 
  AlertCircle,
  ExternalLink
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useAccessibility } from '../context/AccessibilityContext';
import { DoctorAppointment } from '../types';

export const AppointmentManager: React.FC = () => {
  const { 
    appointments, 
    addAppointment, 
    updateAppointment, 
    deleteAppointment, 
    sendAppointmentReminder,
    currentUser 
  } = useAuth();

  const { playChime, speak } = useAccessibility();

  const [activeTab, setActiveTab] = useState<'upcoming' | 'completed'>('upcoming');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [sendingReminderId, setSendingReminderId] = useState<string | null>(null);
  const [reminderStatusMsg, setReminderStatusMsg] = useState<string | null>(null);

  // Form fields
  const [doctorName, setDoctorName] = useState('');
  const [specialty, setSpecialty] = useState('Cardiologist');
  const [hospitalName, setHospitalName] = useState('');
  const [hospitalAddress, setHospitalAddress] = useState('');
  const [appointmentDate, setAppointmentDate] = useState(
    new Date(Date.now() + 86400000 * 5).toISOString().split('T')[0]
  );
  const [appointmentTime, setAppointmentTime] = useState('10:00 AM');
  const [notes, setNotes] = useState('');

  const resetForm = () => {
    setDoctorName('');
    setSpecialty('Cardiologist');
    setHospitalName('');
    setHospitalAddress('');
    setAppointmentDate(new Date(Date.now() + 86400000 * 5).toISOString().split('T')[0]);
    setAppointmentTime('10:00 AM');
    setNotes('');
  };

  const handleAddAppointment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!doctorName.trim() || !hospitalName.trim()) {
      alert('Please enter doctor name and hospital.');
      return;
    }

    addAppointment({
      elderlyUserId: 'usr-elderly-01',
      doctorName,
      specialty,
      hospitalName,
      hospitalAddress,
      appointmentDate,
      appointmentTime,
      notes,
      status: 'upcoming',
      createdBy: currentUser.fullName,
    });

    speak(`Appointment with ${doctorName} scheduled for ${appointmentDate}`);
    setIsAddModalOpen(false);
    resetForm();
  };

  const handleSendReminder = async (apt: DoctorAppointment) => {
    setSendingReminderId(apt.id);
    setReminderStatusMsg(null);
    try {
      const ok = await sendAppointmentReminder(apt.id);
      if (ok) {
        setReminderStatusMsg(`Automated reminder email successfully sent for Dr. ${apt.doctorName}!`);
        speak(`Reminder email sent for ${apt.doctorName}`);
      } else {
        setReminderStatusMsg(`Reminder triggered. Check Notification History for delivery logs.`);
      }
    } catch (e: any) {
      setReminderStatusMsg(`Email failed: ${e?.message || 'Check credentials'}`);
    } finally {
      setSendingReminderId(null);
    }
  };

  // Download .ics Calendar File for Outlook / Google Calendar
  const downloadIcsFile = (apt: DoctorAppointment) => {
    playChime('click');
    const startIso = `${apt.appointmentDate.replace(/-/g, '')}T090000Z`;
    const endIso = `${apt.appointmentDate.replace(/-/g, '')}T100000Z`;

    const icsContent = `BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//ElderCare Plus//Doctor Appointments//EN
CALSCALE:GREGORIAN
METHOD:PUBLISH
BEGIN:VEVENT
UID:${apt.id}@eldercare.plus
DTSTAMP:${new Date().toISOString().replace(/[-:]/g, '').split('.')[0]}Z
DTSTART:${startIso}
DTEND:${endIso}
SUMMARY:Medical Appointment: ${apt.doctorName} (${apt.specialty})
DESCRIPTION:${apt.notes || 'Doctor consultation for Eleanor Vance.'}
LOCATION:${apt.hospitalName}, ${apt.hospitalAddress || ''}
STATUS:CONFIRMED
END:VEVENT
END:VCALENDAR`;

    const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
    const link = document.createElement('a');
    link.href = window.URL.createObjectURL(blob);
    link.setAttribute('download', `appointment-${apt.doctorName.toLowerCase().replace(/\s+/g, '-')}.ics`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const filteredAppointments = appointments.filter(a => {
    if (activeTab === 'upcoming') return a.status === 'upcoming';
    return a.status === 'completed' || a.status === 'cancelled';
  });

  return (
    <div className="space-y-8 pb-16">
      
      {/* 1. Header */}
      <section className="bg-white rounded-3xl border border-slate-200/80 p-6 sm:p-8 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="flex items-center space-x-2 text-elder-blue-700 text-xs font-bold uppercase tracking-wider mb-1">
              <CalendarIcon className="w-4 h-4" />
              <span>Doctor Appointments & Consultations</span>
            </div>
            <h1 className="text-3xl font-black text-slate-900">
              Healthcare Appointments
            </h1>
            <p className="text-slate-500 text-sm font-medium mt-1">
              Schedule visits, sync with calendars, and configure automated email reminders.
            </p>
          </div>

          <button
            onClick={() => {
              resetForm();
              setIsAddModalOpen(true);
            }}
            className="inline-flex items-center space-x-2 px-5 py-3 rounded-2xl bg-elder-blue-700 hover:bg-elder-blue-800 text-white font-extrabold text-sm shadow-md transition-all active:scale-95"
          >
            <Plus className="w-5 h-5" />
            <span>Schedule Appointment</span>
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="mt-8 pt-4 border-t border-slate-100 flex items-center space-x-2">
          <button
            onClick={() => setActiveTab('upcoming')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'upcoming' ? 'bg-elder-blue-700 text-white shadow-sm' : 'bg-slate-100 text-slate-600 hover:text-slate-900'
            }`}
          >
            Upcoming Consultations ({appointments.filter(a => a.status === 'upcoming').length})
          </button>
          <button
            onClick={() => setActiveTab('completed')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'completed' ? 'bg-elder-blue-700 text-white shadow-sm' : 'bg-slate-100 text-slate-600 hover:text-slate-900'
            }`}
          >
            Past & Completed ({appointments.filter(a => a.status !== 'upcoming').length})
          </button>
        </div>
      </section>

      {/* Reminder Status Alert */}
      {reminderStatusMsg && (
        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs font-semibold flex items-center justify-between">
          <span>{reminderStatusMsg}</span>
          <button onClick={() => setReminderStatusMsg(null)} className="text-slate-400 hover:text-slate-600">×</button>
        </div>
      )}

      {/* 2. Appointments Grid */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredAppointments.map((apt) => (
          <div
            key={apt.id}
            className={`bg-white rounded-3xl border p-6 shadow-sm flex flex-col justify-between transition-all ${
              apt.status === 'upcoming' ? 'border-slate-200 hover:border-elder-blue-400' : 'border-slate-200 opacity-75'
            }`}
          >
            <div>
              <div className="flex items-start justify-between">
                <div>
                  <span className="inline-block px-3 py-1 rounded-full text-xs font-bold bg-elder-blue-100 text-elder-blue-900 mb-2">
                    {apt.specialty}
                  </span>
                  <h3 className="text-2xl font-black text-slate-900">{apt.doctorName}</h3>
                </div>

                <div className="text-right">
                  <div className="px-3 py-1.5 rounded-xl bg-slate-100 text-slate-800 text-xs font-black">
                    {apt.appointmentDate}
                  </div>
                  <div className="text-xs font-bold text-slate-500 mt-1 flex items-center justify-end gap-1">
                    <Clock className="w-3.5 h-3.5" />
                    {apt.appointmentTime}
                  </div>
                </div>
              </div>

              <div className="mt-4 space-y-2 text-xs">
                <div className="flex items-start space-x-2 text-slate-700">
                  <MapPin className="w-4 h-4 text-slate-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <span className="font-extrabold">{apt.hospitalName}</span>
                    {apt.hospitalAddress && <p className="text-slate-500 mt-0.5">{apt.hospitalAddress}</p>}
                  </div>
                </div>

                {apt.notes && (
                  <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-slate-600 mt-2">
                    <span className="font-bold text-slate-700 block mb-0.5">Doctor Prep Notes:</span>
                    {apt.notes}
                  </div>
                )}
              </div>
            </div>

            {/* Actions Bar */}
            <div className="mt-6 pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3 text-xs">
              <div className="flex items-center space-x-2">
                {apt.status === 'upcoming' && (
                  <>
                    <button
                      onClick={() => handleSendReminder(apt)}
                      disabled={sendingReminderId === apt.id}
                      className="px-3 py-2 rounded-xl bg-elder-blue-50 hover:bg-elder-blue-100 text-elder-blue-800 font-bold border border-elder-blue-300 flex items-center gap-1.5 transition-all"
                      title="Send automated email reminder to patient and family"
                    >
                      <Mail className="w-3.5 h-3.5" />
                      <span>{sendingReminderId === apt.id ? 'Sending...' : 'Send Email Reminder'}</span>
                    </button>

                    <button
                      onClick={() => downloadIcsFile(apt)}
                      className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold"
                      title="Add to Google/Apple Calendar (.ics file)"
                    >
                      <Download className="w-4 h-4" />
                    </button>
                  </>
                )}
              </div>

              <div className="flex items-center space-x-2">
                {apt.status === 'upcoming' ? (
                  <button
                    onClick={() => updateAppointment(apt.id, { status: 'completed' })}
                    className="px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold"
                  >
                    Mark Completed
                  </button>
                ) : (
                  <span className="px-3 py-1 rounded-full bg-slate-100 text-slate-600 font-bold">
                    Completed
                  </span>
                )}

                <button
                  onClick={() => {
                    if (confirm('Delete this appointment record?')) {
                      deleteAppointment(apt.id);
                    }
                  }}
                  className="p-2 rounded-xl text-slate-400 hover:text-red-600 hover:bg-red-50"
                  title="Delete appointment"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        ))}

        {filteredAppointments.length === 0 && (
          <div className="col-span-2 text-center py-12 bg-white rounded-3xl border border-slate-200">
            <CalendarIcon className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <p className="text-slate-600 font-bold text-base">No appointments found in this view.</p>
            <p className="text-slate-400 text-xs mt-1">Schedule a doctor visit to get automated reminders!</p>
          </div>
        )}
      </section>

      {/* Add Appointment Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl my-8">
            <h2 className="text-2xl font-black text-slate-900 pb-4 border-b border-slate-100">
              Schedule Doctor Appointment
            </h2>

            <form onSubmit={handleAddAppointment} className="space-y-4 mt-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-black uppercase text-slate-700 mb-1">
                    Doctor's Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Dr. Rajesh Sharma"
                    value={doctorName}
                    onChange={(e) => setDoctorName(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-300 font-semibold focus:ring-2 focus:ring-elder-blue-600 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-black uppercase text-slate-700 mb-1">
                    Medical Specialty
                  </label>
                  <select
                    value={specialty}
                    onChange={(e) => setSpecialty(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-300 font-semibold focus:ring-2 focus:ring-elder-blue-600 focus:outline-none"
                  >
                    <option value="Cardiologist">Cardiologist</option>
                    <option value="Endocrinologist">Endocrinologist</option>
                    <option value="General Physician">General Physician</option>
                    <option value="Ophthalmologist">Ophthalmologist (Eye Care)</option>
                    <option value="Neurologist">Neurologist</option>
                    <option value="Orthopedic">Orthopedic Surgeon</option>
                    <option value="Dentist">Dentist</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-black uppercase text-slate-700 mb-1">
                  Hospital or Clinic Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. St. Jude Memorial Hospital"
                  value={hospitalName}
                  onChange={(e) => setHospitalName(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 font-semibold focus:ring-2 focus:ring-elder-blue-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-black uppercase text-slate-700 mb-1">
                  Clinic Address / Room Number
                </label>
                <input
                  type="text"
                  placeholder="e.g. Suite 402, 742 Evergreen Terrace"
                  value={hospitalAddress}
                  onChange={(e) => setHospitalAddress(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 font-semibold focus:ring-2 focus:ring-elder-blue-600 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-black uppercase text-slate-700 mb-1">
                    Appointment Date *
                  </label>
                  <input
                    type="date"
                    required
                    value={appointmentDate}
                    onChange={(e) => setAppointmentDate(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-300 font-semibold focus:ring-2 focus:ring-elder-blue-600 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-black uppercase text-slate-700 mb-1">
                    Appointment Time *
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. 10:30 AM"
                    value={appointmentTime}
                    onChange={(e) => setAppointmentTime(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-300 font-semibold focus:ring-2 focus:ring-elder-blue-600 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-black uppercase text-slate-700 mb-1">
                  Preparation & Consultation Notes
                </label>
                <textarea
                  rows={2}
                  placeholder="e.g. Fasting 10 hours before appointment for glucose check. Bring ECG records."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full px-4 py-2 rounded-xl border border-slate-300 font-medium text-sm focus:ring-2 focus:ring-elder-blue-600 focus:outline-none"
                />
              </div>

              <div className="flex space-x-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="flex-1 py-3 rounded-xl border border-slate-300 font-bold text-slate-700 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-3 rounded-xl bg-elder-blue-700 hover:bg-elder-blue-800 text-white font-extrabold shadow-md"
                >
                  Save & Schedule
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
