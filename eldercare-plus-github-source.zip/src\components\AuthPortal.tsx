import React, { useState } from 'react';
import { 
  Heart, 
  Lock, 
  Mail, 
  User, 
  Phone, 
  ShieldCheck, 
  Eye, 
  EyeOff, 
  ArrowRight, 
  Users, 
  Volume2, 
  AlertCircle,
  Activity
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useAccessibility } from '../context/AccessibilityContext';
import { UserRole } from '../types';

export const AuthPortal: React.FC = () => {
  const { login, signup, quickSignIn } = useAuth();
  const { settings, speak, playChime, updateSettings } = useAccessibility();

  const [mode, setMode] = useState<'signin' | 'signup'>('signin');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Sign In Form State
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');

  // Sign Up Form State
  const [registerRole, setRegisterRole] = useState<UserRole>('elderly');
  const [registerName, setRegisterName] = useState('');
  const [registerEmail, setRegisterEmail] = useState('');
  const [registerPassword, setRegisterPassword] = useState('');
  const [registerPhone, setRegisterPhone] = useState('');
  const [registerRelation, setRegisterRelation] = useState('');
  const [registerLang, setRegisterLang] = useState<'en' | 'hi' | 'bn'>(settings.language);

  const getGreeting = () => {
    if (settings.language === 'hi') {
      return {
        welcome: 'एल्डरकेयर+ में आपका स्वागत है',
        subtitle: 'बिना किसी बाधा के स्वास्थ्य देखभाल और सुरक्षित दवा प्रबंधन',
        voiceText: 'एल्डरकेयर प्लस में आपका स्वागत है। कृपया प्रवेश करने के लिए साइन इन करें।'
      };
    }
    if (settings.language === 'bn') {
      return {
        welcome: 'এল্ডারকেয়ার+ এ আপনাকে স্বাগতম',
        subtitle: 'যোগাযোগ ও অ্যাক্সেসিবিলিটি বাধাহীন নিরাপদ ওষুধ ও স্বাস্থ্যসেবা',
        voiceText: 'এল্ডারকেয়ার প্লাসে স্বাগতম। অনুগ্রহ করে সাইন ইন করুন।'
      };
    }
    return {
      welcome: 'Welcome to ElderCare+',
      subtitle: 'Healthcare Without Communication or Accessibility Barriers',
      voiceText: 'Welcome to ElderCare Plus. Please sign in or choose your profile to continue.'
    };
  };

  const greeting = getGreeting();

  const handleSpeakGreeting = () => {
    playChime('success');
    speak(greeting.voiceText);
  };

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setLoading(true);

    const res = await login({ email: loginEmail, password: loginPassword });
    setLoading(false);

    if (!res.success) {
      setErrorMessage(res.error || 'Login failed. Please check your credentials.');
      playChime('alert');
    }
  };

  const handleSignupSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setLoading(true);

    const res = await signup({
      fullName: registerName,
      email: registerEmail,
      password: registerPassword,
      role: registerRole,
      phone: registerPhone,
      relationshipLabel: registerRelation,
      languagePreference: registerLang,
    });
    setLoading(false);

    if (!res.success) {
      setErrorMessage(res.error || 'Registration failed.');
      playChime('alert');
    }
  };

  return (
    <div className="min-h-screen flex flex-col justify-between bg-gradient-to-b from-slate-50 via-white to-slate-100 py-8 px-4 sm:px-6 lg:px-8 selection:bg-elder-green-200">
      
      {/* Top Header & Accessibility Controls */}
      <header className="max-w-5xl mx-auto w-full flex items-center justify-between py-2 border-b border-slate-200/60 pb-4">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-elder-green-600 to-elder-green-800 flex items-center justify-center text-white shadow-md shadow-elder-green-600/30">
            <Heart className="w-7 h-7 fill-white/20 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-black tracking-tight text-slate-900">
              ElderCare<span className="text-elder-green-600">+</span>
            </h1>
            <p className="text-xs font-semibold text-slate-500">Smart Elderly Care Platform</p>
          </div>
        </div>

        {/* Language selector & Voice Welcome */}
        <div className="flex items-center space-x-2">
          <button
            onClick={handleSpeakGreeting}
            title="Listen to welcome message"
            className="p-2.5 rounded-xl bg-elder-green-100 hover:bg-elder-green-200 text-elder-green-900 flex items-center gap-1.5 text-xs font-bold transition-all"
            aria-label="Voice greeting"
          >
            <Volume2 className="w-4 h-4 text-elder-green-800" />
            <span className="hidden sm:inline">Voice Assist</span>
          </button>

          <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200 text-xs font-extrabold text-slate-600">
            <button
              onClick={() => {
                playChime('click');
                updateSettings({ language: 'en' });
              }}
              className={`px-2.5 py-1 rounded-lg ${settings.language === 'en' ? 'bg-white text-elder-green-800 shadow-xs' : 'hover:text-slate-900'}`}
            >
              EN
            </button>
            <button
              onClick={() => {
                playChime('click');
                updateSettings({ language: 'hi' });
              }}
              className={`px-2.5 py-1 rounded-lg ${settings.language === 'hi' ? 'bg-white text-elder-green-800 shadow-xs' : 'hover:text-slate-900'}`}
            >
              हिंदी
            </button>
            <button
              onClick={() => {
                playChime('click');
                updateSettings({ language: 'bn' });
              }}
              className={`px-2.5 py-1 rounded-lg ${settings.language === 'bn' ? 'bg-white text-elder-green-800 shadow-xs' : 'hover:text-slate-900'}`}
            >
              বাংলা
            </button>
          </div>
        </div>
      </header>

      {/* Main Authentication Container */}
      <main className="max-w-4xl mx-auto w-full my-auto py-8">
        
        {/* Welcome Banner */}
        <div className="text-center mb-8">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-elder-green-100 text-elder-green-800 mb-3 border border-elder-green-300">
            <ShieldCheck className="w-3.5 h-3.5" />
            Secure Certified Patient & Caregiver Portal
          </span>
          <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
            {greeting.welcome}
          </h2>
          <p className="mt-2 text-slate-600 font-medium max-w-xl mx-auto text-sm sm:text-base">
            {greeting.subtitle}
          </p>
        </div>

        {/* Tab Toggle: Sign In vs Sign Up */}
        <div className="max-w-md mx-auto bg-slate-100 p-1.5 rounded-2xl border border-slate-200 flex items-center mb-6">
          <button
            onClick={() => {
              playChime('click');
              setMode('signin');
              setErrorMessage(null);
            }}
            className={`flex-1 py-2.5 rounded-xl font-extrabold text-sm transition-all ${
              mode === 'signin'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            Sign In to Account
          </button>
          <button
            onClick={() => {
              playChime('click');
              setMode('signup');
              setErrorMessage(null);
            }}
            className={`flex-1 py-2.5 rounded-xl font-extrabold text-sm transition-all ${
              mode === 'signup'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            Create New Account
          </button>
        </div>

        {/* Error Alert */}
        {errorMessage && (
          <div 
            role="alert" 
            className="max-w-md mx-auto mb-6 p-4 rounded-2xl bg-red-50 border-2 border-red-300 text-red-900 flex items-start space-x-3 text-sm animate-shake"
          >
            <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <span className="font-bold block">Action Required</span>
              <span>{errorMessage}</span>
            </div>
          </div>
        )}

        {/* SIGN IN FORM */}
        {mode === 'signin' && (
          <div className="max-w-md mx-auto bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-xl shadow-slate-200/50">
            <form onSubmit={handleLoginSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="w-5 h-5 text-slate-400 absolute left-3.5 top-3.5" />
                  <input
                    type="email"
                    required
                    value={loginEmail}
                    onChange={(e) => setLoginEmail(e.target.value)}
                    placeholder="e.g. eleanor.vance@eldercare.plus"
                    className="w-full pl-11 pr-4 py-3 rounded-xl border border-slate-300 focus:border-elder-green-600 focus:ring-2 focus:ring-elder-green-200 font-semibold text-slate-900 text-sm outline-none transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                  Password
                </label>
                <div className="relative">
                  <Lock className="w-5 h-5 text-slate-400 absolute left-3.5 top-3.5" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="Enter your password"
                    className="w-full pl-11 pr-11 py-3 rounded-xl border border-slate-300 focus:border-elder-green-600 focus:ring-2 focus:ring-elder-green-200 font-semibold text-slate-900 text-sm outline-none transition-all"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3.5 top-3.5 text-slate-400 hover:text-slate-600"
                    aria-label={showPassword ? 'Hide password' : 'Show password'}
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between text-xs text-slate-500 pt-1">
                <span className="flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-elder-green-600" />
                  Persistent Local Session
                </span>
                <span className="font-semibold text-elder-green-700">Passcode enabled</span>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full mt-2 py-3.5 px-4 rounded-xl bg-elder-green-700 hover:bg-elder-green-800 text-white font-extrabold text-base flex items-center justify-center space-x-2 shadow-lg shadow-elder-green-700/25 transition-all active:scale-[0.99] disabled:opacity-50"
              >
                <span>{loading ? 'Verifying Account...' : 'Sign In to Dashboard'}</span>
                <ArrowRight className="w-5 h-5" />
              </button>
            </form>
          </div>
        )}

        {/* SIGN UP FORM */}
        {mode === 'signup' && (
          <div className="max-w-lg mx-auto bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-xl shadow-slate-200/50">
            <form onSubmit={handleSignupSubmit} className="space-y-4">
              
              {/* Role Selection Cards */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
                  Select Your Account Role
                </label>
                <div className="grid grid-cols-3 gap-2.5">
                  <button
                    type="button"
                    onClick={() => {
                      playChime('click');
                      setRegisterRole('elderly');
                    }}
                    className={`p-3 rounded-2xl border text-center transition-all ${
                      registerRole === 'elderly'
                        ? 'border-elder-green-600 bg-elder-green-50 ring-2 ring-elder-green-300'
                        : 'border-slate-200 bg-white hover:bg-slate-50'
                    }`}
                  >
                    <div className="w-8 h-8 mx-auto rounded-xl bg-elder-green-700 text-white flex items-center justify-center mb-1.5">
                      <Heart className="w-4 h-4" />
                    </div>
                    <span className="block text-xs font-black text-slate-900">Elderly</span>
                    <span className="block text-[10px] text-slate-500 font-medium">Patient</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      playChime('click');
                      setRegisterRole('family');
                    }}
                    className={`p-3 rounded-2xl border text-center transition-all ${
                      registerRole === 'family'
                        ? 'border-elder-blue-600 bg-elder-blue-50 ring-2 ring-elder-blue-300'
                        : 'border-slate-200 bg-white hover:bg-slate-50'
                    }`}
                  >
                    <div className="w-8 h-8 mx-auto rounded-xl bg-elder-blue-700 text-white flex items-center justify-center mb-1.5">
                      <Users className="w-4 h-4" />
                    </div>
                    <span className="block text-xs font-black text-slate-900">Family</span>
                    <span className="block text-[10px] text-slate-500 font-medium">Guardian</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      playChime('click');
                      setRegisterRole('caregiver');
                    }}
                    className={`p-3 rounded-2xl border text-center transition-all ${
                      registerRole === 'caregiver'
                        ? 'border-purple-600 bg-purple-50 ring-2 ring-purple-300'
                        : 'border-slate-200 bg-white hover:bg-slate-50'
                    }`}
                  >
                    <div className="w-8 h-8 mx-auto rounded-xl bg-purple-700 text-white flex items-center justify-center mb-1.5">
                      <Activity className="w-4 h-4" />
                    </div>
                    <span className="block text-xs font-black text-slate-900">Nurse</span>
                    <span className="block text-[10px] text-slate-500 font-medium">Caregiver</span>
                  </button>
                </div>
              </div>

              {/* Full Name */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                  Full Name
                </label>
                <div className="relative">
                  <User className="w-5 h-5 text-slate-400 absolute left-3.5 top-3.5" />
                  <input
                    type="text"
                    required
                    value={registerName}
                    onChange={(e) => setRegisterName(e.target.value)}
                    placeholder="e.g. Maya Sharma"
                    className="w-full pl-11 pr-4 py-3 rounded-xl border border-slate-300 focus:border-elder-green-600 focus:ring-2 focus:ring-elder-green-200 font-semibold text-slate-900 text-sm outline-none"
                  />
                </div>
              </div>

              {/* Email Address */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="w-5 h-5 text-slate-400 absolute left-3.5 top-3.5" />
                  <input
                    type="email"
                    required
                    value={registerEmail}
                    onChange={(e) => setRegisterEmail(e.target.value)}
                    placeholder="e.g. maya.sharma@example.com"
                    className="w-full pl-11 pr-4 py-3 rounded-xl border border-slate-300 focus:border-elder-green-600 focus:ring-2 focus:ring-elder-green-200 font-semibold text-slate-900 text-sm outline-none"
                  />
                </div>
              </div>

              {/* Password */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                  Create Password
                </label>
                <div className="relative">
                  <Lock className="w-5 h-5 text-slate-400 absolute left-3.5 top-3.5" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={registerPassword}
                    onChange={(e) => setRegisterPassword(e.target.value)}
                    placeholder="Choose a secure password"
                    className="w-full pl-11 pr-11 py-3 rounded-xl border border-slate-300 focus:border-elder-green-600 focus:ring-2 focus:ring-elder-green-200 font-semibold text-slate-900 text-sm outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3.5 top-3.5 text-slate-400 hover:text-slate-600"
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              {/* Phone & Relationship */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                    Phone (Optional)
                  </label>
                  <div className="relative">
                    <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
                    <input
                      type="tel"
                      value={registerPhone}
                      onChange={(e) => setRegisterPhone(e.target.value)}
                      placeholder="+1 (555) 000-0000"
                      className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-300 text-xs font-semibold text-slate-900 outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                    Relationship Label
                  </label>
                  <input
                    type="text"
                    value={registerRelation}
                    onChange={(e) => setRegisterRelation(e.target.value)}
                    placeholder={registerRole === 'family' ? 'e.g. Daughter' : registerRole === 'caregiver' ? 'e.g. Visiting Nurse' : 'Self'}
                    className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-xs font-semibold text-slate-900 outline-none"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full mt-3 py-3.5 px-4 rounded-xl bg-elder-green-700 hover:bg-elder-green-800 text-white font-extrabold text-base flex items-center justify-center space-x-2 shadow-lg shadow-elder-green-700/25 transition-all active:scale-[0.99] disabled:opacity-50"
              >
                <span>{loading ? 'Creating Account...' : 'Complete Registration & Sign In'}</span>
                <ArrowRight className="w-5 h-5" />
              </button>
            </form>
          </div>
        )}

        {/* 1-Click Fast Role Sign-in Cards */}
        <div className="mt-10 pt-8 border-t border-slate-200">
          <div className="text-center mb-5">
            <span className="text-xs font-extrabold tracking-wider text-slate-400 uppercase">
              Or Instant 1-Click Verified Role Login
            </span>
            <p className="text-xs text-slate-500 font-medium mt-0.5">
              Click any verified profile below for instant access without typing:
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            
            {/* Elderly Profile Card */}
            <button
              onClick={() => quickSignIn('elderly')}
              className="p-4 rounded-2xl bg-white border border-slate-200 hover:border-elder-green-600 hover:shadow-lg transition-all text-left group flex items-start space-x-3.5"
            >
              <img
                src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=256"
                alt="Eleanor Vance"
                className="w-12 h-12 rounded-xl object-cover border border-slate-200 group-hover:scale-105 transition-transform"
              />
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-900 text-sm group-hover:text-elder-green-800 transition-colors">
                    Eleanor Vance
                  </span>
                  <span className="px-2 py-0.5 rounded-md bg-elder-green-100 text-elder-green-800 font-black text-[10px]">
                    Elderly
                  </span>
                </div>
                <p className="text-xs text-slate-500 truncate">eleanor.vance@eldercare.plus</p>
                <span className="inline-flex items-center gap-1 text-[11px] font-bold text-elder-green-700 mt-2">
                  <span>Enter as Patient</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                </span>
              </div>
            </button>

            {/* Family Profile Card */}
            <button
              onClick={() => quickSignIn('family')}
              className="p-4 rounded-2xl bg-white border border-slate-200 hover:border-elder-blue-600 hover:shadow-lg transition-all text-left group flex items-start space-x-3.5"
            >
              <img
                src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=256"
                alt="Priya Vance"
                className="w-12 h-12 rounded-xl object-cover border border-slate-200 group-hover:scale-105 transition-transform"
              />
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-900 text-sm group-hover:text-elder-blue-800 transition-colors">
                    Priya Vance
                  </span>
                  <span className="px-2 py-0.5 rounded-md bg-elder-blue-100 text-elder-blue-800 font-black text-[10px]">
                    Family
                  </span>
                </div>
                <p className="text-xs text-slate-500 truncate">priya.vance@familycare.org</p>
                <span className="inline-flex items-center gap-1 text-[11px] font-bold text-elder-blue-700 mt-2">
                  <span>Enter as Family</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                </span>
              </div>
            </button>

            {/* Caregiver Profile Card */}
            <button
              onClick={() => quickSignIn('caregiver')}
              className="p-4 rounded-2xl bg-white border border-slate-200 hover:border-purple-600 hover:shadow-lg transition-all text-left group flex items-start space-x-3.5"
            >
              <img
                src="https://images.unsplash.com/photo-1594824813589-399081e792e8?auto=format&fit=crop&q=80&w=256"
                alt="Nurse Sarah Jenkins"
                className="w-12 h-12 rounded-xl object-cover border border-slate-200 group-hover:scale-105 transition-transform"
              />
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-900 text-sm group-hover:text-purple-800 transition-colors">
                    Nurse Sarah Jenkins
                  </span>
                  <span className="px-2 py-0.5 rounded-md bg-purple-100 text-purple-800 font-black text-[10px]">
                    Nurse RN
                  </span>
                </div>
                <p className="text-xs text-slate-500 truncate">sarah.nurse@elderhealth.net</p>
                <span className="inline-flex items-center gap-1 text-[11px] font-bold text-purple-700 mt-2">
                  <span>Enter as Nurse</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                </span>
              </div>
            </button>

          </div>
        </div>

      </main>

      {/* Footer */}
      <footer className="max-w-5xl mx-auto w-full text-center py-4 border-t border-slate-200/60 text-xs text-slate-500 flex flex-col sm:flex-row items-center justify-between gap-2">
        <div className="flex items-center space-x-2">
          <ShieldCheck className="w-4 h-4 text-elder-green-700" />
          <span>WCAG 2.2 AA Certified Accessible Healthcare Platform</span>
        </div>
        <div className="flex items-center space-x-4">
          <span>Protected Passcode Verification</span>
          <span>•</span>
          <span>Dual-Mode Cloud/Local Persistence</span>
        </div>
      </footer>

    </div>
  );
};
