import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Pill, 
  Calendar, 
  Printer, 
  CheckCircle2, 
  AlertTriangle, 
  Plus, 
  User, 
  Heart, 
  FileText,
  Clock,
  Sparkles,
  Activity
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useAccessibility } from '../context/AccessibilityContext';

interface CaregiverDashboardProps {
  onNavigateTab: (tab: 'medications' | 'appointments' | 'profile') => void;
}

export const CaregiverDashboard: React.FC<CaregiverDashboardProps> = ({ onNavigateTab }) => {
  const { 
    currentUser, 
    healthcareProfile, 
    medicines, 
    schedules, 
    markDoseStatus, 
    appointments, 
    adherencePercentage, 
    adherenceStreak,
    stats,
    auditLogs
  } = useAuth();

  const { playChime, speak } = useAccessibility();
  const [filterTime, setFilterTime] = useState<'all' | 'morning' | 'afternoon' | 'evening' | 'night'>('all');

  const handleAdminister = (scheduleId: string, medName: string) => {
    markDoseStatus(scheduleId, 'taken');
    speak(`Administered ${medName} recorded by nurse.`);
  };

  const handlePrintReport = () => {
    window.print();
  };

  const filteredSchedules = schedules.filter(item => {
    if (filterTime === 'all') return true;
    const hour = parseInt(item.scheduledTime.split(':')[0], 10);
    const isPM = item.scheduledTime.includes('PM');
    const adjustedHour = isPM && hour !== 12 ? hour + 12 : (!isPM && hour === 12 ? 0 : hour);
    
    if (filterTime === 'morning') return adjustedHour < 12;
    if (filterTime === 'afternoon') return adjustedHour >= 12 && adjustedHour < 17;
    if (filterTime === 'evening') return adjustedHour >= 17 && adjustedHour < 21;
    if (filterTime === 'night') return adjustedHour >= 21;
    return true;
  });

  return (
    <div className="space-y-8 pb-16">
      
      {/* 1. Clinical Header */}
      <section className="bg-gradient-to-r from-purple-800 via-indigo-900 to-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-white/15 backdrop-blur text-purple-200 text-xs font-bold uppercase tracking-wider">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Clinical Caregiver & Nursing Portal</span>
            </div>
            
            <h1 className="text-3xl sm:text-4xl font-black text-white">
              Patient: Eleanor Vance (74 y/o)
            </h1>
            
            <p className="text-purple-200 text-sm sm:text-base font-medium max-w-xl">
              Logged in as <strong className="text-white">{currentUser?.fullName || (currentUser as any)?.name || 'Nurse Sarah Jenkins'}</strong>. 
              Review electronic Medication Administration Records (eMAR) and clinical care coordinates.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={handlePrintReport}
              className="inline-flex items-center space-x-2 px-4 py-2.5 rounded-xl bg-white text-purple-950 font-bold text-xs shadow-md hover:bg-purple-50 transition-all"
            >
              <Printer className="w-4 h-4 text-purple-700" />
              <span>Print Daily Care Report</span>
            </button>

            <button
              onClick={() => onNavigateTab('medications')}
              className="inline-flex items-center space-x-1.5 px-4 py-2.5 rounded-xl bg-purple-700 hover:bg-purple-600 text-white font-bold text-xs shadow-md transition-all"
            >
              <Plus className="w-4 h-4" />
              <span>Add Medication</span>
            </button>
          </div>
        </div>
      </section>

      {/* 2. Patient Clinical Alert & Allergies Summary */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Allergies Alert */}
        <div className="bg-red-50 border-2 border-red-200 rounded-3xl p-5 shadow-sm">
          <div className="flex items-center space-x-2 text-red-900 font-extrabold text-sm uppercase tracking-wider mb-2">
            <AlertTriangle className="w-4 h-4 text-red-600" />
            <span>Documented Allergies</span>
          </div>
          <div className="space-y-1.5">
            {healthcareProfile.knownAllergies.map((allergy, i) => (
              <span key={i} className="inline-block px-2.5 py-1 bg-red-100 text-red-900 text-xs font-bold rounded-lg mr-1.5 mb-1.5">
                {allergy}
              </span>
            ))}
          </div>
        </div>

        {/* Chronic Conditions */}
        <div className="bg-amber-50 border-2 border-amber-200 rounded-3xl p-5 shadow-sm">
          <div className="flex items-center space-x-2 text-amber-900 font-extrabold text-sm uppercase tracking-wider mb-2">
            <Activity className="w-4 h-4 text-amber-600" />
            <span>Chronic Conditions</span>
          </div>
          <div className="space-y-1">
            {healthcareProfile.chronicConditions.map((cond, i) => (
              <p key={i} className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                • {cond}
              </p>
            ))}
          </div>
        </div>

        {/* Primary Physician & Emergency Contact */}
        <div className="bg-white border-2 border-slate-200 rounded-3xl p-5 shadow-sm">
          <div className="flex items-center space-x-2 text-slate-900 font-extrabold text-sm uppercase tracking-wider mb-2">
            <Heart className="w-4 h-4 text-elder-green-700" />
            <span>Primary Physician</span>
          </div>
          <p className="text-sm font-extrabold text-slate-900">{healthcareProfile.primaryPhysicianName}</p>
          <p className="text-xs text-slate-600 font-medium">{healthcareProfile.hospitalPreference}</p>
          <p className="text-xs text-slate-500 font-bold mt-1">Tel: {healthcareProfile.primaryPhysicianPhone}</p>
        </div>

      </section>

      {/* 3. Electronic Medication Administration Record (eMAR) */}
      <section className="bg-white rounded-3xl border border-slate-200/80 p-6 sm:p-8 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <h2 className="text-2xl font-black text-slate-900">
              Electronic Medication Administration Record (eMAR)
            </h2>
            <p className="text-slate-500 text-sm font-medium">
              Daily verification chart for scheduled pharmacotherapy.
            </p>
          </div>

          {/* Time of Day Tabs */}
          <div className="flex items-center space-x-1 bg-slate-100 p-1 rounded-xl text-xs font-bold">
            {(['all', 'morning', 'afternoon', 'evening', 'night'] as const).map(tab => (
              <button
                key={tab}
                onClick={() => setFilterTime(tab)}
                className={`px-3 py-1.5 rounded-lg capitalize transition-all ${
                  filterTime === tab ? 'bg-purple-700 text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>

        {/* Table representation */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 text-xs font-black text-slate-500 uppercase tracking-wider">
                <th className="pb-3 px-3">Medicine & Dosage</th>
                <th className="pb-3 px-3">Scheduled Time</th>
                <th className="pb-3 px-3">Administration Note</th>
                <th className="pb-3 px-3">Current Status</th>
                <th className="pb-3 px-3 text-right">Nurse Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm">
              {filteredSchedules.map((item) => (
                <tr key={item.id} className="hover:bg-slate-50/70 transition-colors">
                  <td className="py-4 px-3">
                    <div className="font-extrabold text-slate-900">{item.medicineName}</div>
                    <div className="text-xs text-purple-700 font-semibold">{item.dosage} • {item.form}</div>
                  </td>
                  <td className="py-4 px-3 font-mono font-bold text-slate-700">
                    {item.scheduledTime}
                  </td>
                  <td className="py-4 px-3 text-xs text-slate-600 font-medium">
                    {item.foodInstruction}
                    {item.instructions && <div className="text-slate-400 italic mt-0.5">{item.instructions}</div>}
                  </td>
                  <td className="py-4 px-3">
                    {item.status === 'taken' ? (
                      <span className="inline-flex items-center px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-extrabold">
                        <CheckCircle2 className="w-3.5 h-3.5 mr-1" />
                        Administered ({item.takenAt})
                      </span>
                    ) : item.status === 'skipped' ? (
                      <span className="inline-flex items-center px-2.5 py-1 rounded-full bg-red-100 text-red-800 text-xs font-extrabold">
                        <AlertTriangle className="w-3.5 h-3.5 mr-1" />
                        Omitted: {item.skippedReason}
                      </span>
                    ) : (
                      <span className="inline-flex items-center px-2.5 py-1 rounded-full bg-amber-100 text-amber-800 text-xs font-bold">
                        <Clock className="w-3.5 h-3.5 mr-1" />
                        Due / Pending
                      </span>
                    )}
                  </td>
                  <td className="py-4 px-3 text-right">
                    {item.status !== 'taken' ? (
                      <button
                        onClick={() => handleAdminister(item.id, item.medicineName)}
                        className="px-3.5 py-1.5 rounded-xl bg-purple-700 hover:bg-purple-800 text-white font-bold text-xs shadow-sm transition-all"
                      >
                        Administer Dose
                      </button>
                    ) : (
                      <span className="text-xs text-slate-400 font-medium">Verified</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* 4. Recent Healthcare Audit Trail */}
      <section className="bg-white rounded-3xl border border-slate-200/80 p-6 sm:p-8 shadow-sm">
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center font-bold">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-black text-slate-900">Healthcare Audit & Modification History</h2>
              <p className="text-xs text-slate-500 font-medium">Immutable log of medication confirmations, appointments, and passcode grants</p>
            </div>
          </div>
        </div>

        <div className="space-y-3">
          {auditLogs.slice(0, 5).map((log) => (
            <div key={log.id} className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80 flex items-center justify-between text-xs">
              <div className="space-y-0.5">
                <p className="font-extrabold text-slate-900">
                  <span className="text-purple-700 mr-2">[{log.action}]</span>
                  {log.details}
                </p>
                <p className="text-slate-500 font-medium">
                  By {log.actorName} ({log.actorRole})
                </p>
              </div>
              <span className="text-slate-400 font-mono">
                {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
          ))}
        </div>
      </section>

    </div>
  );
};
