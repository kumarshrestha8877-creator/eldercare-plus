import React, { useState } from 'react';
import { 
  Check, 
  X, 
  Clock, 
  Volume2, 
  Calendar, 
  Users, 
  Heart, 
  Flame, 
  MessageSquare, 
  PhoneCall, 
  ChevronRight, 
  Info,
  Pill,
  Sparkles,
  Moon,
  Mic,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  Compass
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useAccessibility } from '../context/AccessibilityContext';
import { MedicationScheduleItem } from '../types';

interface ElderlyDashboardProps {
  onOpenSilentModal: () => void;
  onOpenVoiceModal: () => void;
  onOpenSosModal: () => void;
  onOpenPasscodeModal: () => void;
  onNavigateTab: (tab: 'medications' | 'appointments' | 'profile') => void;
}

export const ElderlyDashboard: React.FC<ElderlyDashboardProps> = ({
  onOpenSilentModal,
  onOpenVoiceModal,
  onOpenSosModal,
  onOpenPasscodeModal,
  onNavigateTab,
}) => {
  const { 
    currentUser, 
    schedules, 
    markDoseStatus, 
    appointments, 
    relations, 
    adherencePercentage, 
    adherenceStreak,
    stats,
    setTourOpen,
  } = useAuth();
  
  const { speak, speakKey, t, settings } = useAccessibility();
  const [skipModalItem, setSkipModalItem] = useState<MedicationScheduleItem | null>(null);
  const [skipReason, setSkipReason] = useState('Doctor advised');

  // Time of day greeting
  const hour = new Date().getHours();
  const greeting = hour < 12 ? t('goodMorning') : hour < 17 ? t('goodAfternoon') : t('goodEvening');

  // Next upcoming pending medicine
  const nextPendingMed = schedules.find(s => s.status === 'pending');

  // Night / Bedtime medications
  const nightMeds = schedules.filter(s => s.scheduledTime.includes('PM') || s.foodInstruction.toLowerCase().includes('bedtime'));

  const upcomingAppointments = appointments
    .filter(a => a.status === 'upcoming')
    .slice(0, 2);

  const readScheduleAloud = () => {
    const pendingCount = schedules.filter(s => s.status === 'pending').length;
    const takenCount = schedules.filter(s => s.status === 'taken').length;
    const userFirstName = (currentUser?.fullName || (currentUser as any)?.name || 'Eleanor').split(' ')[0];
    speakKey('read_schedule', {
      userName: userFirstName,
      takenCount,
      pendingCount,
      medName: nextPendingMed?.medicineName,
      dosage: nextPendingMed?.dosage,
      time: nextPendingMed?.scheduledTime,
    });
  };

  const handleSkipConfirm = () => {
    if (skipModalItem) {
      markDoseStatus(skipModalItem.id, 'skipped', skipReason);
      setSkipModalItem(null);
    }
  };

  const userFirstName = (currentUser?.fullName || (currentUser as any)?.name || 'Eleanor').split(' ')[0];

  return (
    <div className="space-y-10 pb-20">
      
      {/* 1. Welcoming Hero Banner */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-800 via-teal-900 to-slate-900 text-white p-7 sm:p-9 md:p-10 shadow-lg">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-3 max-w-xl">
            <div className="inline-flex items-center space-x-2 px-3.5 py-1 rounded-full bg-white/15 backdrop-blur text-emerald-100 text-xs font-semibold border border-white/20">
              <Calendar className="w-3.5 h-3.5" />
              <span>{new Date().toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' })}</span>
            </div>
            
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-black tracking-tight text-white">
              {greeting}, {userFirstName}!
            </h1>
            
            <p className="text-emerald-100/90 text-sm sm:text-base font-medium leading-relaxed">
              {settings.language === 'hi'
                ? 'हम आज आपके स्वास्थ्य, दवाओं और सुरक्षा का पूरा ध्यान रख रहे हैं।'
                : settings.language === 'bn'
                ? 'আমরা আজ আপনার স্বাস্থ্য, ওষুধ ও নিরাপত্তার খেয়াল রাখছি।'
                : "Your daily health routine is organized and ready for you today."}
            </p>

            {/* Audio Schedule Narration Button */}
            <div className="pt-2 flex flex-wrap items-center gap-3">
              <button
                onClick={readScheduleAloud}
                className="inline-flex items-center space-x-2 px-5 py-3 rounded-2xl bg-white text-emerald-950 font-extrabold hover:bg-emerald-50 active:scale-95 transition-all shadow-md text-sm"
              >
                <Volume2 className="w-5 h-5 text-emerald-700" />
                <span>{t('readSchedule')}</span>
              </button>

              <button
                onClick={onOpenVoiceModal}
                className="inline-flex items-center space-x-2 px-4 py-3 rounded-2xl bg-white/15 text-white font-semibold hover:bg-white/25 transition-all border border-white/25 backdrop-blur text-sm"
              >
                <Sparkles className="w-4 h-4 text-emerald-300" />
                <span>{t('voiceHelp')}</span>
              </button>

              <button
                onClick={() => setTourOpen(true)}
                className="inline-flex items-center space-x-2 px-4 py-3 rounded-2xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black active:scale-95 transition-all shadow-md text-sm"
              >
                <Compass className="w-4 h-4 text-slate-950" />
                <span>
                  {settings.language === 'hi' ? 'मार्गदर्शिका (तीर देखें)' : settings.language === 'bn' ? 'ট্যুর নির্দেশিকা (তীর)' : 'How Website Works (Tour)'}
                </span>
              </button>
            </div>
          </div>

          {/* Adherence Streak Badge */}
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20 text-center min-w-[200px] flex md:flex-col justify-around items-center gap-4">
            <div>
              <div className="flex items-center justify-center space-x-1.5 text-amber-300 text-3xl sm:text-4xl font-black">
                <Flame className="w-8 h-8 fill-amber-400 text-amber-400" />
                <span>{adherenceStreak}</span>
              </div>
              <p className="text-xs uppercase tracking-wider text-emerald-200 font-bold mt-1">
                {t('streak')}
              </p>
            </div>
            <div className="h-10 w-px bg-white/20 md:w-full md:h-px" />
            <div>
              <div className="text-3xl sm:text-4xl font-black text-white">
                {adherencePercentage}%
              </div>
              <p className="text-xs uppercase tracking-wider text-emerald-200 font-bold mt-1">
                {t('todaysAdherence')}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 2. Immediate Focus: Next Pill Card */}
      {nextPendingMed ? (
        <section className="bg-amber-50/80 border border-amber-300/80 rounded-3xl p-6 sm:p-7 shadow-xs">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="flex items-start space-x-4">
              <div className="w-14 h-14 rounded-2xl bg-amber-500 text-white flex items-center justify-center shadow-md flex-shrink-0">
                <Clock className="w-7 h-7" />
              </div>
              <div>
                <span className="inline-block text-xs uppercase font-extrabold tracking-wider text-amber-900 bg-amber-200/90 px-2.5 py-0.5 rounded-full mb-1">
                  {t('nextUpcomingDose')}
                </span>
                <h2 className="text-2xl sm:text-3xl font-black text-slate-900">
                  {nextPendingMed.medicineName} ({nextPendingMed.dosage})
                </h2>
                <p className="text-slate-600 font-semibold text-base mt-1">
                  {t('dueAt')} <strong>{nextPendingMed.scheduledTime}</strong> • {t(nextPendingMed.foodInstruction) || nextPendingMed.foodInstruction}
                </p>
                {nextPendingMed.instructions && (
                  <p className="text-xs text-amber-800 font-medium mt-1 flex items-center gap-1">
                    <Info className="w-3.5 h-3.5" /> {nextPendingMed.instructions}
                  </p>
                )}
              </div>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={() => markDoseStatus(nextPendingMed.id, 'taken')}
                className="inline-flex items-center justify-center space-x-2 px-7 py-4 rounded-2xl bg-elder-green-700 hover:bg-elder-green-800 text-white font-extrabold text-base shadow-md shadow-elder-green-700/20 active:scale-95 transition-all"
              >
                <Check className="w-6 h-6 stroke-[3]" />
                <span>{t('markTaken')}</span>
              </button>

              <button
                onClick={() => setSkipModalItem(nextPendingMed)}
                className="px-4 py-4 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-600 text-xs font-bold transition-all"
                title="Skip this dose"
              >
                {t('markSkipped')}
              </button>
            </div>
          </div>
        </section>
      ) : (
        <section className="bg-emerald-50/80 border border-emerald-200 rounded-3xl p-6 sm:p-7 text-center shadow-xs">
          <div className="inline-flex p-3 rounded-full bg-emerald-100 text-emerald-800 mb-2">
            <CheckCircle2 className="w-8 h-8" />
          </div>
          <h2 className="text-2xl font-black text-emerald-950">{t('allDosesCompleted')}</h2>
          <p className="text-emerald-700 font-medium text-sm mt-1">{t('allDosesCompletedSub')}</p>
        </section>
      )}

      {/* 3. Night Blindness Bedtime Spotlight (When Nyctalopia Mode is active) */}
      {settings.nightBlindnessMode && (
        <section className="bg-black border-2 border-amber-500 rounded-3xl p-6 sm:p-7 shadow-xl night-glow-card space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-amber-500/40">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-2xl bg-amber-500 text-black flex items-center justify-center font-black">
                <Moon className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl font-black text-amber-400">
                  {t('bedtimeMedications')}
                </h3>
                <p className="text-xs text-amber-200/80 font-medium">
                  {settings.language === 'hi' 
                    ? 'रतौंधी सुरक्षित दृश्य: कम रोशनी में स्पष्टता के लिए एम्बर कंट्रास्ट' 
                    : settings.language === 'bn' 
                    ? 'রাতকানা সুরক্ষিত দৃশ্য: অল্প আলোতে দেখার জন্য অ্যাম্বার বৈসাদৃশ্য' 
                    : 'Scotopic amber glare-free view for night-time medicine safety'}
                </p>
              </div>
            </div>

            <button
              onClick={() => {
                const listText = nightMeds.map(m => `${m.medicineName} (${m.scheduledTime})`).join(', ');
                speak(
                  settings.language === 'hi'
                    ? `रात की दवाइयाँ: ${listText}`
                    : settings.language === 'bn'
                    ? `রাতের ওষুধসমূহ: ${listText}`
                    : `Bedtime medications: ${listText}`
                );
              }}
              className="px-4 py-2 rounded-xl bg-amber-500 text-black font-extrabold text-xs flex items-center gap-1.5 shadow-md self-start sm:self-center"
            >
              <Volume2 className="w-4 h-4" />
              <span>{settings.language === 'hi' ? 'रात की दवाएं सुनें' : settings.language === 'bn' ? 'রাতের ওষুধ শুনুন' : 'Listen to Bedtime Doses'}</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5 pt-1">
            {nightMeds.map((med) => (
              <div
                key={med.id}
                className="p-4 rounded-2xl bg-neutral-950 border border-amber-500/80 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-mono text-xs font-black text-amber-400 bg-neutral-900 px-2 py-0.5 rounded border border-amber-500/50">
                      {med.scheduledTime}
                    </span>
                    {med.status === 'taken' && (
                      <span className="text-[11px] font-bold text-emerald-400 flex items-center gap-0.5">
                        <Check className="w-3.5 h-3.5 stroke-[3]" /> {t('taken')}
                      </span>
                    )}
                  </div>
                  <h4 className="font-black text-amber-300 text-base mt-2">{med.medicineName}</h4>
                  <p className="text-xs text-amber-400/90 font-semibold">{med.dosage} • {med.foodInstruction}</p>
                </div>

                <div className="mt-4 pt-2 border-t border-amber-500/40">
                  {med.status !== 'taken' ? (
                    <button
                      onClick={() => markDoseStatus(med.id, 'taken')}
                      className="w-full py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-black font-black text-xs shadow-md transition-all flex items-center justify-center gap-1.5"
                    >
                      <Check className="w-4 h-4 stroke-[3]" />
                      <span>{t('markTaken')}</span>
                    </button>
                  ) : (
                    <span className="text-xs text-amber-400/60 font-semibold block text-center py-1">
                      {settings.language === 'hi' ? 'सफलतापूर्वक ली गई' : settings.language === 'bn' ? 'নেওয়া হয়েছে' : 'Confirmed Taken'}
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 4. Today's Medicine Routine (Spacious List) */}
      <section className="bg-white rounded-3xl border border-slate-200/80 p-6 sm:p-8 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 pb-4 border-b border-slate-100">
          <div>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900">
              {t('todaysSchedule')}
            </h2>
            <p className="text-slate-500 text-sm font-medium mt-1">
              Tap the green checkmark when you have taken your medicine.
            </p>
          </div>
          <div className="flex items-center space-x-2 text-xs font-bold text-slate-500">
            <span className="px-3 py-1.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 font-extrabold">
              {stats.takenCount} {t('taken')}
            </span>
            <span className="px-3 py-1.5 rounded-full bg-amber-50 text-amber-800 border border-amber-200 font-extrabold">
              {stats.pendingCount} {t('pending')}
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {schedules.map((item) => {
            const isTaken = item.status === 'taken';
            const isSkipped = item.status === 'skipped';

            return (
              <div
                key={item.id}
                className={`relative rounded-2xl p-5 border transition-all flex flex-col justify-between ${
                  isTaken
                    ? 'bg-emerald-50/60 border-emerald-300'
                    : isSkipped
                    ? 'bg-red-50/60 border-red-200 opacity-80'
                    : 'bg-white border-slate-200 hover:border-elder-green-400 shadow-xs'
                }`}
              >
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center space-x-2">
                      <span className="px-2.5 py-1 rounded-lg text-xs font-black uppercase tracking-wider bg-slate-100 text-slate-800 flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-slate-600" />
                        {item.scheduledTime}
                      </span>
                      <span className="text-xs font-semibold text-slate-500">
                        {item.foodInstruction}
                      </span>
                    </div>

                    {isTaken && (
                      <span className="px-2.5 py-1 rounded-full bg-emerald-600 text-white text-xs font-extrabold flex items-center gap-1 shadow-xs">
                        <Check className="w-3.5 h-3.5 stroke-[3]" />
                        {item.takenAt ? `Taken ${item.takenAt}` : t('taken')}
                      </span>
                    )}

                    {isSkipped && (
                      <span className="px-2.5 py-1 rounded-full bg-red-600 text-white text-xs font-extrabold flex items-center gap-1">
                        <X className="w-3.5 h-3.5 stroke-[3]" />
                        {t('missed')}
                      </span>
                    )}
                  </div>

                  <h3 className="text-xl font-black text-slate-900 mt-3 flex items-center gap-2">
                    <Pill className="w-5 h-5 text-elder-green-700" />
                    {item.medicineName}
                  </h3>
                  <p className="text-sm font-bold text-elder-green-800 mt-0.5">
                    {item.dosage} ({item.form})
                  </p>
                  {item.instructions && (
                    <p className="text-xs text-slate-500 font-medium mt-1">
                      {item.instructions}
                    </p>
                  )}
                </div>

                {/* Big Action Button */}
                <div className="mt-5 pt-3 border-t border-slate-100 flex items-center space-x-3">
                  {!isTaken ? (
                    <>
                      <button
                        onClick={() => markDoseStatus(item.id, 'taken')}
                        className="flex-1 flex items-center justify-center space-x-2 py-3 px-4 rounded-xl bg-elder-green-600 hover:bg-elder-green-700 text-white font-extrabold text-sm shadow-sm active:scale-95 transition-all"
                      >
                        <Check className="w-5 h-5 stroke-[3]" />
                        <span>{t('iTookThisPill')}</span>
                      </button>

                      <button
                        onClick={() => setSkipModalItem(item)}
                        className="px-3 py-3 rounded-xl bg-slate-100 hover:bg-red-50 text-slate-600 hover:text-red-700 text-xs font-bold transition-all"
                        title="Skip this dose"
                      >
                        {t('markSkipped')}
                      </button>
                    </>
                  ) : (
                    <button
                      onClick={() => markDoseStatus(item.id, 'pending')}
                      className="text-xs text-slate-500 hover:text-slate-800 underline font-medium py-1"
                    >
                      Undo confirmation (Reset)
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* 5. Two-Column Health Coordinates: Consultations & Family Circle */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* Upcoming Appointments */}
        <section className="bg-white rounded-3xl border border-slate-200/80 p-6 sm:p-7 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-5">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-xl bg-elder-blue-100 text-elder-blue-700 flex items-center justify-center font-bold">
                  <Calendar className="w-6 h-6" />
                </div>
                <h2 className="text-xl font-black text-slate-900">
                  {t('upcomingAppointments')}
                </h2>
              </div>
              <button
                onClick={() => onNavigateTab('appointments')}
                className="text-xs font-bold text-elder-blue-700 hover:underline flex items-center"
              >
                View all <ChevronRight className="w-3.5 h-3.5 ml-0.5" />
              </button>
            </div>

            <div className="space-y-3">
              {upcomingAppointments.length > 0 ? (
                upcomingAppointments.map(apt => (
                  <div key={apt.id} className="p-4 rounded-2xl bg-elder-blue-50/50 border border-elder-blue-200/60">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="font-extrabold text-slate-900 text-base">{apt.doctorName}</h3>
                        <p className="text-xs text-elder-blue-800 font-semibold">{apt.specialty}</p>
                        <p className="text-xs text-slate-600 mt-1">{apt.hospitalName}</p>
                      </div>
                      <div className="text-right">
                        <span className="inline-block px-2.5 py-1 rounded-lg bg-elder-blue-700 text-white text-xs font-bold">
                          {apt.appointmentDate}
                        </span>
                        <p className="text-xs font-bold text-slate-700 mt-1">{apt.appointmentTime}</p>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-slate-500 text-sm font-medium py-4 text-center">No upcoming appointments scheduled.</p>
              )}
            </div>
          </div>

          <div className="mt-5 pt-4 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span>Automatic email reminders active</span>
            <button
              onClick={() => onNavigateTab('appointments')}
              className="text-elder-blue-700 font-bold hover:underline"
            >
              Add Appointment +
            </button>
          </div>
        </section>

        {/* Connected Family & Caregivers (Passcode-based access) */}
        <section className="bg-white rounded-3xl border border-slate-200/80 p-6 sm:p-7 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-5">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center font-bold">
                  <Users className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="text-xl font-black text-slate-900">
                    {t('connectedFamily')}
                  </h2>
                  <p className="text-xs text-slate-500 font-medium">Authorized to view and assist your healthcare</p>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              {relations.map(rel => (
                <div key={rel.id} className="p-3.5 rounded-2xl bg-purple-50/50 border border-purple-200/70 flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 rounded-full bg-purple-200 text-purple-900 flex items-center justify-center font-black text-sm">
                      {rel.memberName.charAt(0)}
                    </div>
                    <div>
                      <h4 className="font-extrabold text-slate-900 text-sm">{rel.memberName}</h4>
                      <p className="text-xs text-purple-700 font-semibold">{rel.relationshipLabel}</p>
                    </div>
                  </div>
                  <span className="px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold">
                    Connected
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-5 pt-4 border-t border-slate-100 flex items-center justify-between">
            <button
              onClick={onOpenPasscodeModal}
              className="px-4 py-2 rounded-xl bg-purple-700 hover:bg-purple-800 text-white font-bold text-xs shadow-xs transition-all"
            >
              Generate Family Passcode +
            </button>
            <button
              onClick={() => onNavigateTab('profile')}
              className="text-xs text-slate-600 hover:underline font-semibold"
            >
              Manage Permissions
            </button>
          </div>
        </section>

      </div>

      {/* 6. Clean Accessibility & Care Support Center */}
      <section className="bg-slate-50 rounded-3xl border border-slate-200/80 p-6 sm:p-8">
        <h3 className="text-lg font-black text-slate-900 mb-4 flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-elder-green-700" />
          <span>Quick Assistance & Accessibility</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          
          <button
            onClick={onOpenVoiceModal}
            className="p-5 rounded-2xl bg-white border border-slate-200 hover:border-elder-green-400 text-left shadow-xs transition-all flex flex-col justify-between group"
          >
            <div>
              <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center mb-3 group-hover:scale-105 transition-transform">
                <Mic className="w-5 h-5" />
              </div>
              <h4 className="font-extrabold text-slate-900 text-base">{t('voiceAssistant')}</h4>
              <p className="text-xs text-slate-500 mt-1">Speak commands or listen to schedules in English, Hindi, or Bengali.</p>
            </div>
            <span className="text-xs font-bold text-emerald-700 mt-4 flex items-center">Open Assistant <ChevronRight className="w-3.5 h-3.5 ml-1" /></span>
          </button>

          <button
            onClick={onOpenSilentModal}
            className="p-5 rounded-2xl bg-white border border-slate-200 hover:border-amber-400 text-left shadow-xs transition-all flex flex-col justify-between group"
          >
            <div>
              <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center mb-3 group-hover:scale-105 transition-transform">
                <MessageSquare className="w-5 h-5" />
              </div>
              <h4 className="font-extrabold text-slate-900 text-base">{t('silentCommunication')}</h4>
              <p className="text-xs text-slate-500 mt-1">Non-verbal communication board with YES, NO, WATER, and PAIN speech output.</p>
            </div>
            <span className="text-xs font-bold text-amber-700 mt-4 flex items-center">Open AAC Board <ChevronRight className="w-3.5 h-3.5 ml-1" /></span>
          </button>

          <button
            onClick={onOpenSosModal}
            className="p-5 rounded-2xl bg-red-50/70 border border-red-200 hover:border-red-400 text-left shadow-xs transition-all flex flex-col justify-between group"
          >
            <div>
              <div className="w-10 h-10 rounded-xl bg-red-100 text-red-700 flex items-center justify-center mb-3 group-hover:scale-105 transition-transform">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <h4 className="font-extrabold text-red-900 text-base">{t('emergencySos')}</h4>
              <p className="text-xs text-red-700 mt-1">Immediate distress broadcast with medical profile sent to all contacts.</p>
            </div>
            <span className="text-xs font-bold text-red-700 mt-4 flex items-center">SOS Emergency <ChevronRight className="w-3.5 h-3.5 ml-1" /></span>
          </button>

        </div>
      </section>

      {/* Skip Reason Modal */}
      {skipModalItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <h3 className="text-xl font-black text-slate-900">
              Skip Dose: {skipModalItem.medicineName}
            </h3>
            <p className="text-sm text-slate-600">
              Please select a reason so your caregiver and family stay informed:
            </p>

            <div className="space-y-2">
              {['Doctor advised to pause', 'Experiencing mild side effects', 'Nausea / upset stomach', 'Forgot / out of medication', 'Other reason'].map((reason) => (
                <label
                  key={reason}
                  className={`flex items-center space-x-3 p-3 rounded-xl border cursor-pointer text-sm font-semibold transition-all ${
                    skipReason === reason ? 'border-red-500 bg-red-50 text-red-900' : 'border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <input
                    type="radio"
                    name="skipReason"
                    value={reason}
                    checked={skipReason === reason}
                    onChange={(e) => setSkipReason(e.target.value)}
                    className="text-red-600 focus:ring-red-500"
                  />
                  <span>{reason}</span>
                </label>
              ))}
            </div>

            <div className="flex space-x-3 pt-4">
              <button
                onClick={() => setSkipModalItem(null)}
                className="flex-1 py-3 rounded-xl border border-slate-300 font-bold text-slate-700 hover:bg-slate-100"
              >
                Cancel
              </button>
              <button
                onClick={handleSkipConfirm}
                className="flex-1 py-3 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold"
              >
                Confirm Skip
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
