import React, { useState, useEffect } from 'react';
import { 
  X, 
  AlertTriangle, 
  PhoneCall, 
  ShieldAlert, 
  CheckCircle2, 
  Volume2, 
  VolumeX, 
  Heart,
  Clock
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useAccessibility } from '../context/AccessibilityContext';

interface EmergencySOSModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const EmergencySOSModal: React.FC<EmergencySOSModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { triggerEmergencySos, currentUser, healthcareProfile, emergencyContacts } = useAuth();
  const { playChime, speak, settings } = useAccessibility();

  const [countdown, setCountdown] = useState<number | null>(null);
  const [isTriggered, setIsTriggered] = useState(false);
  const [isSilent, setIsSilent] = useState(false);
  const [customNote, setCustomNote] = useState('');
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  useEffect(() => {
    if (!isOpen) {
      setCountdown(null);
      setIsTriggered(false);
      setStatusMessage(null);
      return;
    }
  }, [isOpen]);

  // Countdown timer to allow accidental tap cancellation
  useEffect(() => {
    let timer: ReturnType<typeof setTimeout>;
    if (countdown !== null && countdown > 0) {
      timer = setTimeout(() => {
        setCountdown(countdown - 1);
        if (!isSilent) {
          playChime('alert');
        }
      }, 1000);
    } else if (countdown === 0) {
      executeSos();
    }
    return () => clearTimeout(timer);
  }, [countdown, isSilent]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const startCountdown = () => {
    setCountdown(5);
    const msg = settings.language === 'hi'
      ? 'आपातकालीन सहायता पांच सेकंड में शुरू हो रही है। यदि गलती से दबा है तो रद्द करें।'
      : settings.language === 'bn'
      ? 'পাঁচ সেকেন্ডের মধ্যে জরুরি সাহায্য চালু হচ্ছে। ভুলবশত চাপলে বাতিল করুন।'
      : 'Emergency SOS activating in five seconds. Press cancel if this was accidental.';
    speak(msg);
  };

  const cancelCountdown = () => {
    setCountdown(null);
    const msg = settings.language === 'hi'
      ? 'आपातकालीन चेतावनी रद्द कर दी गई है।'
      : settings.language === 'bn'
      ? 'জরুরি সতর্কতা বাতিল করা হয়েছে।'
      : 'Emergency alert cancelled.';
    speak(msg);
  };

  const executeSos = async () => {
    setCountdown(null);
    setIsTriggered(true);

    if (!isSilent) {
      playChime('emergency');
    }

    try {
      const result = await triggerEmergencySos(customNote || 'Patient pressed Emergency SOS button.');
      setStatusMessage(
        `Distress signal successfully broadcasted to ${result.contactCount} emergency contacts and connected family.`
      );
    } catch (e: any) {
      setStatusMessage(`Alert failed: ${e?.message || 'Check notification service'}`);
    }
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl my-6 border-4 border-red-500 max-h-[92vh] flex flex-col justify-between">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-200 sticky top-0 bg-white z-10">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 rounded-2xl bg-red-600 text-white flex items-center justify-center font-black animate-pulse shadow-lg shadow-red-600/30">
              <ShieldAlert className="w-7 h-7" />
            </div>
            <div>
              <h2 className="text-2xl font-black text-slate-900 tracking-tight">
                Emergency Assistance (SOS)
              </h2>
              <p className="text-xs text-red-600 font-bold uppercase tracking-wider">
                Immediate Distress Notification System
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 font-extrabold text-xs transition-all shadow-xs cursor-pointer flex-shrink-0"
            title="Close (ESC)"
          >
            <X className="w-5 h-5 stroke-[2.5]" />
            <span>Close ✕</span>
          </button>
        </div>

        {/* Content */}
        {!isTriggered ? (
          <div className="py-6 space-y-6">
            
            <div className="p-4 rounded-2xl bg-red-50 border border-red-200 text-red-950 text-sm font-medium">
              <p className="font-extrabold text-red-900 text-base mb-1">
                Notice on Emergency Protocol:
              </p>
              <p>
                Pressing this button broadcasts an urgent alert with your location, allergies, and blood group to your designated family contacts and registered caregivers.
              </p>
              <p className="text-xs text-red-700 font-semibold mt-2">
                * Note: ElderCare+ does not guarantee immediate ambulance dispatch. In a life-threatening medical emergency, call 911 or your local ambulance helpline immediately.
              </p>
            </div>

            {/* Optional Custom Note */}
            <div>
              <label className="block text-xs font-black uppercase text-slate-700 mb-1">
                Optional Patient Note (e.g. Fell down, chest pain, dizziness):
              </label>
              <input
                type="text"
                placeholder="What feels wrong? (Optional)"
                value={customNote}
                onChange={(e) => setCustomNote(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-300 font-medium text-sm focus:ring-2 focus:ring-red-600 focus:outline-none"
              />
            </div>

            {/* Silent Mode Toggle */}
            <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-200">
              <div className="flex items-center space-x-2 text-xs font-bold text-slate-700">
                {isSilent ? <VolumeX className="w-4 h-4 text-slate-500" /> : <Volume2 className="w-4 h-4 text-elder-green-700" />}
                <span>Silent Emergency Activation (No Siren Sounds)</span>
              </div>
              <button
                type="button"
                onClick={() => setIsSilent(!isSilent)}
                className={`px-3 py-1 rounded-lg text-xs font-extrabold transition-all ${
                  isSilent ? 'bg-slate-700 text-white' : 'bg-slate-200 text-slate-700'
                }`}
              >
                {isSilent ? 'SILENT (ON)' : 'SOUND (ON)'}
              </button>
            </div>

            {/* Action Buttons */}
            {countdown === null ? (
              <div className="space-y-3 pt-2">
                <button
                  onClick={startCountdown}
                  className="w-full py-4 rounded-2xl bg-gradient-to-r from-red-600 to-rose-700 hover:from-red-700 hover:to-rose-800 text-white font-black text-xl tracking-wide shadow-xl shadow-red-600/30 active:scale-95 transition-all flex items-center justify-center gap-2"
                >
                  <AlertTriangle className="w-6 h-6 animate-bounce" />
                  <span>
                    {settings.language === 'hi' ? 'आपातकालीन सहायता (SOS) शुरू करें' : settings.language === 'bn' ? 'জরুরি সাহায্য (SOS) চালু করুন' : 'ACTIVATE EMERGENCY SOS'}
                  </span>
                </button>

                <button
                  onClick={executeSos}
                  className="w-full py-2.5 text-center text-xs text-red-600 hover:underline font-bold"
                >
                  {settings.language === 'hi' ? 'तुरंत बिना प्रतीक्षा किए भेजें' : settings.language === 'bn' ? 'অপেক্ষা না করে অবিলম্বে পাঠান' : 'Bypass countdown & send immediately'}
                </button>
              </div>
            ) : (
              <div className="text-center py-4 space-y-4">
                <div className="w-24 h-24 rounded-full bg-red-600 text-white font-black text-4xl flex items-center justify-center mx-auto shadow-xl shadow-red-600/40 animate-ping">
                  {countdown}
                </div>
                <p className="text-base font-black text-slate-900">
                  {settings.language === 'hi'
                    ? `${countdown} सेकंड में सहायता संदेश भेजा जा रहा है...`
                    : settings.language === 'bn'
                    ? `${countdown} সেকেন্ডের মধ্যে বিপদ বার্তা পাঠানো হচ্ছে...`
                    : `Transmitting distress alert in ${countdown} seconds...`}
                </p>
                <button
                  onClick={cancelCountdown}
                  className="px-8 py-3 rounded-2xl bg-slate-800 hover:bg-slate-900 text-white font-bold text-sm shadow-md"
                >
                  {settings.language === 'hi' ? 'रद्द करें (गलती से दब गया था)' : settings.language === 'bn' ? 'বাতিল করুন (ভুলবশত চাপ পড়েছিল)' : 'CANCEL ALERT (Accidental Press)'}
                </button>
              </div>
            )}

          </div>
        ) : (
          <div className="py-8 text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <h3 className="text-2xl font-black text-slate-900">
              Emergency Signal Dispatched
            </h3>

            <p className="text-sm font-semibold text-slate-700 max-w-md mx-auto">
              {statusMessage || 'Alert notifications successfully broadcasted.'}
            </p>

            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 text-xs text-left max-w-sm mx-auto space-y-1">
              <p className="font-bold text-slate-700">Patient Emergency Information Included:</p>
              <p className="text-slate-600">• Blood Group: {healthcareProfile.bloodGroup}</p>
              <p className="text-slate-600">• Known Allergies: {healthcareProfile.knownAllergies.join(', ')}</p>
              <p className="text-slate-600">• Primary Contact: {emergencyContacts[0]?.contactName} ({emergencyContacts[0]?.phone})</p>
            </div>

            <button
              onClick={onClose}
              className="mt-6 px-8 py-3 rounded-2xl bg-slate-900 text-white font-bold text-sm"
            >
              Close Emergency Window
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
