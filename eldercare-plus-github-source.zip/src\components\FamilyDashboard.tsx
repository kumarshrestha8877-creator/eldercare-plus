import React, { useState } from 'react';
import { 
  Heart, 
  Users, 
  CheckCircle2, 
  AlertTriangle, 
  Clock, 
  Calendar, 
  Mail, 
  ShieldCheck, 
  Key, 
  ChevronRight, 
  Plus, 
  Bell, 
  Pill,
  Send,
  Eye,
  FileText
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useAccessibility } from '../context/AccessibilityContext';
import { getStoredResendKey } from '../lib/resend';

interface FamilyDashboardProps {
  onOpenPasscodeModal: () => void;
  onOpenSettingsModal: () => void;
  onNavigateTab: (tab: 'medications' | 'appointments' | 'profile') => void;
}

export const FamilyDashboard: React.FC<FamilyDashboardProps> = ({
  onOpenPasscodeModal,
  onOpenSettingsModal,
  onNavigateTab,
}) => {
  const { 
    currentUser, 
    healthcareProfile, 
    schedules, 
    appointments, 
    relations, 
    redeemPasscode, 
    adherencePercentage, 
    adherenceStreak,
    stats,
    updateRelationPermissions,
    triggerScheduledEmailCheck
  } = useAuth();

  const { playChime, speak } = useAccessibility();
  const [passcodeKey, setPasscodeKey] = useState('');
  const [passcodeStatus, setPasscodeStatus] = useState<{ type: 'idle' | 'success' | 'error'; message: string }>({
    type: 'idle',
    message: '',
  });
  const [isRedeeming, setIsRedeeming] = useState(false);
  const [emailCheckLoading, setEmailCheckLoading] = useState(false);
  const [emailCheckResult, setEmailCheckResult] = useState<string | null>(null);

  const resendKey = getStoredResendKey();

  // Find user's active relation
  const currentRelation = relations.find(r => r.memberEmail === currentUser.email && r.status === 'active') || relations[0];

  const handleRedeemPasscode = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!passcodeKey.trim()) return;

    setIsRedeeming(true);
    setPasscodeStatus({ type: 'idle', message: '' });

    const result = await redeemPasscode(passcodeKey);
    setIsRedeeming(false);

    if (result.success) {
      setPasscodeStatus({ type: 'success', message: result.message });
      setPasscodeKey('');
      speak(result.message);
    } else {
      setPasscodeStatus({ type: 'error', message: result.message });
      playChime('alert');
    }
  };

  const handleTriggerEmailTest = async () => {
    setEmailCheckLoading(true);
    setEmailCheckResult(null);
    try {
      const count = await triggerScheduledEmailCheck();
      setEmailCheckResult(`Successfully checked schedules! Sent ${count} reminder emails.`);
    } catch (e: any) {
      setEmailCheckResult(`Email dispatch error: ${e?.message || 'Check API key'}`);
    } finally {
      setEmailCheckLoading(false);
    }
  };

  return (
    <div className="space-y-8 pb-16">
      
      {/* 1. Header with Loved One Switcher & Status Banner */}
      <section className="bg-gradient-to-r from-elder-blue-700 via-elder-blue-800 to-sky-950 text-white rounded-3xl p-6 sm:p-8 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-white/15 backdrop-blur text-sky-200 text-xs font-bold uppercase tracking-wider">
              <Users className="w-3.5 h-3.5" />
              <span>Family Caregiver Portal</span>
            </div>
            
            <h1 className="text-3xl sm:text-4xl font-black text-white">
              Monitoring: Eleanor Vance
            </h1>
            
            <p className="text-sky-100 text-sm sm:text-base font-medium max-w-xl">
              Connected as <span className="font-bold underline">{currentUser?.fullName || (currentUser as any)?.name || 'Family Member'} ({currentRelation?.relationshipLabel || 'Daughter'})</span>. 
              Keeping Mom safe, healthy, and on track with her medications.
            </p>
          </div>

          {/* Quick Metrics Badges */}
          <div className="flex items-center gap-4 bg-white/10 backdrop-blur-md rounded-2xl p-4 border border-white/20">
            <div className="text-center px-3">
              <span className="text-2xl sm:text-3xl font-black text-white">{adherencePercentage}%</span>
              <p className="text-[11px] uppercase tracking-wider text-sky-200 font-bold mt-0.5">Adherence</p>
            </div>
            <div className="w-px h-8 bg-white/20" />
            <div className="text-center px-3">
              <span className="text-2xl sm:text-3xl font-black text-amber-300">{adherenceStreak}d</span>
              <p className="text-[11px] uppercase tracking-wider text-sky-200 font-bold mt-0.5">Streak</p>
            </div>
            <div className="w-px h-8 bg-white/20" />
            <div className="text-center px-3">
              <span className="text-2xl sm:text-3xl font-black text-emerald-300">{stats.takenCount}/{stats.totalScheduled}</span>
              <p className="text-[11px] uppercase tracking-wider text-sky-200 font-bold mt-0.5">Taken Today</p>
            </div>
          </div>
        </div>
      </section>

      {/* 2. Missed Dose Alert Notification (Urgent Family Awareness) */}
      {stats.missedCount > 0 && (
        <section className="bg-red-50 border-2 border-red-300 rounded-3xl p-5 shadow-sm flex items-start space-x-4">
          <div className="p-3 bg-red-600 text-white rounded-2xl flex-shrink-0">
            <AlertTriangle className="w-6 h-6" />
          </div>
          <div className="flex-1">
            <h2 className="text-lg font-black text-red-900">
              Attention Required: {stats.missedCount} Prescribed Dose(s) Were Skipped Today
            </h2>
            <p className="text-sm text-red-700 font-medium mt-0.5">
              An automated email alert was recorded for family members. Please check in with Eleanor to review reason and tolerance.
            </p>
          </div>
          <button
            onClick={() => onNavigateTab('medications')}
            className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-xl shadow-sm self-center"
          >
            Review Log
          </button>
        </section>
      )}

      {/* 3. Passcode Connection Form (Core Hackathon Requirement: Connect to Profile) */}
      <section className="bg-white rounded-3xl border border-slate-200/80 p-6 sm:p-7 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="max-w-xl">
            <div className="flex items-center space-x-2 text-elder-blue-700 font-bold text-xs uppercase tracking-wider mb-1">
              <Key className="w-4 h-4" />
              <span>Passcode-Based Family Access</span>
            </div>
            <h2 className="text-2xl font-black text-slate-900">Connect to an Elderly Loved One</h2>
            <p className="text-slate-600 text-sm font-medium mt-1">
              Enter the unique, secure passcode generated by the elderly family member to request access to their healthcare profile.
            </p>
          </div>

          <form onSubmit={handleRedeemPasscode} className="flex-1 max-w-md w-full">
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="e.g. FAMILY-8492"
                value={passcodeKey}
                onChange={(e) => setPasscodeKey(e.target.value)}
                className="flex-1 px-4 py-3 rounded-xl border border-slate-300 font-mono font-bold uppercase tracking-wider text-base focus:ring-2 focus:ring-elder-blue-500 focus:outline-none"
              />
              <button
                type="submit"
                disabled={isRedeeming}
                className="px-6 py-3 rounded-xl bg-elder-blue-700 hover:bg-elder-blue-800 text-white font-bold text-sm shadow-md transition-all disabled:opacity-50"
              >
                {isRedeeming ? 'Verifying...' : 'Connect'}
              </button>
            </div>

            {passcodeStatus.message && (
              <p className={`text-xs font-bold mt-2 ${
                passcodeStatus.type === 'success' ? 'text-emerald-700' : 'text-red-600'
              }`}>
                {passcodeStatus.message}
              </p>
            )}
          </form>
        </div>
      </section>

      {/* 4. Active Permissions & Role Config Inspector */}
      {currentRelation && (
        <section className="bg-slate-50 border border-slate-200 rounded-3xl p-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
            <div>
              <span className="text-xs uppercase font-extrabold tracking-wider text-slate-500">Security & Permissions</span>
              <h2 className="text-xl font-black text-slate-900">Your Configured Healthcare Permissions</h2>
            </div>
            <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-extrabold bg-emerald-100 text-emerald-800">
              <ShieldCheck className="w-3.5 h-3.5 mr-1" />
              Verified Active Connection
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pt-4">
            <div className="p-3.5 bg-white rounded-2xl border border-slate-200 flex items-center justify-between">
              <span className="text-xs font-bold text-slate-700">Manage Medications</span>
              <span className={`text-xs font-extrabold px-2 py-0.5 rounded-full ${
                currentRelation.canManageMedications ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-500'
              }`}>
                {currentRelation.canManageMedications ? 'Allowed' : 'View Only'}
              </span>
            </div>

            <div className="p-3.5 bg-white rounded-2xl border border-slate-200 flex items-center justify-between">
              <span className="text-xs font-bold text-slate-700">Manage Appointments</span>
              <span className={`text-xs font-extrabold px-2 py-0.5 rounded-full ${
                currentRelation.canManageAppointments ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-500'
              }`}>
                {currentRelation.canManageAppointments ? 'Allowed' : 'View Only'}
              </span>
            </div>

            <div className="p-3.5 bg-white rounded-2xl border border-slate-200 flex items-center justify-between">
              <span className="text-xs font-bold text-slate-700">Missed Dose Email Alerts</span>
              <button
                onClick={() => updateRelationPermissions(currentRelation.id, {
                  ...currentRelation,
                  notifyOnMissedDose: !currentRelation.notifyOnMissedDose,
                })}
                className={`text-xs font-extrabold px-2.5 py-1 rounded-full transition-all ${
                  currentRelation.notifyOnMissedDose ? 'bg-elder-blue-100 text-elder-blue-800' : 'bg-slate-200 text-slate-600'
                }`}
              >
                {currentRelation.notifyOnMissedDose ? 'Active (ON)' : 'Disabled'}
              </button>
            </div>

            <div className="p-3.5 bg-white rounded-2xl border border-slate-200 flex items-center justify-between">
              <span className="text-xs font-bold text-slate-700">Emergency SOS Alerts</span>
              <button
                onClick={() => updateRelationPermissions(currentRelation.id, {
                  ...currentRelation,
                  notifyOnSos: !currentRelation.notifyOnSos,
                })}
                className={`text-xs font-extrabold px-2.5 py-1 rounded-full transition-all ${
                  currentRelation.notifyOnSos ? 'bg-red-100 text-red-800' : 'bg-slate-200 text-slate-600'
                }`}
              >
                {currentRelation.notifyOnSos ? 'Active (ON)' : 'Disabled'}
              </button>
            </div>
          </div>
        </section>
      )}

      {/* 5. Live Medication Adherence Feed */}
      <section className="bg-white rounded-3xl border border-slate-200/80 p-6 sm:p-8 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <h2 className="text-2xl font-black text-slate-900">Today's Medication Tracking</h2>
            <p className="text-slate-500 text-sm font-medium">Real-time confirmation status for Eleanor Vance</p>
          </div>

          <div className="flex items-center space-x-3">
            {currentRelation?.canManageMedications && (
              <button
                onClick={() => onNavigateTab('medications')}
                className="inline-flex items-center space-x-1.5 px-4 py-2.5 rounded-xl bg-elder-green-700 hover:bg-elder-green-800 text-white font-bold text-xs shadow-sm"
              >
                <Plus className="w-4 h-4" />
                <span>Add / Edit Medicine</span>
              </button>
            )}

            <button
              onClick={handleTriggerEmailTest}
              disabled={emailCheckLoading}
              title="Test the automated email reminder check"
              className="inline-flex items-center space-x-1.5 px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs border border-slate-300"
            >
              <Send className="w-3.5 h-3.5 text-elder-blue-700" />
              <span>{emailCheckLoading ? 'Checking...' : 'Run Email Reminder Check'}</span>
            </button>
          </div>
        </div>

        {emailCheckResult && (
          <div className="mb-4 p-3 rounded-xl bg-elder-blue-50 border border-elder-blue-200 text-elder-blue-900 text-xs font-semibold flex items-center justify-between">
            <span>{emailCheckResult}</span>
            <button onClick={() => setEmailCheckResult(null)} className="text-slate-400 hover:text-slate-600">×</button>
          </div>
        )}

        <div className="divide-y divide-slate-100">
          {schedules.map((item) => (
            <div key={item.id} className="py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-start space-x-3">
                <div className={`p-2.5 rounded-xl flex-shrink-0 ${
                  item.status === 'taken' ? 'bg-emerald-100 text-emerald-800' :
                  item.status === 'skipped' ? 'bg-red-100 text-red-800' : 'bg-slate-100 text-slate-600'
                }`}>
                  <Pill className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-extrabold text-slate-900 text-base">{item.medicineName}</h4>
                  <p className="text-xs text-slate-500 font-medium">
                    {item.dosage} • {item.scheduledTime} • {item.foodInstruction}
                  </p>
                </div>
              </div>

              <div className="flex items-center space-x-3 self-end sm:self-center">
                {item.status === 'taken' ? (
                  <span className="inline-flex items-center px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-extrabold">
                    <CheckCircle2 className="w-3.5 h-3.5 mr-1" />
                    Confirmed Taken at {item.takenAt}
                  </span>
                ) : item.status === 'skipped' ? (
                  <span className="inline-flex items-center px-3 py-1 rounded-full bg-red-100 text-red-800 text-xs font-extrabold">
                    <AlertTriangle className="w-3.5 h-3.5 mr-1" />
                    Skipped ({item.skippedReason})
                  </span>
                ) : (
                  <span className="inline-flex items-center px-3 py-1 rounded-full bg-amber-100 text-amber-800 text-xs font-bold">
                    <Clock className="w-3.5 h-3.5 mr-1" />
                    Pending ({item.scheduledTime})
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 6. Upcoming Doctor Appointments Card */}
      <section className="bg-white rounded-3xl border border-slate-200/80 p-6 sm:p-8 shadow-sm">
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-elder-blue-100 text-elder-blue-800 flex items-center justify-center font-bold">
              <Calendar className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-2xl font-black text-slate-900">Medical Consultations</h2>
              <p className="text-slate-500 text-xs font-medium">Coordinate upcoming visits and email notifications</p>
            </div>
          </div>

          <button
            onClick={() => onNavigateTab('appointments')}
            className="px-4 py-2 rounded-xl bg-elder-blue-700 hover:bg-elder-blue-800 text-white font-bold text-xs shadow-sm flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            <span>Schedule Appointment</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {appointments.slice(0, 2).map((apt) => (
            <div key={apt.id} className="p-5 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col justify-between">
              <div>
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-extrabold text-slate-900 text-base">{apt.doctorName}</h3>
                    <p className="text-xs font-semibold text-elder-blue-800">{apt.specialty}</p>
                  </div>
                  <span className="px-2.5 py-1 rounded-lg bg-elder-blue-700 text-white text-xs font-bold">
                    {apt.appointmentDate}
                  </span>
                </div>
                <p className="text-xs text-slate-600 mt-2 font-medium">{apt.hospitalName}</p>
                {apt.notes && (
                  <p className="text-xs text-slate-500 mt-1 italic">Note: {apt.notes}</p>
                )}
              </div>

              <div className="mt-4 pt-3 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
                <span>Time: <strong>{apt.appointmentTime}</strong></span>
                <span className="text-emerald-700 font-bold">Email Reminder Active</span>
              </div>
            </div>
          ))}
        </div>
      </section>

    </div>
  );
};
