import React, { useState, useEffect } from 'react';
import { 
  ArrowDown, 
  ArrowUp, 
  ArrowLeft, 
  ArrowRight, 
  X, 
  Check, 
  Pill, 
  Calendar, 
  Lock, 
  AlertTriangle, 
  Sparkles, 
  Volume2, 
  ChevronRight, 
  ChevronLeft,
  Compass,
  Plus,
  Play
} from 'lucide-react';
import { useAccessibility } from '../context/AccessibilityContext';
import { AppTab } from './Navbar';

interface TourStep {
  id: string;
  tab: AppTab;
  title: {
    en: string;
    hi: string;
    bn: string;
  };
  subtitle: {
    en: string;
    hi: string;
    bn: string;
  };
  description: {
    en: string;
    hi: string;
    bn: string;
  };
  voiceText: {
    en: string;
    hi: string;
    bn: string;
  };
  targetArea: 'dashboard_dose' | 'nav_medications' | 'add_medicine_button' | 'nav_appointments' | 'nav_profile' | 'sos_button';
  arrowPosition: 'top' | 'bottom' | 'left' | 'right';
  badge: string;
  actionHint?: {
    en: string;
    hi: string;
    bn: string;
  };
}

const TOUR_STEPS: TourStep[] = [
  {
    id: 'step-dashboard',
    tab: 'dashboard',
    badge: 'Step 1 of 6: Daily Care',
    title: {
      en: 'Your Daily Medicine Routine',
      hi: 'आपकी दैनिक दवाओं का समय',
      bn: 'আপনার প্রতিদিনের ওষুধের রুটিন'
    },
    subtitle: {
      en: 'Track today\'s upcoming doses and adherence streak',
      hi: 'आज की आने वाली खुराक और दवा लेने का क्रम देखें',
      bn: 'আজকের আসন্ন ডোজ এবং ওষুধ গ্রহণের ধারাবাহিকতা দেখুন'
    },
    description: {
      en: 'The dashboard highlights your next upcoming medication. Once you take the pill, simply tap "Mark as Taken" to record adherence and keep family members updated in real-time.',
      hi: 'डैशबोर्ड आपकी अगली आने वाली दवा दिखाता है। दवा लेने के बाद बस "दवा ले ली" पर टैप करें ताकि परिवार को तुरंत जानकारी मिल सके।',
      bn: 'ড্যাশবোর্ড আপনার পরবর্তী আসন্ন ওষুধ প্রদর্শন করে। ওষুধ খাওয়ার পর "ওষুধ খেয়েছি" চাপুন যাতে পরিবার তাৎক্ষণিক আপডেট পায়।'
    },
    voiceText: {
      en: 'Welcome to ElderCare Plus. This is your daily routine dashboard. Your next medicine appears here with meal instructions.',
      hi: 'एल्डरकेयर प्लस में आपका स्वागत है। यह आपका दैनिक डैशबोर्ड है। आपकी अगली दवा भोजन निर्देश के साथ यहाँ दिखाई देती है।',
      bn: 'এল্ডারকেয়ার প্লাসে স্বাগতম। এটি আপনার দৈনন্দিন ড্যাশবোর্ড। পরবর্তী ওষুধটি খাবারের নির্দেশসহ এখানে প্রদর্শিত হবে।'
    },
    targetArea: 'dashboard_dose',
    arrowPosition: 'bottom',
    actionHint: {
      en: 'Tap "Mark as Taken" after taking your pill',
      hi: 'दवा लेने के बाद "दवा ले ली" पर टैप करें',
      bn: 'ওষুধ গ্রহণের পর "ওষুধ খেয়েছি" চাপুন'
    }
  },
  {
    id: 'step-nav-meds',
    tab: 'medications',
    badge: 'Step 2 of 6: Medication Hub',
    title: {
      en: 'Medication Management Tab',
      hi: 'दवाइयाँ प्रबंधन टैब',
      bn: 'ওষুধ ব্যবস্থাপনা ট্যাব'
    },
    subtitle: {
      en: 'Where all prescriptions and schedules live',
      hi: 'यहाँ आपकी सभी दवाइयाँ और समय सारणी मौजूद हैं',
      bn: 'যেখানে আপনার সমস্ত প্রেসক্রিপশন ও সময়সূচি সংরক্ষিত থাকে'
    },
    description: {
      en: 'Click the "Medications" tab at any time to see full prescriptions, daily morning/afternoon/night schedules, and refill warnings.',
      hi: 'अपनी सभी निर्धारित दवाओं, सुबह/दोपहर/रात के समय और स्टॉक की स्थिति देखने के लिए किसी भी समय "दवाइयाँ" टैब पर क्लिक करें।',
      bn: 'আপনার সমস্ত প্রেসক্রিপশন এবং সকাল, দুপুর ও রাতের সময়সূচি দেখতে যেকোনো সময় "ওষুধ" ট্যাবে যান।'
    },
    voiceText: {
      en: 'The Medications tab allows you and your family to view all prescriptions and daily schedules.',
      hi: 'दवाइयाँ टैब आपको और आपके परिवार को सभी नुस्खे और समय देखने की सुविधा देता है।',
      bn: 'ওষুধ ট্যাবের মাধ্যমে আপনি ও আপনার পরিবার সমস্ত প্রেসক্রিপশন দেখতে পারবেন।'
    },
    targetArea: 'nav_medications',
    arrowPosition: 'top'
  },
  {
    id: 'step-add-medicine',
    tab: 'medications',
    badge: 'Step 3 of 6: How to Add Medicines',
    title: {
      en: 'How to Add New Medicines (Key Feature)',
      hi: 'नई दवा कैसे जोड़ें (मुख्य सुविधा)',
      bn: 'নতুন ওষুধ কীভাবে যুক্ত করবেন (প্রধান ফিচার)'
    },
    subtitle: {
      en: 'Add any pill, drops, or syrup in 3 easy steps',
      hi: 'सिर्फ 3 आसान चरणों में कोई भी दवा, ड्रॉप्स या सिरप जोड़ें',
      bn: 'মাত্র ৩টি সহজ ধাপে যেকোনো ওষুধ বা ড্রপ যোগ করুন'
    },
    description: {
      en: 'Click the green "+ Add New Medicine" button! A simple form appears where you enter: 1) Medicine Name (e.g. Metformin), 2) Dosage (e.g. 500mg), 3) Scheduled Times (e.g. 08:00 AM & 08:00 PM), and 4) Food Rule (Before/With/After meals). It will instantly appear on your daily schedule!',
      hi: 'हरे रंग के "+ नई दवा जोड़ें" बटन पर क्लिक करें! एक सरल फॉर्म खुलेगा जहाँ आप भरेंगे: 1) दवा का नाम, 2) खुराक (उदा. 500mg), 3) समय (उदा. सुबह 8 बजे), और 4) भोजन निर्देश (खाने से पहले या बाद)। यह तुरंत आपके दैनिक समय में जुड़ जाएगी!',
      bn: 'সবুজ "+ নতুন ওষুধ যোগ করুন" বোতামে চাপুন! একটি ফর্ম আসবে যেখানে ওষুধের নাম, ডোজ, গ্রহণের সময় এবং খাবারের নিয়ম দিয়ে সেভ করলেই ওষুধ যুক্ত হয়ে যাবে!'
    },
    voiceText: {
      en: 'To add a medicine, tap the green Add New Medicine button. Fill in the medicine name, dosage, time, and meal instruction.',
      hi: 'नई दवा जोड़ने के लिए हरे बटन पर क्लिक करें। दवा का नाम, खुराक, समय और भोजन निर्देश दर्ज करें।',
      bn: 'নতুন ওষুধ যুক্ত করতে সবুজ বোতামে চাপুন। ওষুধের নাম, ডোজ এবং সময় লিখে সেভ করুন।'
    },
    targetArea: 'add_medicine_button',
    arrowPosition: 'bottom',
    actionHint: {
      en: 'Click "+ Add New Medicine" above to try adding a pill',
      hi: 'दवा जोड़ने के लिए ऊपर "+ नई दवा जोड़ें" पर क्लिक करें',
      bn: 'ওষুধ যোগ করতে উপরের "+ নতুন ওষুধ যোগ করুন" বোতামে চাপুন'
    }
  },
  {
    id: 'step-appointments',
    tab: 'appointments',
    badge: 'Step 4 of 6: Doctor Visits',
    title: {
      en: 'Doctor Appointments & Email Reminders',
      hi: 'डॉक्टर की मुलाकातें व ईमेल स्मरण',
      bn: 'ডাক্তারের সাক্ষাতকার ও ইমেল অনুস্মারক'
    },
    subtitle: {
      en: 'Never miss a clinic consultation or follow-up',
      hi: 'डॉक्टर की जांच या क्लिनिक की मुलाकात कभी न भूलें',
      bn: 'কখনোই ডাক্তারের পরামর্শ বা ফলো-আপ মিস করবেন না'
    },
    description: {
      en: 'Under the Appointments tab, you can schedule upcoming checkups with Dr. Rajesh Sharma or any specialist. Automated email reminders are sent to you and your family before the visit.',
      hi: 'अपॉइंटमेंट्स टैब में आप डॉक्टर के साथ मुलाकातों का समय तय कर सकते हैं। मुलाकात से पहले आपको और आपके परिवार को ईमेल रिमाइंडर भेजा जाता है।',
      bn: 'অ্যাপয়েন্টমেন্ট ট্যাবে ডাক্তারের সাথে সাক্ষাতকারের সময়সূচি ঠিক করতে পারেন এবং স্বয়ংক্রিয় ইমেল অনুস্মারক পাবেন।'
    },
    voiceText: {
      en: 'The Appointments tab tracks your doctor visits and automatically sends email reminders to your family.',
      hi: 'अपॉइंटमेंट्स टैब आपकी डॉक्टर मुलाकातों को ट्रैक करता है और परिवार को ईमेल रिमाइंडर भेजता है।',
      bn: 'অ্যাপয়েন্টমেন্ট ট্যাব আপনার ডাক্তারের সাক্ষাতকার ট্র্যাক করে এবং পরিবারকে ইমেল অনুস্মারক পাঠায়।'
    },
    targetArea: 'nav_appointments',
    arrowPosition: 'top'
  },
  {
    id: 'step-profile-passcodes',
    tab: 'profile',
    badge: 'Step 5 of 6: Family Access',
    title: {
      en: 'Shared Health Profile & Family Passcodes',
      hi: 'साझा स्वास्थ्य प्रोफ़ाइल व पारिवारिक पासकोड',
      bn: 'শেয়ার্ড হেলথ প্রোফাইল ও ফ্যামিলি পাসকোড'
    },
    subtitle: {
      en: 'Share secure access with your loved ones using passcodes',
      hi: 'पासकोड का उपयोग करके अपने परिजनों के साथ सुरक्षित पहुँच साझा करें',
      bn: 'পাসকোড দিয়ে প্রিয়জনদের সাথে নিরাপদ অ্যাক্সেস শেয়ার করুন'
    },
    description: {
      en: 'ElderCare+ allows you to generate access passcodes like FAMILY-8492 or CARE-5120. Give this code to your daughter, son, or visiting nurse so they can view your health records and manage medications from their own devices.',
      hi: 'एल्डरकेयर+ आपको FAMILY-8492 या CARE-5120 जैसे एक्सेस पासकोड बनाने की सुविधा देता है। यह कोड अपने बेटे, बेटी या नर्स को दें ताकि वे भी आपकी देखभाल में मदद कर सकें।',
      bn: 'পাসকোড জেনারেট করে আপনার ছেলে, মেয়ে বা নার্সকে দিন যাতে তারা দূর থেকেও আপনার স্বাস্থ্যসেবা পরিচালনা করতে পারে।'
    },
    voiceText: {
      en: 'In the Health Profile tab, you can generate family passcodes so your children and nurses can help manage your care.',
      hi: 'हेल्थ प्रोफाइल टैब में आप पारिवारिक पासकोड बना सकते हैं ताकि आपके बच्चे और नर्स भी आपकी सहायता कर सकें।',
      bn: 'হেলথ প্রোফাইল ট্যাবে ফ্যামিলি পাসকোড তৈরি করে আপনার প্রিয়জনদের সাথে যুক্ত হতে পারেন।'
    },
    targetArea: 'nav_profile',
    arrowPosition: 'top'
  },
  {
    id: 'step-sos-voice',
    tab: 'dashboard',
    badge: 'Step 6 of 6: Safety & Voice Assist',
    title: {
      en: 'Voice Assistant & 1-Tap Emergency SOS',
      hi: 'ध्वनि सहायक और 1-टैप आपातकालीन SOS',
      bn: 'ভয়েস সহকারী ও জরুরি এসওএস'
    },
    subtitle: {
      en: 'Accessibility and 24/7 emergency peace of mind',
      hi: 'आसान ध्वनि सहायता और 24 घंटे आपातकालीन सुरक्षा',
      bn: 'সহজ ভয়েস সহায়তা এবং ২৪ ঘণ্টা জরুরি সুরক্ষা'
    },
    description: {
      en: 'Use the floating Voice Help button to ask questions in your language or trigger silent card messages. In an emergency, tap the red SOS button to instantly alert all designated contacts with siren alarm and automated emails!',
      hi: 'अपनी भाषा में प्रश्न पूछने के लिए फ्लोटिंग वॉइस हेल्प बटन का उपयोग करें। किसी आपात स्थिति में, लाल SOS बटन दबाएं जिससे तुरंत अलार्म बजेगा और परिजनों को संदेश पहुंचेगा!',
      bn: 'ভয়েস হেল্প বোতাম দিয়ে আপনার ভাষায় কথা বলুন। কোনো জরুরি অবস্থায় লাল এসওএস বোতামে চাপ দিন।'
    },
    voiceText: {
      en: 'You are all set! Use Voice Help for audio assistance, and the red SOS button for immediate emergency help. Stay healthy!',
      hi: 'आपकी मार्गदर्शिका पूरी हुई! ध्वनि सहायता के लिए वॉइस हेल्प और आपात स्थिति में लाल SOS बटन का उपयोग करें। स्वस्थ रहें!',
      bn: 'আপনার ট্যুর সম্পন্ন হয়েছে! ভয়েস হেল্প এবং লাল এসওএস বোতামের সাহায্যে নিরাপদ থাকুন।'
    },
    targetArea: 'sos_button',
    arrowPosition: 'bottom'
  }
];

interface GuidedTourModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigateTab: (tab: AppTab) => void;
  onOpenAddMedicineModal?: () => void;
}

export const GuidedTourModal: React.FC<GuidedTourModalProps> = ({
  isOpen,
  onClose,
  onNavigateTab,
  onOpenAddMedicineModal,
}) => {
  const { settings, speak, playChime } = useAccessibility();
  const [currentStepIndex, setCurrentStepIndex] = useState(0);

  const step = TOUR_STEPS[currentStepIndex];

  // When step changes, navigate to the step's tab and speak narration
  useEffect(() => {
    if (!isOpen) return;
    onNavigateTab(step.tab);

    const textToSpeak = step.voiceText[settings.language] || step.voiceText.en;
    speak(textToSpeak);
  }, [currentStepIndex, isOpen, settings.language]);

  if (!isOpen) return null;

  const handleNext = () => {
    playChime('click');
    if (currentStepIndex < TOUR_STEPS.length - 1) {
      setCurrentStepIndex(currentStepIndex + 1);
    } else {
      handleFinish();
    }
  };

  const handlePrev = () => {
    playChime('click');
    if (currentStepIndex > 0) {
      setCurrentStepIndex(currentStepIndex - 1);
    }
  };

  const handleFinish = () => {
    playChime('success');
    speak(settings.language === 'hi' ? 'मार्गदर्शिका समाप्त। अब आप अपनी दवाइयाँ प्रबंधित कर सकते हैं।' : settings.language === 'bn' ? 'ট্যুর সম্পন্ন হয়েছে।' : 'Tour complete. You are ready to manage your health routine.');
    onClose();
  };

  const handleTryAddMedicine = () => {
    onClose();
    onNavigateTab('medications');
    if (onOpenAddMedicineModal) {
      setTimeout(() => {
        onOpenAddMedicineModal();
      }, 300);
    }
  };

  const currentTitle = step.title[settings.language] || step.title.en;
  const currentSubtitle = step.subtitle[settings.language] || step.subtitle.en;
  const currentDesc = step.description[settings.language] || step.description.en;
  const currentHint = step.actionHint ? (step.actionHint[settings.language] || step.actionHint.en) : null;

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-end sm:justify-center items-center p-3 sm:p-6 bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-200">
      
      {/* Visual Bouncing Arrow Indicator */}
      <div className="w-full max-w-xl mx-auto flex flex-col items-center pointer-events-none mb-3">
        {step.arrowPosition === 'bottom' && (
          <div className="flex flex-col items-center animate-bounce">
            <span className="px-3 py-1 rounded-full bg-amber-400 text-slate-950 font-black text-xs shadow-lg tracking-wider uppercase mb-1">
              👇 Look Here
            </span>
            <div className="w-12 h-12 rounded-full bg-amber-400 text-slate-950 flex items-center justify-center shadow-2xl ring-4 ring-amber-300/50">
              <ArrowDown className="w-7 h-7 stroke-[3]" />
            </div>
          </div>
        )}

        {step.arrowPosition === 'top' && (
          <div className="flex flex-col items-center animate-bounce mb-2">
            <div className="w-12 h-12 rounded-full bg-amber-400 text-slate-950 flex items-center justify-center shadow-2xl ring-4 ring-amber-300/50">
              <ArrowUp className="w-7 h-7 stroke-[3]" />
            </div>
            <span className="px-3 py-1 rounded-full bg-amber-400 text-slate-950 font-black text-xs shadow-lg tracking-wider uppercase mt-1">
              👆 Look at Header Tab
            </span>
          </div>
        )}
      </div>

      {/* Tour Card Box */}
      <div 
        className="relative w-full max-w-xl bg-white rounded-3xl shadow-2xl border-2 border-elder-green-500 p-6 sm:p-8 animate-in zoom-in-95 duration-200"
        role="dialog"
        aria-labelledby="tour-step-title"
      >
        {/* Header Ribbon */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center space-x-2">
            <span className="px-3 py-1 rounded-full bg-elder-green-100 text-elder-green-900 font-black text-xs uppercase tracking-wide border border-elder-green-200">
              {step.badge}
            </span>
            <button
              onClick={() => {
                playChime('click');
                speak(step.voiceText[settings.language] || step.voiceText.en);
              }}
              title="Listen to instruction audio"
              className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
              aria-label="Replay audio guidance"
            >
              <Volume2 className="w-4 h-4 text-elder-green-700" />
            </button>
          </div>

          <button
            onClick={() => {
              playChime('click');
              onClose();
            }}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-all"
            aria-label="Close Tour"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step Content */}
        <div className="mt-4 space-y-2">
          <h2 id="tour-step-title" className="text-2xl font-black text-slate-900 tracking-tight">
            {currentTitle}
          </h2>
          <p className="text-sm font-bold text-elder-green-700">
            {currentSubtitle}
          </p>
          <p className="text-sm text-slate-600 leading-relaxed pt-1">
            {currentDesc}
          </p>

          {currentHint && (
            <div className="mt-3 p-3 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 flex items-center space-x-2.5 text-xs font-bold">
              <Sparkles className="w-4 h-4 text-amber-600 shrink-0" />
              <span>{currentHint}</span>
            </div>
          )}
        </div>

        {/* Special Action on Step 3: Direct Button to open Add Medicine Modal */}
        {step.id === 'step-add-medicine' && onOpenAddMedicineModal && (
          <div className="mt-4 pt-3 border-t border-slate-100">
            <button
              onClick={handleTryAddMedicine}
              className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-elder-green-700 to-elder-green-800 hover:from-elder-green-800 hover:to-elder-green-900 text-white font-black text-sm flex items-center justify-center space-x-2 shadow-lg shadow-elder-green-700/20 active:scale-95 transition-all"
            >
              <Plus className="w-5 h-5" />
              <span>Try Adding Your First Medicine Now</span>
            </button>
          </div>
        )}

        {/* Stepper Progress & Buttons */}
        <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between gap-3">
          
          {/* Progress Dots */}
          <div className="flex items-center space-x-1.5">
            {TOUR_STEPS.map((_, idx) => (
              <span
                key={idx}
                className={`h-2 rounded-full transition-all ${
                  idx === currentStepIndex
                    ? 'w-6 bg-elder-green-600'
                    : 'w-2 bg-slate-200'
                }`}
              />
            ))}
          </div>

          {/* Action Buttons */}
          <div className="flex items-center space-x-2">
            {currentStepIndex > 0 && (
              <button
                onClick={handlePrev}
                className="px-3.5 py-2 rounded-xl text-xs font-bold text-slate-700 hover:bg-slate-100 border border-slate-200 flex items-center gap-1 transition-all"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>Back</span>
              </button>
            )}

            <button
              onClick={handleNext}
              className="px-5 py-2.5 rounded-xl text-xs font-black bg-elder-green-700 hover:bg-elder-green-800 text-white shadow-md flex items-center gap-1.5 transition-all active:scale-95"
            >
              <span>{currentStepIndex === TOUR_STEPS.length - 1 ? 'Finish Tour ✓' : 'Next Step →'}</span>
            </button>
          </div>

        </div>

      </div>

    </div>
  );
};
