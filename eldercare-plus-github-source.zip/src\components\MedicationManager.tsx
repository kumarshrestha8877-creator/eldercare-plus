import React, { useState, useEffect } from 'react';
import { 
  Pill, 
  Plus, 
  Trash2, 
  Edit3, 
  Clock, 
  Calendar, 
  Check, 
  X, 
  AlertCircle, 
  Filter, 
  Flame, 
  ChevronRight,
  Info,
  ArrowUp,
  Sparkles
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useAccessibility } from '../context/AccessibilityContext';
import { Medicine } from '../types';

interface MedicationManagerProps {
  forceOpenAddModal?: boolean;
}

export const MedicationManager: React.FC<MedicationManagerProps> = ({ forceOpenAddModal = false }) => {
  const { 
    medicines, 
    addMedicine, 
    updateMedicine, 
    deleteMedicine, 
    schedules, 
    markDoseStatus, 
    adherencePercentage, 
    adherenceStreak,
    stats,
    currentRole,
    loadSampleMedicines
  } = useAuth();

  const { playChime, speak } = useAccessibility();

  // Tab & Filter states
  const [viewTab, setViewTab] = useState<'daily' | 'all_meds' | 'weekly'>('daily');
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'taken' | 'skipped'>('all');

  // Add/Edit Medicine Modal State
  const [isModalOpen, setIsModalOpen] = useState(forceOpenAddModal);
  const [editingMedId, setEditingMedId] = useState<string | null>(null);

  useEffect(() => {
    if (forceOpenAddModal) {
      setIsModalOpen(true);
    }
  }, [forceOpenAddModal]);

  // Form fields
  const [name, setName] = useState('');
  const [dosage, setDosage] = useState('');
  const [form, setForm] = useState<Medicine['form']>('Tablet');
  const [frequency, setFrequency] = useState<Medicine['frequency']>('Once Daily');
  const [colorCode, setColorCode] = useState('#10B981');
  const [scheduleTimes, setScheduleTimes] = useState<string[]>(['08:00 AM']);
  const [timeInput, setTimeInput] = useState('08:00 AM');
  const [foodInstruction, setFoodInstruction] = useState<Medicine['foodInstruction']>('After Food');
  const [startDate, setStartDate] = useState(new Date().toISOString().split('T')[0]);
  const [endDate, setEndDate] = useState('');
  const [prescribedBy, setPrescribedBy] = useState('');
  const [instructions, setInstructions] = useState('');

  const resetForm = () => {
    setName('');
    setDosage('');
    setForm('Tablet');
    setFrequency('Once Daily');
    setColorCode('#10B981');
    setScheduleTimes(['08:00 AM']);
    setTimeInput('08:00 AM');
    setFoodInstruction('After Food');
    setStartDate(new Date().toISOString().split('T')[0]);
    setEndDate('');
    setPrescribedBy('');
    setInstructions('');
    setEditingMedId(null);
  };

  const handleOpenAddModal = () => {
    resetForm();
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (med: Medicine) => {
    setEditingMedId(med.id);
    setName(med.name);
    setDosage(med.dosage);
    setForm(med.form);
    setFrequency(med.frequency);
    setColorCode(med.colorCode);
    setScheduleTimes(med.scheduleTimes);
    setFoodInstruction(med.foodInstruction);
    setStartDate(med.startDate);
    setEndDate(med.endDate || '');
    setPrescribedBy(med.prescribedBy || '');
    setInstructions(med.instructions || '');
    setIsModalOpen(true);
  };

  const handleAddTimeSlot = () => {
    if (!scheduleTimes.includes(timeInput)) {
      setScheduleTimes([...scheduleTimes, timeInput]);
    }
  };

  const handleRemoveTimeSlot = (t: string) => {
    setScheduleTimes(scheduleTimes.filter(item => item !== t));
  };

  const handleSubmitMedicine = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !dosage.trim()) {
      alert('Please provide medication name and dosage.');
      return;
    }

    if (editingMedId) {
      updateMedicine(editingMedId, {
        name,
        dosage,
        form,
        frequency,
        colorCode,
        scheduleTimes,
        foodInstruction,
        startDate,
        endDate: endDate || undefined,
        prescribedBy: prescribedBy || undefined,
        instructions: instructions || undefined,
      });
      speak(`Updated ${name}`);
    } else {
      addMedicine({
        elderlyUserId: 'usr-elderly-01',
        name,
        dosage,
        form,
        frequency,
        colorCode,
        scheduleTimes,
        foodInstruction,
        startDate,
        endDate: endDate || undefined,
        prescribedBy: prescribedBy || undefined,
        instructions: instructions || undefined,
        isActive: true,
      });
    }

    setIsModalOpen(false);
    resetForm();
  };

  const filteredSchedules = schedules.filter(item => {
    if (statusFilter === 'all') return true;
    return item.status === statusFilter;
  });

  const daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

  return (
    <div className="space-y-8 pb-16">
      
      {/* 1. Header with Adherence Metric & Add Button */}
      <section className="bg-white rounded-3xl border border-slate-200/80 p-6 sm:p-8 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="flex items-center space-x-2 text-elder-green-700 text-xs font-bold uppercase tracking-wider mb-1">
              <Pill className="w-4 h-4" />
              <span>Medication Management & Tracking</span>
            </div>
            <h1 className="text-3xl font-black text-slate-900">
              Prescription & Adherence Schedule
            </h1>
            <p className="text-slate-500 text-sm font-medium mt-1">
              Track dose times, meal instructions, adherence rates, and doctor prescriptions.
            </p>
          </div>

          <div className="flex items-center gap-4">
            <div className="hidden sm:flex items-center space-x-3 bg-emerald-50 border border-emerald-200 px-4 py-2.5 rounded-2xl">
              <Flame className="w-6 h-6 text-amber-500 fill-amber-500" />
              <div>
                <p className="text-xs font-bold text-emerald-800 uppercase tracking-wider">Adherence</p>
                <p className="text-lg font-black text-emerald-950">{adherencePercentage}% ({adherenceStreak}d streak)</p>
              </div>
            </div>

            <button
              onClick={handleOpenAddModal}
              className="inline-flex items-center space-x-2 px-5 py-3 rounded-2xl bg-elder-green-700 hover:bg-elder-green-800 text-white font-extrabold text-sm shadow-md transition-all active:scale-95"
            >
              <Plus className="w-5 h-5" />
              <span>Add New Medicine</span>
            </button>
          </div>
        </div>

        {/* Tab Switcher: Daily vs All Prescriptions vs Weekly */}
        <div className="mt-8 pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center space-x-2 bg-slate-100 p-1.5 rounded-2xl text-xs font-bold">
            <button
              onClick={() => setViewTab('daily')}
              className={`px-4 py-2 rounded-xl transition-all ${
                viewTab === 'daily' ? 'bg-white text-elder-charcoal shadow-sm' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Today's Schedule ({schedules.length})
            </button>
            <button
              onClick={() => setViewTab('all_meds')}
              className={`px-4 py-2 rounded-xl transition-all ${
                viewTab === 'all_meds' ? 'bg-white text-elder-charcoal shadow-sm' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Active Prescriptions ({medicines.length})
            </button>
            <button
              onClick={() => setViewTab('weekly')}
              className={`px-4 py-2 rounded-xl transition-all ${
                viewTab === 'weekly' ? 'bg-white text-elder-charcoal shadow-sm' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Weekly Overview
            </button>
          </div>

          {viewTab === 'daily' && (
            <div className="flex items-center space-x-2 text-xs font-bold text-slate-600">
              <Filter className="w-3.5 h-3.5 text-slate-400" />
              <span>Filter:</span>
              {(['all', 'pending', 'taken', 'skipped'] as const).map(f => (
                <button
                  key={f}
                  onClick={() => setStatusFilter(f)}
                  className={`px-2.5 py-1 rounded-lg capitalize ${
                    statusFilter === f ? 'bg-elder-green-100 text-elder-green-800 font-extrabold' : 'hover:bg-slate-100'
                  }`}
                >
                  {f}
                </button>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* 2. Content depending on active tab */}

      {/* TAB 1: Today's Schedule */}
      {viewTab === 'daily' && (
        <section className="space-y-4">
          {filteredSchedules.length === 0 ? (
            <div className="bg-white rounded-3xl border-2 border-dashed border-elder-green-300 p-8 sm:p-12 text-center max-w-2xl mx-auto space-y-6 shadow-sm">
              <div className="flex flex-col items-center">
                <div className="w-16 h-16 rounded-3xl bg-elder-green-100 text-elder-green-800 flex items-center justify-center mb-4">
                  <Pill className="w-8 h-8" />
                </div>
                <div className="animate-bounce flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-amber-400 text-slate-950 text-xs font-black mb-3 shadow-md">
                  <ArrowUp className="w-4 h-4 stroke-[3]" />
                  <span>Look Here: Tap "Add New Medicine" Above</span>
                </div>
                <h3 className="text-2xl font-black text-slate-900">
                  No Medicines Scheduled Yet
                </h3>
                <p className="text-slate-600 text-sm max-w-md mx-auto">
                  Your daily routine is ready. Add your first prescription schedule in 3 easy steps:
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-left">
                <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200">
                  <span className="w-6 h-6 rounded-full bg-elder-green-700 text-white flex items-center justify-center text-xs font-black mb-2">1</span>
                  <p className="text-xs font-bold text-slate-900">Medicine Name</p>
                  <p className="text-[11px] text-slate-500">e.g. Metformin or Lisinopril 10mg</p>
                </div>
                <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200">
                  <span className="w-6 h-6 rounded-full bg-elder-green-700 text-white flex items-center justify-center text-xs font-black mb-2">2</span>
                  <p className="text-xs font-bold text-slate-900">Scheduled Time</p>
                  <p className="text-[11px] text-slate-500">Morning, lunch, dinner, or night</p>
                </div>
                <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200">
                  <span className="w-6 h-6 rounded-full bg-elder-green-700 text-white flex items-center justify-center text-xs font-black mb-2">3</span>
                  <p className="text-xs font-bold text-slate-900">Meal Rule</p>
                  <p className="text-[11px] text-slate-500">Before, with, or after food</p>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
                <button
                  onClick={handleOpenAddModal}
                  className="w-full sm:w-auto px-6 py-3.5 rounded-2xl bg-elder-green-700 hover:bg-elder-green-800 text-white font-black text-sm flex items-center justify-center space-x-2 shadow-lg shadow-elder-green-700/20 active:scale-95 transition-all"
                >
                  <Plus className="w-5 h-5" />
                  <span>Add Your First Medicine Now</span>
                </button>

                <button
                  onClick={loadSampleMedicines}
                  className="w-full sm:w-auto px-5 py-3 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition-all flex items-center justify-center gap-1.5"
                >
                  <Sparkles className="w-4 h-4 text-amber-500" />
                  <span>Load Sample Starter Medicines</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredSchedules.map((item) => (
                <div
                  key={item.id}
                  className={`rounded-3xl p-5 border-2 flex flex-col justify-between transition-all ${
                    item.status === 'taken'
                      ? 'bg-emerald-50/80 border-emerald-300'
                      : item.status === 'skipped'
                      ? 'bg-red-50/70 border-red-300'
                      : 'bg-white border-slate-200 hover:border-slate-300 shadow-sm'
                  }`}
                >
                  <div>
                    <div className="flex items-start justify-between">
                      <span className="px-3 py-1 rounded-xl bg-slate-100 text-slate-800 text-xs font-black uppercase flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5 text-slate-600" />
                        {item.scheduledTime}
                      </span>

                      {item.status === 'taken' ? (
                        <span className="px-2.5 py-1 rounded-full bg-emerald-600 text-white text-xs font-black flex items-center gap-1">
                          <Check className="w-3.5 h-3.5 stroke-[3]" />
                          Taken at {item.takenAt}
                        </span>
                      ) : item.status === 'skipped' ? (
                        <span className="px-2.5 py-1 rounded-full bg-red-600 text-white text-xs font-black flex items-center gap-1">
                          <X className="w-3.5 h-3.5 stroke-[3]" />
                          Skipped ({item.skippedReason})
                        </span>
                      ) : (
                        <span className="px-2.5 py-1 rounded-full bg-amber-100 text-amber-800 text-xs font-bold">
                          Pending
                        </span>
                      )}
                    </div>

                    <h3 className="text-xl font-black text-slate-900 mt-3">{item.medicineName}</h3>
                    <p className="text-sm font-extrabold text-elder-green-800">{item.dosage}</p>
                    <p className="text-xs text-slate-500 font-medium mt-1">{item.foodInstruction}</p>
                    {item.instructions && (
                      <p className="text-xs text-slate-400 italic mt-1">{item.instructions}</p>
                    )}
                  </div>

                  <div className="mt-5 pt-3 border-t border-slate-200/60 flex items-center gap-2">
                    {item.status !== 'taken' ? (
                      <button
                        onClick={() => markDoseStatus(item.id, 'taken')}
                        className="flex-1 py-2.5 rounded-xl bg-elder-green-600 hover:bg-elder-green-700 text-white font-extrabold text-xs shadow-sm flex items-center justify-center gap-1"
                      >
                        <Check className="w-4 h-4 stroke-[3]" />
                        <span>Take Dose</span>
                      </button>
                    ) : (
                      <button
                        onClick={() => markDoseStatus(item.id, 'pending')}
                        className="text-xs text-slate-500 hover:underline font-medium"
                      >
                        Reset to Pending
                      </button>
                    )}

                    {item.status === 'pending' && (
                      <button
                        onClick={() => markDoseStatus(item.id, 'skipped', 'Patient declined')}
                        className="px-3 py-2.5 rounded-xl bg-slate-100 hover:bg-red-100 text-slate-600 hover:text-red-700 text-xs font-bold"
                      >
                        Skip
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      )}

      {/* TAB 2: Active Prescriptions Management */}
      {viewTab === 'all_meds' && (
        <section>
          {medicines.length === 0 ? (
            <div className="bg-white rounded-3xl border-2 border-dashed border-elder-green-300 p-8 sm:p-12 text-center max-w-2xl mx-auto space-y-4">
              <div className="w-16 h-16 rounded-3xl bg-elder-green-100 text-elder-green-800 flex items-center justify-center mx-auto">
                <Pill className="w-8 h-8" />
              </div>
              <h3 className="text-2xl font-black text-slate-900">No Prescriptions Registered</h3>
              <p className="text-slate-600 text-sm max-w-md mx-auto">
                Click the button below to register your first active prescription with doctor details and instructions.
              </p>
              <button
                onClick={handleOpenAddModal}
                className="px-6 py-3 rounded-2xl bg-elder-green-700 hover:bg-elder-green-800 text-white font-bold text-sm shadow-md"
              >
                + Register First Prescription
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {medicines.map((med) => (
            <div key={med.id} className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm flex flex-col justify-between">
              <div>
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-3">
                    <div 
                      className="w-12 h-12 rounded-2xl flex items-center justify-center text-white font-black"
                      style={{ backgroundColor: med.colorCode }}
                    >
                      <Pill className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="text-xl font-black text-slate-900">{med.name}</h3>
                      <p className="text-xs font-bold text-slate-500">{med.dosage} • {med.form}</p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-1">
                    <button
                      onClick={() => handleOpenEditModal(med)}
                      className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100"
                      title="Edit medicine"
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => {
                        if (confirm(`Are you sure you want to remove ${med.name}?`)) {
                          deleteMedicine(med.id);
                        }
                      }}
                      className="p-2 rounded-xl text-slate-400 hover:text-red-600 hover:bg-red-50"
                      title="Delete medicine"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <div className="mt-4 space-y-2 text-xs">
                  <div className="flex justify-between py-1 border-b border-slate-100">
                    <span className="text-slate-500 font-semibold">Frequency:</span>
                    <span className="font-extrabold text-slate-800">{med.frequency}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-100">
                    <span className="text-slate-500 font-semibold">Schedule Times:</span>
                    <span className="font-extrabold text-slate-800">{med.scheduleTimes.join(', ')}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-100">
                    <span className="text-slate-500 font-semibold">Food Instruction:</span>
                    <span className="font-extrabold text-slate-800">{med.foodInstruction}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-100">
                    <span className="text-slate-500 font-semibold">Prescribing Doctor:</span>
                    <span className="font-extrabold text-slate-800">{med.prescribedBy || 'Primary Physician'}</span>
                  </div>
                  {med.instructions && (
                    <div className="pt-2">
                      <p className="text-slate-500 font-semibold">Special Instructions:</p>
                      <p className="text-slate-700 font-medium italic mt-0.5">{med.instructions}</p>
                    </div>
                  )}
                </div>
              </div>

              <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-400">
                <span>Start: {med.startDate}</span>
                <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold">Active</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </section>
  )}

      {/* TAB 3: Weekly Overview */}
      {viewTab === 'weekly' && (
        <section className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm">
          <h2 className="text-2xl font-black text-slate-900 mb-2">Weekly Adherence Matrix</h2>
          <p className="text-slate-500 text-sm font-medium mb-6">Visual tracking of daily scheduled medication regimes.</p>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-7 gap-3">
            {daysOfWeek.map((day, idx) => {
              const isToday = idx === 6; // Sunday in sample
              return (
                <div
                  key={day}
                  className={`p-4 rounded-2xl border text-center ${
                    isToday ? 'bg-elder-green-50 border-elder-green-300' : 'bg-slate-50 border-slate-200'
                  }`}
                >
                  <p className="text-xs uppercase font-extrabold tracking-wider text-slate-500">{day.substring(0, 3)}</p>
                  <p className="text-lg font-black text-slate-900 mt-1">{isToday ? 'Today' : `Feb ${10 + idx}`}</p>
                  <div className="my-3 flex justify-center">
                    <div className="w-10 h-10 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold text-xs">
                      {isToday ? `${adherencePercentage}%` : '100%'}
                    </div>
                  </div>
                  <p className="text-[11px] font-semibold text-slate-500">
                    {isToday ? `${stats.takenCount}/${stats.totalScheduled} Taken` : 'All Taken'}
                  </p>
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* Add / Edit Medicine Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl my-8">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <h2 className="text-2xl font-black text-slate-900">
                {editingMedId ? 'Edit Medicine Details' : 'Add Prescribed Medicine'}
              </h2>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-2 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitMedicine} className="space-y-4 mt-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-black uppercase text-slate-700 mb-1">
                    Medicine Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Metformin"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-300 font-semibold focus:ring-2 focus:ring-elder-green-600 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-black uppercase text-slate-700 mb-1">
                    Dosage *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. 500 mg, 1 tablet"
                    value={dosage}
                    onChange={(e) => setDosage(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-300 font-semibold focus:ring-2 focus:ring-elder-green-600 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-black uppercase text-slate-700 mb-1">
                    Form
                  </label>
                  <select
                    value={form}
                    onChange={(e) => setForm(e.target.value as any)}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-300 font-semibold focus:ring-2 focus:ring-elder-green-600 focus:outline-none"
                  >
                    <option value="Tablet">Tablet</option>
                    <option value="Capsule">Capsule</option>
                    <option value="Syrup">Syrup</option>
                    <option value="Injection">Injection</option>
                    <option value="Inhaler">Inhaler</option>
                    <option value="Drops">Eye/Ear Drops</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-black uppercase text-slate-700 mb-1">
                    Frequency
                  </label>
                  <select
                    value={frequency}
                    onChange={(e) => setFrequency(e.target.value as any)}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-300 font-semibold focus:ring-2 focus:ring-elder-green-600 focus:outline-none"
                  >
                    <option value="Once Daily">Once Daily</option>
                    <option value="Twice Daily">Twice Daily</option>
                    <option value="Three Times Daily">Three Times Daily</option>
                    <option value="Four Times Daily">Four Times Daily</option>
                    <option value="As Needed">As Needed (SOS)</option>
                  </select>
                </div>
              </div>

              {/* Time Slots Input */}
              <div>
                <label className="block text-xs font-black uppercase text-slate-700 mb-1">
                  Scheduled Daily Times
                </label>
                <div className="flex gap-2">
                  <select
                    value={timeInput}
                    onChange={(e) => setTimeInput(e.target.value)}
                    className="flex-1 px-4 py-2.5 rounded-xl border border-slate-300 font-semibold focus:ring-2 focus:ring-elder-green-600 focus:outline-none"
                  >
                    <option value="08:00 AM">Morning (08:00 AM)</option>
                    <option value="09:00 AM">Morning Routine (09:00 AM)</option>
                    <option value="01:00 PM">Afternoon Lunch (01:00 PM)</option>
                    <option value="07:00 PM">Evening (07:00 PM)</option>
                    <option value="08:00 PM">Dinner (08:00 PM)</option>
                    <option value="09:30 PM">Bedtime (09:30 PM)</option>
                  </select>
                  <button
                    type="button"
                    onClick={handleAddTimeSlot}
                    className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold rounded-xl text-xs"
                  >
                    Add Time
                  </button>
                </div>

                <div className="flex flex-wrap gap-2 mt-2">
                  {scheduleTimes.map(t => (
                    <span key={t} className="px-3 py-1 bg-elder-green-100 text-elder-green-800 rounded-full text-xs font-bold flex items-center gap-1">
                      {t}
                      <button type="button" onClick={() => handleRemoveTimeSlot(t)} className="hover:text-red-600">×</button>
                    </span>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-black uppercase text-slate-700 mb-1">
                    Meal Instruction
                  </label>
                  <select
                    value={foodInstruction}
                    onChange={(e) => setFoodInstruction(e.target.value as any)}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-300 font-semibold focus:ring-2 focus:ring-elder-green-600 focus:outline-none"
                  >
                    <option value="Before Food">Before Food</option>
                    <option value="After Food">After Food</option>
                    <option value="With Food">With Food / Meal</option>
                    <option value="Empty Stomach">Empty Stomach</option>
                    <option value="Anytime">Anytime</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-black uppercase text-slate-700 mb-1">
                    Prescribing Doctor
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Dr. Rajesh Sharma"
                    value={prescribedBy}
                    onChange={(e) => setPrescribedBy(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-300 font-semibold focus:ring-2 focus:ring-elder-green-600 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-black uppercase text-slate-700 mb-1">
                  Special Notes / Precautions
                </label>
                <textarea
                  rows={2}
                  placeholder="e.g. Take with a full glass of water. Avoid taking with antacids."
                  value={instructions}
                  onChange={(e) => setInstructions(e.target.value)}
                  className="w-full px-4 py-2 rounded-xl border border-slate-300 font-medium text-sm focus:ring-2 focus:ring-elder-green-600 focus:outline-none"
                />
              </div>

              <div className="flex space-x-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="flex-1 py-3 rounded-xl border border-slate-300 font-bold text-slate-700 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-3 rounded-xl bg-elder-green-700 hover:bg-elder-green-800 text-white font-extrabold shadow-md"
                >
                  {editingMedId ? 'Save Changes' : 'Add Medicine'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
