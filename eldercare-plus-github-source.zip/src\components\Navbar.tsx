import React, { useState, useEffect, useRef } from 'react';
import { 
  Heart, 
  Layers, 
  Pill, 
  Calendar, 
  Lock, 
  Sliders, 
  Inbox, 
  AlertTriangle, 
  Users, 
  UserCheck, 
  ShieldCheck, 
  Menu, 
  X,
  Bell,
  Moon,
  LogOut,
  ChevronDown,
  Compass
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useAccessibility } from '../context/AccessibilityContext';
import { getVirtualEmails } from '../lib/resend';

export type AppTab = 'dashboard' | 'medications' | 'appointments' | 'profile';

interface NavbarProps {
  activeTab: AppTab;
  onTabChange: (tab: AppTab) => void;
  onOpenSilentModal: () => void;
  onOpenVoiceModal: () => void;
  onOpenSosModal: () => void;
  onOpenSettingsModal: () => void;
  onOpenNotifModal: () => void;
  onOpenMailboxModal: () => void;
  onOpenNightBlindnessModal: () => void;
  onOpenAccessibilityHubModal: () => void;
  onOpenTourModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  onTabChange,
  onOpenSilentModal,
  onOpenVoiceModal,
  onOpenSosModal,
  onOpenSettingsModal,
  onOpenNotifModal,
  onOpenMailboxModal,
  onOpenNightBlindnessModal,
  onOpenAccessibilityHubModal,
  onOpenTourModal,
}) => {
  const { currentRole, currentUser, switchUser, logout, notifications } = useAuth();
  const { settings, updateSettings, t, playChime } = useAccessibility();

  const [virtualMailCount, setVirtualMailCount] = useState(0);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const userMenuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const updateCount = () => {
      setVirtualMailCount(getVirtualEmails().length);
    };
    updateCount();
    window.addEventListener('eldercare_new_email', updateCount);
    window.addEventListener('eldercare_mailbox_cleared', updateCount);
    return () => {
      window.removeEventListener('eldercare_new_email', updateCount);
      window.removeEventListener('eldercare_mailbox_cleared', updateCount);
    };
  }, []);

  // Close user dropdown on outside click or ESC key
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (userMenuRef.current && !userMenuRef.current.contains(e.target as Node)) {
        setUserMenuOpen(false);
      }
    };
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setUserMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, []);

  const handleTabClick = (tab: AppTab) => {
    playChime('click');
    onTabChange(tab);
    setMobileMenuOpen(false);
  };

  const handleRoleSwitch = (role: 'elderly' | 'family' | 'caregiver') => {
    playChime('click');
    switchUser(role);
    setUserMenuOpen(false);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-white/95 backdrop-blur-md border-b border-slate-200/80 shadow-xs transition-colors">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20 gap-2 sm:gap-4">
          
          {/* 1. Left: Brand Logo */}
          <div className="flex items-center space-x-2.5 shrink-0">
            <button
              onClick={() => handleTabClick('dashboard')}
              className="flex items-center space-x-2.5 text-left focus:outline-none"
              aria-label="ElderCare+ Home"
            >
              <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-xl sm:rounded-2xl bg-gradient-to-br from-elder-green-600 to-elder-green-800 flex items-center justify-center text-white shadow-md shadow-elder-green-600/20 shrink-0">
                <Heart className="w-5 h-5 sm:w-6 sm:h-6 fill-white/20 text-white" />
              </div>
              <div>
                <span className="text-xl sm:text-2xl font-black tracking-tight text-slate-900 flex items-center">
                  ElderCare<span className="text-elder-green-600">+</span>
                </span>
                <span className="hidden sm:block text-[10px] sm:text-[11px] font-semibold text-slate-400 -mt-0.5 whitespace-nowrap">
                  {settings.language === 'hi' 
                    ? 'स्मार्ट स्वास्थ्य देखभाल' 
                    : settings.language === 'bn' 
                    ? 'স্মার্ট স্বাস্থ্যসেবা' 
                    : 'Smart Elderly Care'}
                </span>
              </div>
            </button>
          </div>

          {/* 2. Center: Primary Clean Navigation Tabs (Desktop & Laptop) */}
          <nav className="hidden lg:flex items-center space-x-1 bg-slate-100/90 p-1 rounded-2xl border border-slate-200/60 shrink">
            <button
              onClick={() => handleTabClick('dashboard')}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-xl text-xs xl:text-sm font-bold whitespace-nowrap transition-all ${
                activeTab === 'dashboard'
                  ? 'bg-white text-elder-green-800 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
              }`}
            >
              <Layers className="w-4 h-4 text-elder-green-600 shrink-0" />
              <span>
                {settings.language === 'hi' ? 'डैशबोर्ड' : settings.language === 'bn' ? 'ড্যাশবোর্ড' : 'Dashboard'}
              </span>
            </button>

            <button
              onClick={() => handleTabClick('medications')}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-xl text-xs xl:text-sm font-bold whitespace-nowrap transition-all ${
                activeTab === 'medications'
                  ? 'bg-white text-elder-green-800 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
              }`}
            >
              <Pill className="w-4 h-4 text-elder-green-600 shrink-0" />
              <span>
                {settings.language === 'hi' ? 'दवाइयाँ' : settings.language === 'bn' ? 'ওষুধ' : 'Medications'}
              </span>
            </button>

            <button
              onClick={() => handleTabClick('appointments')}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-xl text-xs xl:text-sm font-bold whitespace-nowrap transition-all ${
                activeTab === 'appointments'
                  ? 'bg-white text-elder-green-800 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
              }`}
            >
              <Calendar className="w-4 h-4 text-elder-green-600 shrink-0" />
              <span>
                {settings.language === 'hi' ? 'मुलाकातें' : settings.language === 'bn' ? 'সাক্ষাত' : 'Appointments'}
              </span>
            </button>

            <button
              onClick={() => handleTabClick('profile')}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-xl text-xs xl:text-sm font-bold whitespace-nowrap transition-all ${
                activeTab === 'profile'
                  ? 'bg-white text-elder-green-800 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
              }`}
            >
              <Lock className="w-4 h-4 text-elder-green-600 shrink-0" />
              <span>
                {settings.language === 'hi' ? 'प्रोफ़ाइल' : settings.language === 'bn' ? 'প্রোফাইল' : 'Health Profile'}
              </span>
            </button>
          </nav>

          {/* 3. Right: Streamlined Action & User Controls */}
          <div className="flex items-center space-x-1.5 sm:space-x-2 shrink-0">
            
            {/* Quick Language Segmented Control */}
            <div className="flex items-center bg-slate-100 p-0.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-600 shrink-0">
              <button
                onClick={() => {
                  playChime('click');
                  updateSettings({ language: 'en' });
                }}
                className={`px-2 py-1 rounded-lg transition-all ${
                  settings.language === 'en' 
                    ? 'bg-white text-elder-green-800 shadow-xs font-black' 
                    : 'hover:text-slate-900'
                }`}
                aria-label="English"
              >
                EN
              </button>
              <button
                onClick={() => {
                  playChime('click');
                  updateSettings({ language: 'hi' });
                }}
                className={`px-2 py-1 rounded-lg transition-all ${
                  settings.language === 'hi' 
                    ? 'bg-white text-elder-green-800 shadow-xs font-black' 
                    : 'hover:text-slate-900'
                }`}
                aria-label="Hindi"
              >
                हिंदी
              </button>
              <button
                onClick={() => {
                  playChime('click');
                  updateSettings({ language: 'bn' });
                }}
                className={`px-2 py-1 rounded-lg transition-all ${
                  settings.language === 'bn' 
                    ? 'bg-white text-elder-green-800 shadow-xs font-black' 
                    : 'hover:text-slate-900'
                }`}
                aria-label="Bengali"
              >
                বাংলা
              </button>
            </div>

            {/* Virtual Mailbox Icon Button */}
            <button
              onClick={onOpenMailboxModal}
              aria-label="Virtual Test Mailbox"
              className="relative p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 transition-all shrink-0"
            >
              <Inbox className="w-4 h-4 text-elder-blue-700" />
              {virtualMailCount > 0 && (
                <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-elder-blue-700 text-[10px] font-black text-white">
                  {virtualMailCount}
                </span>
              )}
            </button>

            {/* Interactive Guided Tour Button (With Visual Arrows) */}
            <button
              onClick={onOpenTourModal}
              aria-label="How ElderCare Works Guided Tour with Arrows"
              title="How It Works (Interactive Tour with Arrows)"
              className="flex items-center space-x-1.5 px-2.5 sm:px-3 py-2 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-600 text-slate-950 font-black text-xs shadow-md shadow-amber-400/20 active:scale-95 transition-all shrink-0"
            >
              <Compass className="w-4 h-4 text-slate-950 shrink-0" />
              <span className="hidden sm:inline">How It Works</span>
            </button>

            {/* Accessibility & Display Hub */}
            <button
              onClick={onOpenAccessibilityHubModal}
              aria-label="Accessibility & Display Settings"
              className="flex items-center space-x-1 p-2 sm:px-2.5 sm:py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-200 text-xs font-bold transition-all shrink-0"
            >
              <Sliders className="w-4 h-4 text-elder-green-700" />
              <span className="hidden xl:inline">Display</span>
              {settings.nightBlindnessMode && (
                <Moon className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
              )}
            </button>

            {/* User Profile & Role Dropdown Menu Hub */}
            <div className="relative shrink-0" ref={userMenuRef}>
              <button
                onClick={() => setUserMenuOpen(!userMenuOpen)}
                className="flex items-center space-x-2 bg-slate-100 hover:bg-slate-200/80 py-1 px-2 rounded-xl border border-slate-200 transition-all text-left"
                aria-label="User profile and role menu"
                aria-expanded={userMenuOpen}
              >
                {currentUser?.avatarUrl ? (
                  <img 
                    src={currentUser.avatarUrl} 
                    alt={currentUser.fullName || 'User'} 
                    className="w-7 h-7 rounded-lg object-cover border border-slate-300 shrink-0"
                  />
                ) : (
                  <div className="w-7 h-7 rounded-lg bg-elder-green-700 text-white flex items-center justify-center font-bold text-xs shrink-0">
                    {((currentUser?.fullName || (currentUser as any)?.name || 'U')[0] || 'U')}
                  </div>
                )}
                <div className="hidden sm:block leading-tight max-w-[85px] xl:max-w-[110px]">
                  <div className="text-xs font-bold text-slate-900 truncate">
                    {(currentUser?.fullName || (currentUser as any)?.name || 'Eleanor').split(' ')[0]}
                  </div>
                  <div className="text-[10px] font-semibold text-elder-green-700 capitalize truncate">
                    {currentRole === 'elderly' ? 'Patient' : currentRole === 'family' ? 'Family' : 'Nurse'}
                  </div>
                </div>
                <ChevronDown className="w-3.5 h-3.5 text-slate-500 shrink-0" />
              </button>

              {/* User Dropdown Popover */}
              {userMenuOpen && (
                <div className="absolute right-0 mt-2 w-64 bg-white rounded-2xl shadow-2xl border border-slate-200 p-3 z-50 animate-in fade-in zoom-in-95 duration-100">
                  <div className="flex items-center space-x-3 pb-3 border-b border-slate-100">
                    {currentUser?.avatarUrl ? (
                      <img src={currentUser.avatarUrl} alt="" className="w-10 h-10 rounded-xl object-cover border border-slate-200" />
                    ) : (
                      <div className="w-10 h-10 rounded-xl bg-elder-green-700 text-white flex items-center justify-center font-bold text-sm">
                        {((currentUser?.fullName || (currentUser as any)?.name || 'U')[0] || 'U')}
                      </div>
                    )}
                    <div className="min-w-0 flex-1">
                      <div className="text-sm font-bold text-slate-900 truncate">{currentUser?.fullName || 'User'}</div>
                      <div className="text-xs text-slate-500 truncate">{currentUser?.email}</div>
                      <span className="inline-block mt-1 px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-wider bg-elder-green-100 text-elder-green-800">
                        {currentRole} Mode
                      </span>
                    </div>
                  </div>

                  {/* Switch Active Role */}
                  <div className="py-2.5 border-b border-slate-100">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">
                      Switch Role View:
                    </span>
                    <div className="space-y-1">
                      <button
                        onClick={() => handleRoleSwitch('elderly')}
                        className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                          currentRole === 'elderly' ? 'bg-elder-green-50 text-elder-green-800 font-bold' : 'text-slate-700 hover:bg-slate-100'
                        }`}
                      >
                        <span>Eleanor Vance (Patient)</span>
                        {currentRole === 'elderly' && <span className="w-2 h-2 rounded-full bg-elder-green-600"></span>}
                      </button>

                      <button
                        onClick={() => handleRoleSwitch('family')}
                        className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                          currentRole === 'family' ? 'bg-elder-blue-50 text-elder-blue-800 font-bold' : 'text-slate-700 hover:bg-slate-100'
                        }`}
                      >
                        <span>Priya Vance (Family)</span>
                        {currentRole === 'family' && <span className="w-2 h-2 rounded-full bg-elder-blue-600"></span>}
                      </button>

                      <button
                        onClick={() => handleRoleSwitch('caregiver')}
                        className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                          currentRole === 'caregiver' ? 'bg-purple-50 text-purple-800 font-bold' : 'text-slate-700 hover:bg-slate-100'
                        }`}
                      >
                        <span>Nurse Sarah Jenkins (RN)</span>
                        {currentRole === 'caregiver' && <span className="w-2 h-2 rounded-full bg-purple-600"></span>}
                      </button>
                    </div>
                  </div>

                  {/* Log Out Option in Dropdown */}
                  <div className="pt-2">
                    <button
                      onClick={() => {
                        setUserMenuOpen(false);
                        playChime('click');
                        logout();
                      }}
                      className="w-full flex items-center space-x-2 px-2.5 py-2 rounded-lg text-xs font-bold text-red-600 hover:bg-red-50 transition-all"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>Log Out of Session</span>
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Quick Log Out Button on Desktop */}
            <button
              onClick={() => {
                playChime('click');
                logout();
              }}
              aria-label="Log Out"
              className="hidden sm:flex items-center space-x-1 px-2.5 py-2 rounded-xl bg-slate-100 hover:bg-red-50 hover:text-red-700 text-slate-700 border border-slate-200 text-xs font-bold transition-all shrink-0"
            >
              <LogOut className="w-4 h-4 text-slate-600 hover:text-red-700 shrink-0" />
              <span className="hidden md:inline">Log Out</span>
            </button>

            {/* Emergency SOS Button (Always distinct and rightmost) */}
            <button
              onClick={onOpenSosModal}
              aria-label="Emergency SOS Alert"
              className="flex items-center space-x-1 px-3 sm:px-3.5 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white font-black text-xs sm:text-sm tracking-wide shadow-md shadow-red-600/30 transition-transform active:scale-95 shrink-0"
            >
              <AlertTriangle className="w-4 h-4 text-white animate-bounce shrink-0" />
              <span>SOS</span>
            </button>

            {/* Mobile Menu Hamburger */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-xl bg-slate-100 text-slate-700 hover:bg-slate-200 shrink-0"
              aria-label="Toggle Navigation"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>

          </div>

        </div>

        {/* Mobile Dropdown Menu (Clean, spacious, full feature set) */}
        {mobileMenuOpen && (
          <div className="lg:hidden py-4 border-t border-slate-200 space-y-3 bg-white">
            <div className="grid grid-cols-2 gap-2 text-xs font-bold">
              <button
                onClick={() => handleTabClick('dashboard')}
                className={`p-3 rounded-xl flex items-center space-x-2 ${
                  activeTab === 'dashboard' ? 'bg-elder-green-700 text-white' : 'bg-slate-100 text-slate-800'
                }`}
              >
                <Layers className="w-4 h-4" />
                <span>{settings.language === 'hi' ? 'डैशबोर्ड' : settings.language === 'bn' ? 'ড্যাশবোর্ড' : 'Dashboard'}</span>
              </button>
              <button
                onClick={() => handleTabClick('medications')}
                className={`p-3 rounded-xl flex items-center space-x-2 ${
                  activeTab === 'medications' ? 'bg-elder-green-700 text-white' : 'bg-slate-100 text-slate-800'
                }`}
              >
                <Pill className="w-4 h-4" />
                <span>{settings.language === 'hi' ? 'दवाइयाँ' : settings.language === 'bn' ? 'ওষুধ' : 'Medications'}</span>
              </button>
              <button
                onClick={() => handleTabClick('appointments')}
                className={`p-3 rounded-xl flex items-center space-x-2 ${
                  activeTab === 'appointments' ? 'bg-elder-green-700 text-white' : 'bg-slate-100 text-slate-800'
                }`}
              >
                <Calendar className="w-4 h-4" />
                <span>{settings.language === 'hi' ? 'मुलाकातें' : settings.language === 'bn' ? 'সাক্ষাত' : 'Appointments'}</span>
              </button>
              <button
                onClick={() => handleTabClick('profile')}
                className={`p-3 rounded-xl flex items-center space-x-2 ${
                  activeTab === 'profile' ? 'bg-elder-green-700 text-white' : 'bg-slate-100 text-slate-800'
                }`}
              >
                <Lock className="w-4 h-4" />
                <span>{settings.language === 'hi' ? 'प्रोफ़ाइल' : settings.language === 'bn' ? 'প্রোফাইল' : 'Health Profile'}</span>
              </button>
            </div>

            {/* Mobile Tour Button */}
            <button
              onClick={() => {
                onOpenTourModal();
                setMobileMenuOpen(false);
              }}
              className="w-full p-3 rounded-2xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-black text-xs flex items-center justify-center space-x-2 shadow-sm"
            >
              <Compass className="w-4 h-4 text-slate-950" />
              <span>Interactive Website Guide & Arrows</span>
            </button>

            {/* Mobile User Profile & Log Out */}
            <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
              <div className="flex items-center space-x-2.5">
                {currentUser?.avatarUrl ? (
                  <img src={currentUser.avatarUrl} alt={currentUser.fullName} className="w-8 h-8 rounded-lg object-cover border border-slate-200" />
                ) : (
                  <div className="w-8 h-8 rounded-lg bg-elder-green-700 text-white flex items-center justify-center font-bold text-xs">
                    {((currentUser?.fullName || (currentUser as any)?.name || 'U')[0] || 'U')}
                  </div>
                )}
                <div>
                  <span className="font-bold text-slate-900 text-xs block">{currentUser?.fullName || (currentUser as any)?.name || 'User'}</span>
                  <span className="text-[10px] text-slate-500 capitalize">{currentRole}</span>
                </div>
              </div>
              <button
                onClick={() => {
                  logout();
                  setMobileMenuOpen(false);
                }}
                className="flex items-center space-x-1 px-3 py-1.5 rounded-xl bg-red-50 text-red-700 font-bold text-xs border border-red-200"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Log Out</span>
              </button>
            </div>

            {/* Mobile Role Switcher */}
            <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs font-semibold">
              <span className="text-slate-500">Quick Role Switch:</span>
              <div className="flex gap-1.5">
                <button
                  onClick={() => handleRoleSwitch('elderly')}
                  className={`px-3 py-1.5 rounded-lg ${currentRole === 'elderly' ? 'bg-elder-green-700 text-white' : 'bg-slate-100'}`}
                >
                  Elderly
                </button>
                <button
                  onClick={() => handleRoleSwitch('family')}
                  className={`px-3 py-1.5 rounded-lg ${currentRole === 'family' ? 'bg-elder-blue-700 text-white' : 'bg-slate-100'}`}
                >
                  Family
                </button>
                <button
                  onClick={() => handleRoleSwitch('caregiver')}
                  className={`px-3 py-1.5 rounded-lg ${currentRole === 'caregiver' ? 'bg-purple-700 text-white' : 'bg-slate-100'}`}
                >
                  Nurse
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    </header>
  );
};
