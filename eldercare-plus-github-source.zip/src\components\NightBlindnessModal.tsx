import React, { useState, useEffect } from 'react';
import { 
  X, 
  Moon, 
  Sun, 
  Volume2, 
  Pill, 
  Sparkles, 
  Check, 
  Lightbulb, 
  Eye, 
  Info,
  Sliders,
  ShieldCheck
} from 'lucide-react';
import { useAccessibility } from '../context/AccessibilityContext';
import { useAuth } from '../context/AuthContext';

interface NightBlindnessModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NightBlindnessModal: React.FC<NightBlindnessModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { settings, updateSettings, speak, playChime, t } = useAccessibility();
  const { schedules, markDoseStatus } = useAuth();

  const [lanternActive, setLanternActive] = useState(false);

  // Close on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const currentLang = settings.language;
  const isNightMode = settings.nightBlindnessMode;

  // Filter bedtime & evening medications
  const eveningMeds = schedules.filter(s => {
    return s.scheduledTime.includes('PM') || s.foodInstruction.toLowerCase().includes('bedtime') || s.foodInstruction.toLowerCase().includes('dinner');
  });

  const toggleNightMode = () => {
    playChime('click');
    const newVal = !isNightMode;
    updateSettings({ nightBlindnessMode: newVal });

    let announce = '';
    if (newVal) {
      if (currentLang === 'hi') {
        announce = 'रतौंधी मोड चालू किया गया। कम रोशनी में बिना चमक के देखने के लिए एम्बर थीम सक्रिय है।';
      } else if (currentLang === 'bn') {
        announce = 'রাতকানা মোড চালু হয়েছে। কম আলোতে দেখার জন্য অ্যাম্বার থিম সক্রিয়।';
      } else {
        announce = 'Night Blindness mode enabled. Scotopic amber contrast active.';
      }
    } else {
      if (currentLang === 'hi') {
        announce = 'रतौंधी मोड बंद किया गया।';
      } else if (currentLang === 'bn') {
        announce = 'রাতকানা মোড বন্ধ করা হয়েছে।';
      } else {
        announce = 'Night Blindness mode disabled.';
      }
    }
    speak(announce);
  };

  const readBedtimeMedsAloud = () => {
    playChime('click');
    let text = '';
    if (currentLang === 'hi') {
      text = `रात के समय की दवाइयाँ: `;
      if (eveningMeds.length > 0) {
        text += eveningMeds.map(m => `${m.medicineName}, ${m.dosage}, समय ${m.scheduledTime}, स्थिति: ${m.status === 'taken' ? 'ले ली गई है' : 'बाकी है'}`).join('। ');
      } else {
        text += 'रात के लिए कोई दवा निर्धारित नहीं है।';
      }
    } else if (currentLang === 'bn') {
      text = `রাতের বেলার ওষুধসমূহ: `;
      if (eveningMeds.length > 0) {
        text += eveningMeds.map(m => `${m.medicineName}, ${m.dosage}, সময় ${m.scheduledTime}, অবস্থা: ${m.status === 'taken' ? 'নেওয়া হয়েছে' : 'বাকি আছে'}`).join('। ');
      } else {
        text += 'রাতের জন্য কোনো ওষুধ নেই।';
      }
    } else {
      text = `Bedtime and evening medications: `;
      if (eveningMeds.length > 0) {
        text += eveningMeds.map(m => `${m.medicineName}, ${m.dosage}, scheduled for ${m.scheduledTime}, status: ${m.status}`).join('. ');
      } else {
        text += 'No evening medications scheduled.';
      }
    }
    speak(text);
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="bg-black border-3 border-amber-500 rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl my-6 text-amber-300 max-h-[92vh] flex flex-col justify-between">
        
        {/* Sticky Header with High-Visibility Close Button */}
        <div className="flex items-center justify-between pb-4 border-b border-amber-500/40 sticky top-0 bg-black z-20">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-500 text-black flex items-center justify-center font-black shadow-lg shadow-amber-500/30 flex-shrink-0">
              <Moon className="w-7 h-7" />
            </div>
            <div>
              <h2 className="text-2xl font-black text-amber-400">
                {t('nightBlindness')}
              </h2>
              <p className="text-xs text-amber-200 font-semibold">
                {t('nightBlindnessDesc')}
              </p>
            </div>
          </div>

          {/* Prominent, Highly Visible Close Button */}
          <button
            onClick={onClose}
            aria-label="Close modal window"
            className="flex items-center space-x-1.5 px-3.5 py-2.5 rounded-2xl bg-amber-400 hover:bg-amber-300 text-black font-black text-xs shadow-lg shadow-amber-400/40 border-2 border-amber-300 active:scale-95 transition-all cursor-pointer ring-2 ring-amber-400/30 flex-shrink-0"
            title="Close (ESC)"
          >
            <X className="w-5 h-5 stroke-[3]" />
            <span className="font-black uppercase tracking-wider text-xs">Close ✕</span>
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="py-6 space-y-6 overflow-y-auto pr-1 flex-1">
          
          {/* Main Mode Toggle Switch */}
          <div className="p-5 rounded-2xl bg-neutral-950 border-2 border-amber-500 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center space-x-2 text-amber-400 font-extrabold text-sm mb-1">
                <Sliders className="w-4 h-4" />
                <span>
                  {currentLang === 'hi' ? 'रतौंधी मोड स्थिति:' : currentLang === 'bn' ? 'রাতকানা মোড অবস্থা:' : 'Night Blindness Mode Status:'}
                </span>
              </div>
              <p className="text-xs text-amber-200/80">
                {isNightMode 
                  ? (currentLang === 'hi' ? 'एम्बर थीम सक्रिय है (रोशनी की चकाचौंध से बचाव)' : currentLang === 'bn' ? 'অ্যাম্বার থিম সক্রিয় (চোখের চমক প্রতিরোধ)' : 'Active (Amber rod-sparing dark contrast active)')
                  : (currentLang === 'hi' ? 'सामान्य मोड चालू है' : currentLang === 'bn' ? 'স্বাভাবিক মোড সক্রিয়' : 'Disabled (Standard mode)')}
              </p>
            </div>

            <button
              onClick={toggleNightMode}
              className={`px-6 py-3 rounded-2xl font-black text-sm tracking-wide transition-all shadow-md active:scale-95 ${
                isNightMode
                  ? 'bg-amber-400 text-black hover:bg-amber-300 ring-4 ring-amber-500/30'
                  : 'bg-neutral-800 text-amber-400 border border-amber-500 hover:bg-neutral-700'
              }`}
            >
              {isNightMode ? 'MODE: ACTIVE (ON)' : 'TURN ON NIGHT MODE'}
            </button>
          </div>

          {/* Medical Optical Rationale */}
          <div className="p-4 rounded-2xl bg-neutral-900 border border-amber-500/40 text-xs text-amber-200/90 leading-relaxed space-y-1.5">
            <p className="font-bold text-amber-400 flex items-center gap-1.5">
              <Eye className="w-4 h-4 text-amber-400" />
              {currentLang === 'hi' ? 'चिकित्सीय लाभ (रतौंधी व मोतियाबिंद):' : currentLang === 'bn' ? 'চিকিৎসাভিত্তিক সুবিধা (রাতকানা ও ছানি):' : 'Clinical Advantage for Nyctalopia & Cataracts:'}
            </p>
            <p>
              {currentLang === 'hi'
                ? 'रतौंधी या मोतियाबिंद वाले बुज़ुर्गों की आँखों की रॉड कोशिकाएं कम रोशनी में नीली/सफेद चमक से तुरंत चौंधिया जाती हैं। ५९०nm+ का यह एम्बर रंग आँखों को बिना थकाए स्पष्ट दृश्यता प्रदान करता है।'
                : currentLang === 'bn'
                ? 'রাতকানা বা ছানি থাকা বয়োজ্যেষ্ঠদের চোখের রড কোষগুলো কম আলোতে সাদা বা নীল আলোতে ঝলসে যায়। এই উষ্ণ অ্যাম্বার আলো চোখের দৃষ্টি রক্ষা করে স্পষ্ট দেখতে সাহায্য করে।'
                : 'Individuals with night blindness (nyctalopia) suffer from impaired rod photoreceptors and extreme glare sensitivity. This warm monochromatic amber palette (>590nm) preserves dark adaptation and prevents flash-bleaching.'}
            </p>
          </div>

          {/* Bedtime Medications Spotlight */}
          <div className="p-5 rounded-2xl bg-neutral-950 border-2 border-amber-500/80 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-black text-amber-400 flex items-center gap-2">
                <Pill className="w-5 h-5 text-amber-400" />
                <span>{t('bedtimeMedications')}</span>
              </h3>

              <button
                onClick={readBedtimeMedsAloud}
                className="px-3.5 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/50 text-xs font-bold flex items-center gap-1.5 transition-all"
              >
                <Volume2 className="w-3.5 h-3.5 text-amber-400" />
                <span>{currentLang === 'hi' ? 'बोलकर सुनाएं' : currentLang === 'bn' ? 'শুনুন' : 'Listen Aloud'}</span>
              </button>
            </div>

            <div className="space-y-2">
              {eveningMeds.map((med) => (
                <div
                  key={med.id}
                  className="p-3.5 rounded-xl bg-neutral-900 border border-amber-500/40 flex items-center justify-between"
                >
                  <div>
                    <h4 className="font-extrabold text-amber-300 text-sm">{med.medicineName}</h4>
                    <p className="text-xs text-amber-400/80 font-mono">
                      {med.dosage} • {med.scheduledTime} ({med.foodInstruction})
                    </p>
                  </div>

                  {med.status === 'taken' ? (
                    <span className="px-2.5 py-1 rounded-full bg-emerald-950 border border-emerald-500 text-emerald-400 text-xs font-bold flex items-center gap-1">
                      <Check className="w-3 h-3" />
                      {t('taken')}
                    </span>
                  ) : (
                    <button
                      onClick={() => markDoseStatus(med.id, 'taken')}
                      className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-extrabold text-xs shadow-sm transition-all"
                    >
                      {t('markTaken')}
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Bedside Amber Lantern (Safe Screen Light) */}
          <div className="p-5 rounded-2xl bg-neutral-950 border-2 border-amber-500/60 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <h4 className="font-black text-amber-400 text-sm flex items-center gap-2">
                <Lightbulb className="w-4 h-4 text-amber-400" />
                <span>{t('amberTorch')}</span>
              </h4>
              <p className="text-xs text-amber-200/80">
                {currentLang === 'hi'
                  ? 'रात में बिस्तर के पास रखी दवा की शीशियों को देखने के लिए सुरक्षित एम्बर प्रकाश।'
                  : currentLang === 'bn'
                  ? 'রাতের বেলা বিছানার পাশে ওষুধের বোতল দেখার জন্য নিরাপদ উষ্ণ অ্যাম্বার আলো।'
                  : 'Soft rod-sparing amber glow to identify bedside medicine bottles without turning on glaring bedroom lights.'}
              </p>
            </div>

            <button
              onClick={() => setLanternActive(!lanternActive)}
              className={`px-5 py-2.5 rounded-xl font-bold text-xs border transition-all ${
                lanternActive 
                  ? 'bg-amber-400 text-black border-amber-300 font-black ring-4 ring-amber-400/40 animate-pulse' 
                  : 'bg-neutral-900 hover:bg-neutral-800 text-amber-400 border-amber-500'
              }`}
            >
              {lanternActive ? 'LANTERN ON (Glowing)' : 'TURN ON LANTERN'}
            </button>
          </div>

          {/* Lantern Fullscreen Glow Light if active */}
          {lanternActive && (
            <div 
              onClick={() => setLanternActive(false)}
              className="p-8 rounded-3xl bg-amber-400 text-black text-center font-black shadow-2xl cursor-pointer select-none space-y-2 animate-pulse"
            >
              <Lightbulb className="w-12 h-12 mx-auto text-black" />
              <p className="text-lg">BEDSIDE AMBER LANTERN ACTIVE</p>
              <p className="text-xs font-semibold">Hold device near medicine bottle to inspect labels. Tap anywhere here to turn off.</p>
            </div>
          )}

        </div>

        {/* Sticky Footer with Secondary Close Button */}
        <div className="pt-4 border-t border-amber-500/40 sticky bottom-0 bg-black z-20 flex items-center justify-between">
          <span className="text-xs text-amber-200/70 hidden sm:inline">Click outside or press ESC to exit</span>
          <button
            onClick={onClose}
            className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-black font-black text-xs shadow-md transition-all flex items-center justify-center gap-1.5"
          >
            <X className="w-4 h-4 stroke-[3]" />
            <span>Done / Close Window</span>
          </button>
        </div>

      </div>
    </div>
  );
};
