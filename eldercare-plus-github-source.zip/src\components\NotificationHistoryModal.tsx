import React, { useEffect } from 'react';
import { 
  X, 
  Bell, 
  Mail, 
  CheckCircle, 
  AlertTriangle, 
  Clock, 
  Send,
  ShieldAlert,
  Calendar,
  Pill
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { NotificationType, NotificationStatus } from '../types';

interface NotificationHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenSettingsModal: () => void;
}

export const NotificationHistoryModal: React.FC<NotificationHistoryModalProps> = ({
  isOpen,
  onClose,
  onOpenSettingsModal,
}) => {
  const { notifications, triggerScheduledEmailCheck } = useAuth();

  React.useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const getTypeIcon = (type: NotificationType) => {
    switch (type) {
      case 'upcoming_dose':
      case 'missed_medication':
        return <Pill className="w-4 h-4 text-emerald-600" />;
      case 'doctor_appointment':
        return <Calendar className="w-4 h-4 text-elder-blue-600" />;
      case 'emergency_sos':
        return <ShieldAlert className="w-4 h-4 text-red-600" />;
      default:
        return <Mail className="w-4 h-4 text-purple-600" />;
    }
  };

  const getStatusBadge = (status: NotificationStatus, error?: string) => {
    if (status === 'delivered') {
      return (
        <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[11px] font-black uppercase flex items-center gap-1">
          <CheckCircle className="w-3 h-3" />
          Delivered
        </span>
      );
    }
    if (status === 'sent') {
      return (
        <span className="px-2.5 py-0.5 rounded-full bg-elder-blue-100 text-elder-blue-800 text-[11px] font-black uppercase flex items-center gap-1">
          <Send className="w-3 h-3" />
          Sent
        </span>
      );
    }
    return (
      <span className="px-2.5 py-0.5 rounded-full bg-red-100 text-red-800 text-[11px] font-black uppercase flex items-center gap-1" title={error}>
        <AlertTriangle className="w-3 h-3" />
        Failed
      </span>
    );
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="bg-white rounded-3xl max-w-3xl w-full p-6 sm:p-8 shadow-2xl my-6 flex flex-col justify-between max-h-[85vh] border border-slate-200">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-200 sticky top-0 bg-white z-10">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 rounded-2xl bg-elder-blue-100 text-elder-blue-800 flex items-center justify-center font-bold">
              <Mail className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-2xl font-black text-slate-900">
                Automated Notification & Email History
              </h2>
              <p className="text-xs text-slate-500 font-semibold">
                Transparent delivery tracking for dose reminders, missed medications, and doctor appointments.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 font-extrabold text-xs transition-all shadow-xs cursor-pointer flex-shrink-0"
            title="Close (ESC)"
          >
            <X className="w-5 h-5 stroke-[2.5]" />
            <span>Close ✕</span>
          </button>
        </div>

        {/* History List */}
        <div className="py-4 overflow-y-auto space-y-3 flex-1 pr-1">
          {notifications.map((notif) => (
            <div
              key={notif.id}
              className={`p-4 rounded-2xl border transition-all ${
                notif.status === 'failed' ? 'bg-red-50/50 border-red-200' : 'bg-slate-50 border-slate-200'
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start space-x-3">
                  <div className="p-2 rounded-xl bg-white shadow-xs border border-slate-200 flex-shrink-0 mt-0.5">
                    {getTypeIcon(notif.type)}
                  </div>
                  <div>
                    <h4 className="font-extrabold text-slate-900 text-sm">{notif.subject}</h4>
                    <p className="text-xs text-slate-500 font-medium mt-0.5">
                      To: <strong className="text-slate-800">{notif.recipientEmail}</strong> ({notif.recipientName || 'User'})
                    </p>
                    <p className="text-xs text-slate-600 mt-1 italic">
                      "{notif.bodyPreview}"
                    </p>
                    {notif.errorMessage && (
                      <p className="text-xs text-red-600 font-bold mt-1.5 flex items-center gap-1">
                        <AlertTriangle className="w-3.5 h-3.5" />
                        {notif.errorMessage}
                      </p>
                    )}
                  </div>
                </div>

                <div className="text-right flex-shrink-0 space-y-1">
                  {getStatusBadge(notif.status, notif.errorMessage)}
                  <p className="text-[11px] text-slate-400 font-mono">
                    {new Date(notif.sentAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
              </div>
            </div>
          ))}

          {notifications.length === 0 && (
            <div className="py-12 text-center text-slate-400">
              <Mail className="w-12 h-12 mx-auto mb-2 opacity-30" />
              <p className="font-bold text-sm">No notification logs recorded yet.</p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="pt-4 border-t border-slate-200 flex items-center justify-between text-xs">
          <span className="text-slate-500">
            Email Service Powered by <strong>Resend API</strong>
          </span>
          <button
            onClick={() => {
              onClose();
              onOpenSettingsModal();
            }}
            className="text-elder-blue-700 font-bold hover:underline"
          >
            Configure Email API Key in Settings →
          </button>
        </div>

      </div>
    </div>
  );
};
