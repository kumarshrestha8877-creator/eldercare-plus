import React, { useState, useEffect } from 'react';
import { 
  X, 
  Key, 
  Lock, 
  ShieldCheck, 
  Copy, 
  Check, 
  Users, 
  UserCheck 
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useAccessibility } from '../context/AccessibilityContext';

interface PasscodeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PasscodeModal: React.FC<PasscodeModalProps> = ({ isOpen, onClose }) => {
  const { 
    currentRole, 
    generatePasscode, 
    redeemPasscode, 
    passcodes 
  } = useAuth();
  
  const { playChime, speak } = useAccessibility();

  // Mode: if elderly, default to 'generate', otherwise 'redeem'
  const [activeTab, setActiveTab] = useState<'generate' | 'redeem'>(
    currentRole === 'elderly' ? 'generate' : 'redeem'
  );

  // Generate form
  const [targetRole, setTargetRole] = useState<'family' | 'caregiver'>('family');
  const [label, setLabel] = useState('');
  const [canMeds, setCanMeds] = useState(true);
  const [canApts, setCanApts] = useState(true);
  const [canHistory, setCanHistory] = useState(true);
  const [generatedCode, setGeneratedCode] = useState<string | null>(null);

  // Redeem form
  const [enteredPasscode, setEnteredPasscode] = useState('');
  const [redeemResult, setRedeemResult] = useState<{ success: boolean; msg: string } | null>(null);
  const [loading, setLoading] = useState(false);

  React.useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleGenerate = (e: React.FormEvent) => {
    e.preventDefault();
    const code = generatePasscode({
      targetRole,
      label: label || `Access for ${targetRole}`,
      canManageMedications: canMeds,
      canManageAppointments: canApts,
      canViewMedicalHistory: canHistory,
      expiryDays: 30,
    });
    setGeneratedCode(code.passcode);
  };

  const handleRedeem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!enteredPasscode.trim()) return;

    setLoading(true);
    setRedeemResult(null);

    const result = await redeemPasscode(enteredPasscode);
    setLoading(false);

    if (result.success) {
      setRedeemResult({ success: true, msg: result.message });
      speak('Passcode verified. Connected to healthcare profile.');
    } else {
      setRedeemResult({ success: false, msg: result.message });
      playChime('alert');
    }
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-md p-4 overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl my-6 flex flex-col justify-between max-h-[92vh] border border-slate-200">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-200 sticky top-0 bg-white z-10">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 rounded-2xl bg-purple-700 text-white flex items-center justify-center font-bold">
              <Key className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-2xl font-black text-slate-900">
                Family Access Passcode
              </h2>
              <p className="text-xs text-slate-500 font-semibold">
                Passcode verification & pairing system.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 font-extrabold text-xs transition-all shadow-xs cursor-pointer flex-shrink-0"
            title="Close (ESC)"
          >
            <X className="w-5 h-5 stroke-[2.5]" />
            <span>Close ✕</span>
          </button>
        </div>

        {/* Tab switch */}
        <div className="flex bg-slate-100 p-1 rounded-2xl my-4 text-xs font-bold">
          <button
            onClick={() => setActiveTab('generate')}
            className={`flex-1 py-2 rounded-xl transition-all ${
              activeTab === 'generate' ? 'bg-purple-700 text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Generate Passcode
          </button>
          <button
            onClick={() => setActiveTab('redeem')}
            className={`flex-1 py-2 rounded-xl transition-all ${
              activeTab === 'redeem' ? 'bg-purple-700 text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Enter / Redeem Passcode
          </button>
        </div>

        {/* Generate View */}
        {activeTab === 'generate' ? (
          <div>
            {!generatedCode ? (
              <form onSubmit={handleGenerate} className="space-y-4">
                <div>
                  <label className="block text-xs font-black uppercase text-slate-700 mb-1">
                    Target Role
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setTargetRole('family')}
                      className={`py-2.5 px-3 rounded-xl font-bold text-xs border text-center transition-all ${
                        targetRole === 'family' ? 'bg-elder-blue-700 text-white border-elder-blue-700' : 'border-slate-300 text-slate-700'
                      }`}
                    >
                      Family Member
                    </button>
                    <button
                      type="button"
                      onClick={() => setTargetRole('caregiver')}
                      className={`py-2.5 px-3 rounded-xl font-bold text-xs border text-center transition-all ${
                        targetRole === 'caregiver' ? 'bg-purple-700 text-white border-purple-700' : 'border-slate-300 text-slate-700'
                      }`}
                    >
                      Caregiver / Nurse
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-black uppercase text-slate-700 mb-1">
                    Label (e.g. For Daughter Priya)
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. For daughter or home nurse"
                    value={label}
                    onChange={(e) => setLabel(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-300 font-semibold text-xs focus:ring-2 focus:ring-purple-600 focus:outline-none"
                  />
                </div>

                <div className="space-y-2 pt-1">
                  <label className="flex items-center space-x-2 text-xs font-bold text-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={canMeds}
                      onChange={(e) => setCanMeds(e.target.checked)}
                      className="rounded text-purple-600"
                    />
                    <span>Permission to view & edit medications</span>
                  </label>

                  <label className="flex items-center space-x-2 text-xs font-bold text-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={canApts}
                      onChange={(e) => setCanApts(e.target.checked)}
                      className="rounded text-purple-600"
                    />
                    <span>Permission to manage doctor appointments</span>
                  </label>
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 rounded-2xl bg-purple-700 hover:bg-purple-800 text-white font-extrabold text-sm shadow-md transition-all mt-4"
                >
                  Generate Secure Passcode
                </button>
              </form>
            ) : (
              <div className="py-6 text-center space-y-4">
                <span className="text-xs uppercase font-extrabold text-purple-700 tracking-wider">
                  Passcode Generated Successfully
                </span>

                <div className="p-5 rounded-2xl bg-purple-50 border-2 border-purple-300 font-mono font-black text-3xl tracking-widest text-purple-950 flex items-center justify-center space-x-3">
                  <span>{generatedCode}</span>
                </div>

                <p className="text-xs text-slate-600 font-medium max-w-sm mx-auto">
                  Share this code with your family member or caregiver. They can enter it from their dashboard to connect.
                </p>

                <div className="flex gap-2 pt-2">
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(generatedCode);
                      playChime('click');
                      speak('Passcode copied to clipboard');
                    }}
                    className="flex-1 py-3 rounded-xl bg-purple-700 hover:bg-purple-800 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md"
                  >
                    <Copy className="w-4 h-4" />
                    <span>Copy Passcode</span>
                  </button>

                  <button
                    onClick={() => setGeneratedCode(null)}
                    className="px-4 py-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs"
                  >
                    Done
                  </button>
                </div>
              </div>
            )}
          </div>
        ) : (
          <form onSubmit={handleRedeem} className="space-y-4 py-2">
            <p className="text-xs text-slate-600 font-medium">
              Enter the unique passcode provided by the elderly individual (e.g. <code className="bg-slate-100 px-1 py-0.5 rounded font-mono font-bold">FAMILY-8492</code> or <code className="bg-slate-100 px-1 py-0.5 rounded font-mono font-bold">CARE-5120</code>).
            </p>

            <div>
              <input
                type="text"
                required
                placeholder="ENTER PASSCODE..."
                value={enteredPasscode}
                onChange={(e) => setEnteredPasscode(e.target.value)}
                className="w-full px-4 py-3 rounded-2xl border-2 border-slate-300 font-mono font-black text-center text-xl uppercase tracking-widest focus:border-purple-600 focus:outline-none"
              />
            </div>

            {redeemResult && (
              <p className={`text-xs font-bold text-center ${
                redeemResult.success ? 'text-emerald-700' : 'text-red-600'
              }`}>
                {redeemResult.msg}
              </p>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3.5 rounded-2xl bg-purple-700 hover:bg-purple-800 text-white font-extrabold text-sm shadow-md transition-all disabled:opacity-50"
            >
              {loading ? 'Verifying...' : 'Verify & Connect Access'}
            </button>
          </form>
        )}

      </div>
    </div>
  );
};
