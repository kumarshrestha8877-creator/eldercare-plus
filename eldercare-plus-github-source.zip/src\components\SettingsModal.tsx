import React, { useState, useEffect } from 'react';
import { 
  X, 
  Settings, 
  Database, 
  Mail, 
  Key, 
  Check, 
  RotateCcw, 
  ExternalLink, 
  AlertCircle,
  ShieldCheck,
  Send,
  Inbox,
  Sparkles
} from 'lucide-react';
import { 
  getStoredResendKey, 
  setStoredResendKey, 
  sendEmailNotification, 
  isSandboxMailMode, 
  setMailMode 
} from '../lib/resend';
import { getSupabaseConfig, setSupabaseConfig, localStore } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { useAccessibility } from '../context/AccessibilityContext';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenMailbox?: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ 
  isOpen, 
  onClose,
  onOpenMailbox 
}) => {
  const { playChime, speak } = useAccessibility();
  const { currentUser } = useAuth();

  const currentSupabase = getSupabaseConfig();
  const currentResendKey = getStoredResendKey();

  const [mailModeChoice, setMailModeChoice] = useState<'sandbox' | 'live'>(
    isSandboxMailMode() ? 'sandbox' : 'live'
  );
  const [supabaseUrl, setSupabaseUrl] = useState(currentSupabase.url);
  const [supabaseKey, setSupabaseKey] = useState(currentSupabase.key);
  const [resendKey, setResendKey] = useState(currentResendKey);

  const [savedSuccess, setSavedSuccess] = useState(false);
  const [testEmailAddress, setTestEmailAddress] = useState(currentUser.email);
  const [testEmailResult, setTestEmailResult] = useState<{ success: boolean; msg: string; isSandbox?: boolean } | null>(null);
  const [isSendingTest, setIsSendingTest] = useState(false);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleSaveCredentials = (e: React.FormEvent) => {
    e.preventDefault();
    setSupabaseConfig(supabaseUrl, supabaseKey);
    setStoredResendKey(resendKey);
    setMailMode(mailModeChoice);
    setSavedSuccess(true);
    playChime('success');
    speak('Platform settings saved successfully.');
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const handleSendTestEmail = async () => {
    if (!testEmailAddress.trim()) return;
    setIsSendingTest(true);
    setTestEmailResult(null);

    // If in live mode but no key entered, prompt to use Sandbox mode
    if (mailModeChoice === 'live' && !resendKey.trim()) {
      setIsSendingTest(false);
      setTestEmailResult({
        success: false,
        msg: 'Live Resend API key is not configured. Switch to "Virtual Mailbox Sandbox" above or enter a valid Resend key (`re_...`).',
      });
      playChime('alert');
      return;
    }

    const result = await sendEmailNotification({
      to: testEmailAddress,
      recipientName: currentUser.fullName || 'Eleanor Vance',
      subject: 'ElderCare+ Dose Reminder: Metformin 500mg with Dinner',
      type: 'upcoming_dose',
      patientName: 'Eleanor Vance',
      details: {
        medicineName: 'Metformin Hydrochloride (500mg)',
        dosage: '1 tablet with warm meal',
        time: '08:00 PM',
        foodInstruction: 'With Food / Dinner',
      },
    });

    setIsSendingTest(false);
    if (result.success) {
      if (result.isSandbox) {
        setTestEmailResult({
          success: true,
          msg: `✅ Test email successfully rendered and delivered to your in-app Virtual Mailbox!`,
          isSandbox: true,
        });
      } else {
        setTestEmailResult({
          success: true,
          msg: `✅ Real email successfully dispatched to ${testEmailAddress} via Resend! (Message ID: ${result.messageId})`,
          isSandbox: false,
        });
      }
      playChime('success');
      speak('Test email dispatched successfully.');
    } else {
      setTestEmailResult({
        success: false,
        msg: result.error || 'Failed to dispatch email. Please check your credentials.',
      });
      playChime('alert');
    }
  };

  const handleResetData = () => {
    if (confirm('Reset all demonstration data (medications, appointments, passcodes) to initial default states?')) {
      localStore.resetToDefault();
      window.location.reload();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-md p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl my-6 flex flex-col justify-between max-h-[90vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-200">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 rounded-2xl bg-slate-900 text-white flex items-center justify-center font-bold">
              <Settings className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-2xl font-black text-slate-900">
                System & API Service Settings
              </h2>
              <p className="text-xs text-slate-500 font-semibold">
                Configure real Supabase PostgreSQL backend and Resend automated email delivery.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 font-extrabold text-xs transition-all shadow-xs cursor-pointer"
            title="Close (ESC)"
          >
            <X className="w-5 h-5 stroke-[2.5]" />
            <span>Close ✕</span>
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSaveCredentials} className="py-5 space-y-6 overflow-y-auto pr-1">
          
          {savedSuccess && (
            <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-300 text-emerald-900 text-xs font-bold flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-600" />
              <span>Configuration saved successfully!</span>
            </div>
          )}

          {/* Resend Automated Email Service Section */}
          <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2 text-slate-900 font-black text-base">
                <Mail className="w-5 h-5 text-elder-blue-700" />
                <span>Automated Email Reminder Service</span>
              </div>
              <span className={`text-[10px] font-black uppercase px-2.5 py-1 rounded-full ${
                mailModeChoice === 'sandbox' 
                  ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' 
                  : resendKey 
                  ? 'bg-elder-blue-100 text-elder-blue-800 border border-elder-blue-300' 
                  : 'bg-amber-100 text-amber-800'
              }`}>
                {mailModeChoice === 'sandbox' 
                  ? 'SANDBOX ACTIVE (Ready to Test)' 
                  : resendKey 
                  ? 'LIVE RESEND READY' 
                  : 'KEY REQUIRED'}
              </span>
            </div>

            <p className="text-xs text-slate-600 font-medium">
              Powers real-time email reminders for scheduled medication doses, missed medication alerts to caregivers, and Emergency SOS broadcasts.
            </p>

            {/* Mode Selector */}
            <div className="bg-white p-3 rounded-2xl border border-slate-200 space-y-2">
              <label className="block text-xs font-black uppercase text-slate-700 mb-1">
                Choose Email Dispatch Mode:
              </label>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setMailModeChoice('sandbox');
                    setMailMode('sandbox');
                  }}
                  className={`p-3 rounded-xl border text-left transition-all ${
                    mailModeChoice === 'sandbox'
                      ? 'bg-emerald-50 border-emerald-400 ring-2 ring-emerald-500/20'
                      : 'border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-extrabold text-xs text-emerald-950 flex items-center gap-1.5">
                      <Inbox className="w-3.5 h-3.5 text-emerald-700" />
                      Virtual Mailbox Sandbox
                    </span>
                    <span className="text-[10px] bg-emerald-200 text-emerald-900 font-bold px-1.5 py-0.2 rounded">Recommended</span>
                  </div>
                  <p className="text-[11px] text-slate-500 font-medium">
                    No external API keys required! Generates full HTML emails and delivers them to the in-app interactive test mailbox.
                  </p>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setMailModeChoice('live');
                    setMailMode('live');
                  }}
                  className={`p-3 rounded-xl border text-left transition-all ${
                    mailModeChoice === 'live'
                      ? 'bg-elder-blue-50 border-elder-blue-400 ring-2 ring-elder-blue-500/20'
                      : 'border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-extrabold text-xs text-slate-900 flex items-center gap-1.5">
                      <Mail className="w-3.5 h-3.5 text-elder-blue-700" />
                      Live Resend Cloud API
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 font-medium">
                    Delivers emails directly to real external inboxes using your free Resend account.
                  </p>
                </button>
              </div>
            </div>

            {/* Resend Key Input (if live mode chosen) */}
            {mailModeChoice === 'live' && (
              <div className="p-3 bg-white rounded-xl border border-slate-200 space-y-2">
                <label className="block text-xs font-black uppercase text-slate-700">
                  Resend API Key (`re_...`)
                </label>
                <input
                  type="password"
                  placeholder="re_123456789_abcdefg..."
                  value={resendKey}
                  onChange={(e) => setResendKey(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 font-mono text-xs focus:ring-2 focus:ring-elder-blue-600 focus:outline-none"
                />
                <p className="text-[11px] text-slate-400">
                  Get a free key from <a href="https://resend.com" target="_blank" rel="noreferrer" className="text-elder-blue-700 underline font-bold">resend.com</a>. Free tier includes 3,000 emails/month.
                </p>
              </div>
            )}

            {/* Test Email Dispatcher */}
            <div className="pt-3 border-t border-slate-200">
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Send a Test Email:
              </label>
              <div className="flex gap-2">
                <input
                  type="email"
                  placeholder="your-email@domain.com"
                  value={testEmailAddress}
                  onChange={(e) => setTestEmailAddress(e.target.value)}
                  className="flex-1 px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs font-medium focus:outline-none"
                />
                <button
                  type="button"
                  onClick={handleSendTestEmail}
                  disabled={isSendingTest}
                  className="px-5 py-2.5 bg-elder-blue-700 hover:bg-elder-blue-800 text-white font-extrabold text-xs rounded-xl flex items-center gap-1.5 shadow-sm disabled:opacity-50"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{isSendingTest ? 'Sending...' : 'Test Send'}</span>
                </button>
              </div>

              {testEmailResult && (
                <div className={`mt-3 p-3 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs font-semibold ${
                  testEmailResult.success 
                    ? 'bg-emerald-50 border-emerald-200 text-emerald-900' 
                    : 'bg-red-50 border-red-200 text-red-900'
                }`}>
                  <span>{testEmailResult.msg}</span>
                  {testEmailResult.isSandbox && onOpenMailbox && (
                    <button
                      type="button"
                      onClick={() => {
                        onClose();
                        onOpenMailbox();
                      }}
                      className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-lg self-start sm:self-center flex items-center gap-1"
                    >
                      <Inbox className="w-3.5 h-3.5" />
                      <span>Open Test Inbox</span>
                    </button>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Supabase Database Section */}
          <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2 text-slate-900 font-black text-sm">
                <Database className="w-4 h-4 text-emerald-700" />
                <span>Supabase PostgreSQL & Auth</span>
              </div>
              <span className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-full ${
                supabaseUrl && supabaseKey ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-700'
              }`}>
                {supabaseUrl && supabaseKey ? 'Connected' : 'Local Storage Mode'}
              </span>
            </div>

            <p className="text-xs text-slate-600 font-medium">
              ElderCare+ works seamlessly out of the box with our rich demonstration data, or syncs with your production Supabase database. SQL setup script is included in <code className="bg-slate-200 px-1 py-0.5 rounded text-[11px] font-mono">supabase-schema.sql</code>.
            </p>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-black uppercase text-slate-700 mb-1">
                  Supabase Project URL
                </label>
                <input
                  type="url"
                  placeholder="https://xyzcompany.supabase.co"
                  value={supabaseUrl}
                  onChange={(e) => setSupabaseUrl(e.target.value)}
                  className="w-full px-4 py-2 rounded-xl border border-slate-300 font-mono text-xs focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-black uppercase text-slate-700 mb-1">
                  Supabase Anon Key
                </label>
                <input
                  type="password"
                  placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                  value={supabaseKey}
                  onChange={(e) => setSupabaseKey(e.target.value)}
                  className="w-full px-4 py-2 rounded-xl border border-slate-300 font-mono text-xs focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                />
              </div>
            </div>
          </div>

          <div className="flex space-x-3 pt-2">
            <button
              type="submit"
              className="flex-1 py-3.5 rounded-2xl bg-slate-900 hover:bg-black text-white font-extrabold text-sm shadow-md"
            >
              Save Settings
            </button>
          </div>
        </form>

        {/* Footer with Reset */}
        <div className="pt-4 border-t border-slate-200 flex items-center justify-between text-xs">
          <span className="text-slate-500">ElderCare+ Hackathon Edition</span>
          <button
            onClick={handleResetData}
            className="text-red-600 font-bold hover:underline flex items-center gap-1"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Demo Data</span>
          </button>
        </div>

      </div>
    </div>
  );
};
