import React, { useState } from 'react';
import { 
  Heart, 
  ShieldCheck, 
  Key, 
  AlertTriangle, 
  Plus, 
  Trash2, 
  Copy, 
  Check, 
  UserCheck, 
  Lock, 
  Eye, 
  Clock, 
  Activity,
  Edit2,
  Users
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useAccessibility } from '../context/AccessibilityContext';
import { EmergencyContact } from '../types';

export const SharedHealthProfile: React.FC = () => {
  const { 
    currentUser, 
    currentRole, 
    healthcareProfile, 
    updateHealthcareProfile, 
    emergencyContacts, 
    addEmergencyContact, 
    deleteEmergencyContact,
    passcodes, 
    generatePasscode, 
    revokePasscode, 
    relations, 
    updateRelationPermissions, 
    revokeRelation,
    auditLogs
  } = useAuth();

  const { playChime, speak } = useAccessibility();

  // Modals
  const [isPasscodeModalOpen, setIsPasscodeModalOpen] = useState(false);
  const [isContactModalOpen, setIsContactModalOpen] = useState(false);
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  // New Passcode Form
  const [targetRole, setTargetRole] = useState<'family' | 'caregiver'>('family');
  const [passcodeLabel, setPasscodeLabel] = useState('');
  const [canManageMeds, setCanManageMeds] = useState(true);
  const [canManageApts, setCanManageApts] = useState(true);
  const [canViewHistory, setCanViewHistory] = useState(true);
  const [expiryDays, setExpiryDays] = useState(30);

  // New Emergency Contact Form
  const [contactName, setContactName] = useState('');
  const [relationship, setRelationship] = useState('Daughter');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [isPrimary, setIsPrimary] = useState(false);
  const [canReceiveSos, setCanReceiveSos] = useState(true);

  const handleCopy = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    playChime('click');
    speak(`Copied passcode ${code}`);
    setTimeout(() => setCopiedCode(null), 2500);
  };

  const handleGeneratePasscode = (e: React.FormEvent) => {
    e.preventDefault();
    generatePasscode({
      targetRole,
      label: passcodeLabel || `Passcode for ${targetRole}`,
      canManageMedications: canManageMeds,
      canManageAppointments: canManageApts,
      canViewMedicalHistory: canViewHistory,
      expiryDays,
    });
    setIsPasscodeModalOpen(false);
    setPasscodeLabel('');
  };

  const handleAddContact = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactName.trim() || !phone.trim()) return;

    addEmergencyContact({
      elderlyUserId: healthcareProfile.elderlyUserId,
      contactName,
      relationship,
      phone,
      email,
      isPrimary,
      canReceiveSosEmail: canReceiveSos,
    });

    setIsContactModalOpen(false);
    setContactName('');
    setPhone('');
    setEmail('');
  };

  return (
    <div className="space-y-8 pb-16">
      
      {/* 1. Header with Patient Information */}
      <section className="bg-white rounded-3xl border border-slate-200/80 p-6 sm:p-8 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-center space-x-4">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-elder-green-600 to-elder-green-800 text-white flex items-center justify-center font-black text-2xl shadow-md">
              EV
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-3xl font-black text-slate-900">Eleanor Vance</h1>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-black bg-elder-green-100 text-elder-green-800 border border-elder-green-300">
                  Primary Patient
                </span>
              </div>
              <p className="text-slate-500 text-xs sm:text-sm font-semibold mt-0.5">
                Born: April 18, 1952 (Age 74) • Blood Group: <strong className="text-slate-800">{healthcareProfile.bloodGroup}</strong>
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => setIsContactModalOpen(true)}
              className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs border border-slate-300 transition-all"
            >
              + Add Emergency Contact
            </button>

            <button
              onClick={() => setIsPasscodeModalOpen(true)}
              className="px-4 py-2.5 rounded-xl bg-purple-700 hover:bg-purple-800 text-white font-bold text-xs shadow-md transition-all flex items-center gap-1.5"
            >
              <Key className="w-4 h-4" />
              <span>Generate Access Passcode</span>
            </button>
          </div>
        </div>

        {/* Clinical Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8 pt-6 border-t border-slate-100">
          
          {/* Allergies */}
          <div className="p-4 rounded-2xl bg-red-50 border border-red-200">
            <h3 className="text-xs uppercase font-extrabold tracking-wider text-red-900 flex items-center gap-1.5 mb-2">
              <AlertTriangle className="w-4 h-4 text-red-600" />
              Documented Allergies
            </h3>
            <div className="space-y-1">
              {healthcareProfile.knownAllergies.map((a, i) => (
                <p key={i} className="text-xs font-bold text-red-800">• {a}</p>
              ))}
            </div>
          </div>

          {/* Chronic Conditions */}
          <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200">
            <h3 className="text-xs uppercase font-extrabold tracking-wider text-amber-900 flex items-center gap-1.5 mb-2">
              <Activity className="w-4 h-4 text-amber-600" />
              Chronic Conditions
            </h3>
            <div className="space-y-1">
              {healthcareProfile.chronicConditions.map((c, i) => (
                <p key={i} className="text-xs font-bold text-amber-900">• {c}</p>
              ))}
            </div>
          </div>

          {/* Primary Doctor & Hospital */}
          <div className="p-4 rounded-2xl bg-elder-green-50 border border-elder-green-200">
            <h3 className="text-xs uppercase font-extrabold tracking-wider text-elder-green-900 flex items-center gap-1.5 mb-2">
              <Heart className="w-4 h-4 text-elder-green-700" />
              Primary Physician
            </h3>
            <p className="text-xs font-black text-slate-900">{healthcareProfile.primaryPhysicianName}</p>
            <p className="text-[11px] text-slate-600 mt-0.5">{healthcareProfile.hospitalPreference}</p>
            <p className="text-[11px] font-bold text-elder-green-800 mt-1">Tel: {healthcareProfile.primaryPhysicianPhone}</p>
          </div>

        </div>
      </section>

      {/* 2. PASSCODE-BASED ACCESS CONTROL (Mandatory Core Hackathon Requirement) */}
      <section className="bg-white rounded-3xl border border-slate-200/80 p-6 sm:p-8 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <div className="flex items-center space-x-2 text-purple-700 font-bold text-xs uppercase tracking-wider mb-1">
              <Lock className="w-4 h-4" />
              <span>Passcode-Based Family Access System</span>
            </div>
            <h2 className="text-2xl font-black text-slate-900">
              Active Access Passcodes
            </h2>
            <p className="text-slate-500 text-xs sm:text-sm font-medium mt-1">
              Passcodes allow family members and caregivers to pair securely with your healthcare profile.
            </p>
          </div>

          <button
            onClick={() => setIsPasscodeModalOpen(true)}
            className="px-4 py-2.5 rounded-xl bg-purple-700 hover:bg-purple-800 text-white font-bold text-xs shadow-md transition-all flex items-center gap-1.5 self-start sm:self-center"
          >
            <Plus className="w-4 h-4" />
            <span>Generate New Passcode</span>
          </button>
        </div>

        {/* Passcode Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 text-xs font-black text-slate-500 uppercase tracking-wider">
                <th className="pb-3 px-3">Passcode</th>
                <th className="pb-3 px-3">Target Role & Label</th>
                <th className="pb-3 px-3">Configured Permissions</th>
                <th className="pb-3 px-3">Status / Expiry</th>
                <th className="pb-3 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm">
              {passcodes.map((code) => {
                const isExpired = new Date(code.expiresAt) < new Date();
                return (
                  <tr key={code.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-4 px-3">
                      <div className="flex items-center space-x-2">
                        <span className="font-mono text-base font-black tracking-wider text-purple-900 bg-purple-100 px-3 py-1 rounded-xl">
                          {code.passcode}
                        </span>
                        <button
                          onClick={() => handleCopy(code.passcode)}
                          className="p-1.5 text-slate-400 hover:text-purple-700"
                          title="Copy passcode"
                        >
                          {copiedCode === code.passcode ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                        </button>
                      </div>
                    </td>

                    <td className="py-4 px-3">
                      <div className="font-bold text-slate-900 capitalize">{code.targetRole} Member</div>
                      <div className="text-xs text-slate-500 font-medium">{code.label}</div>
                    </td>

                    <td className="py-4 px-3 text-xs">
                      <div className="flex flex-wrap gap-1">
                        {code.canManageMedications && (
                          <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-semibold">
                            Medications
                          </span>
                        )}
                        {code.canManageAppointments && (
                          <span className="px-2 py-0.5 rounded-full bg-elder-blue-100 text-elder-blue-800 font-semibold">
                            Appointments
                          </span>
                        )}
                        {code.canViewMedicalHistory && (
                          <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 font-semibold">
                            Full Medical
                          </span>
                        )}
                      </div>
                    </td>

                    <td className="py-4 px-3 text-xs">
                      {code.isRevoked ? (
                        <span className="px-2.5 py-1 rounded-full bg-red-100 text-red-800 font-bold">
                          Revoked
                        </span>
                      ) : isExpired ? (
                        <span className="px-2.5 py-1 rounded-full bg-amber-100 text-amber-800 font-bold">
                          Expired
                        </span>
                      ) : (
                        <div>
                          <span className="px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 font-bold">
                            Active ({code.usedCount}/{code.maxUses} used)
                          </span>
                          <p className="text-[11px] text-slate-400 mt-1">
                            Expires {new Date(code.expiresAt).toLocaleDateString()}
                          </p>
                        </div>
                      )}
                    </td>

                    <td className="py-4 px-3 text-right">
                      {!code.isRevoked && (
                        <button
                          onClick={() => {
                            if (confirm(`Revoke passcode ${code.passcode}?`)) {
                              revokePasscode(code.id);
                            }
                          }}
                          className="px-3 py-1.5 rounded-xl text-red-600 hover:bg-red-50 text-xs font-bold transition-all"
                        >
                          Revoke
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>

      {/* 3. Connected Family Members & Caregivers List */}
      <section className="bg-white rounded-3xl border border-slate-200/80 p-6 sm:p-8 shadow-sm">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-black text-slate-900">
              Connected Healthcare Team & Family
            </h2>
            <p className="text-slate-500 text-xs sm:text-sm font-medium mt-1">
              Authorized individual accounts with active access to your medications and appointments.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {relations.map((rel) => (
            <div key={rel.id} className="p-5 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col justify-between">
              <div>
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 rounded-full bg-purple-200 text-purple-900 flex items-center justify-center font-black text-base">
                      {rel.memberName.charAt(0)}
                    </div>
                    <div>
                      <h4 className="font-extrabold text-slate-900 text-base">{rel.memberName}</h4>
                      <p className="text-xs text-purple-800 font-bold">{rel.relationshipLabel}</p>
                      <p className="text-xs text-slate-500 font-mono mt-0.5">{rel.memberEmail}</p>
                    </div>
                  </div>

                  <span className="px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold">
                    Active
                  </span>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-200/60 space-y-2 text-xs">
                  <p className="font-extrabold text-slate-700">Access Permissions:</p>
                  <div className="flex flex-wrap gap-2">
                    <span className={`px-2 py-0.5 rounded-md font-semibold ${
                      rel.canManageMedications ? 'bg-emerald-100 text-emerald-900' : 'bg-slate-200 text-slate-500 line-through'
                    }`}>
                      Medications
                    </span>
                    <span className={`px-2 py-0.5 rounded-md font-semibold ${
                      rel.canManageAppointments ? 'bg-emerald-100 text-emerald-900' : 'bg-slate-200 text-slate-500 line-through'
                    }`}>
                      Appointments
                    </span>
                    <span className={`px-2 py-0.5 rounded-md font-semibold ${
                      rel.notifyOnMissedDose ? 'bg-elder-blue-100 text-elder-blue-900' : 'bg-slate-200 text-slate-500'
                    }`}>
                      Missed Dose Alerts
                    </span>
                  </div>
                </div>
              </div>

              <div className="mt-5 pt-3 border-t border-slate-200 flex items-center justify-between text-xs">
                <span className="text-slate-400">Joined {new Date(rel.joinedAt).toLocaleDateString()}</span>
                <button
                  onClick={() => {
                    if (confirm(`Revoke access for ${rel.memberName}? They will no longer be able to view your profile.`)) {
                      revokeRelation(rel.id);
                    }
                  }}
                  className="text-red-600 font-bold hover:underline"
                >
                  Revoke Access
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 4. Emergency Contacts Table */}
      <section className="bg-white rounded-3xl border border-slate-200/80 p-6 sm:p-8 shadow-sm">
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-red-100 text-red-700 flex items-center justify-center font-bold">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-black text-slate-900">Registered Emergency Contacts</h2>
              <p className="text-xs text-slate-500 font-medium">Alerted instantly when Emergency SOS is triggered</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {emergencyContacts.map((c) => (
            <div key={c.id} className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <h4 className="font-extrabold text-slate-900 text-sm">{c.contactName}</h4>
                  {c.isPrimary && (
                    <span className="px-2 py-0.5 rounded-full bg-red-100 text-red-800 text-[10px] font-black uppercase">
                      Primary
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-600 font-semibold">{c.relationship}</p>
                <p className="text-xs text-slate-800 font-bold mt-2">📞 {c.phone}</p>
                {c.email && <p className="text-xs text-slate-500 mt-0.5">✉️ {c.email}</p>}
              </div>

              {!c.isPrimary && (
                <div className="mt-4 pt-2 border-t border-slate-200 text-right">
                  <button
                    onClick={() => deleteEmergencyContact(c.id)}
                    className="text-xs text-red-600 font-bold hover:underline"
                  >
                    Remove Contact
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* Generate Passcode Modal */}
      {isPasscodeModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl my-8">
            <h2 className="text-2xl font-black text-slate-900 pb-4 border-b border-slate-100">
              Generate Family Access Passcode
            </h2>

            <form onSubmit={handleGeneratePasscode} className="space-y-4 mt-4">
              <div>
                <label className="block text-xs font-black uppercase text-slate-700 mb-1">
                  Target Member Role *
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setTargetRole('family')}
                    className={`py-3 px-4 rounded-xl font-bold text-xs border text-center transition-all ${
                      targetRole === 'family' ? 'bg-elder-blue-700 text-white border-elder-blue-700 shadow-sm' : 'border-slate-300 text-slate-700'
                    }`}
                  >
                    Family Member
                  </button>
                  <button
                    type="button"
                    onClick={() => setTargetRole('caregiver')}
                    className={`py-3 px-4 rounded-xl font-bold text-xs border text-center transition-all ${
                      targetRole === 'caregiver' ? 'bg-purple-700 text-white border-purple-700 shadow-sm' : 'border-slate-300 text-slate-700'
                    }`}
                  >
                    Caregiver / Nurse
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-black uppercase text-slate-700 mb-1">
                  Label / Description
                </label>
                <input
                  type="text"
                  placeholder="e.g. For daughter Priya or visiting nurse"
                  value={passcodeLabel}
                  onChange={(e) => setPasscodeLabel(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 font-semibold focus:ring-2 focus:ring-purple-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-black uppercase text-slate-700 mb-2">
                  Configurable Permissions
                </label>
                <div className="space-y-2">
                  <label className="flex items-center space-x-2 text-xs font-bold text-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={canManageMeds}
                      onChange={(e) => setCanManageMeds(e.target.checked)}
                      className="rounded text-purple-600"
                    />
                    <span>Allow adding & editing medication schedules</span>
                  </label>

                  <label className="flex items-center space-x-2 text-xs font-bold text-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={canManageApts}
                      onChange={(e) => setCanManageApts(e.target.checked)}
                      className="rounded text-purple-600"
                    />
                    <span>Allow managing doctor appointments</span>
                  </label>

                  <label className="flex items-center space-x-2 text-xs font-bold text-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={canViewHistory}
                      onChange={(e) => setCanViewHistory(e.target.checked)}
                      className="rounded text-purple-600"
                    />
                    <span>Allow viewing full medical history & allergies</span>
                  </label>
                </div>
              </div>

              <div>
                <label className="block text-xs font-black uppercase text-slate-700 mb-1">
                  Passcode Expiration
                </label>
                <select
                  value={expiryDays}
                  onChange={(e) => setExpiryDays(Number(e.target.value))}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 font-semibold focus:ring-2 focus:ring-purple-600 focus:outline-none"
                >
                  <option value={7}>7 Days</option>
                  <option value={14}>14 Days</option>
                  <option value={30}>30 Days (Recommended)</option>
                  <option value={90}>90 Days</option>
                </select>
              </div>

              <div className="flex space-x-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsPasscodeModalOpen(false)}
                  className="flex-1 py-3 rounded-xl border border-slate-300 font-bold text-slate-700 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-3 rounded-xl bg-purple-700 hover:bg-purple-800 text-white font-extrabold shadow-md"
                >
                  Generate Passcode
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Emergency Contact Modal */}
      {isContactModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl my-8">
            <h2 className="text-2xl font-black text-slate-900 pb-4 border-b border-slate-100">
              Add Emergency Contact
            </h2>

            <form onSubmit={handleAddContact} className="space-y-4 mt-4">
              <div>
                <label className="block text-xs font-black uppercase text-slate-700 mb-1">
                  Contact Full Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Arjun Vance"
                  value={contactName}
                  onChange={(e) => setContactName(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 font-semibold focus:ring-2 focus:ring-elder-green-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-black uppercase text-slate-700 mb-1">
                  Relationship *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Son, Neighbor, Family Doctor"
                  value={relationship}
                  onChange={(e) => setRelationship(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 font-semibold focus:ring-2 focus:ring-elder-green-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-black uppercase text-slate-700 mb-1">
                  Phone Number *
                </label>
                <input
                  type="tel"
                  required
                  placeholder="e.g. +1 (555) 345-6789"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 font-semibold focus:ring-2 focus:ring-elder-green-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-black uppercase text-slate-700 mb-1">
                  Email Address (For SOS Notifications)
                </label>
                <input
                  type="email"
                  placeholder="e.g. arjun@family.org"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 font-semibold focus:ring-2 focus:ring-elder-green-600 focus:outline-none"
                />
              </div>

              <div className="flex space-x-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsContactModalOpen(false)}
                  className="flex-1 py-3 rounded-xl border border-slate-300 font-bold text-slate-700 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-3 rounded-xl bg-elder-green-700 hover:bg-elder-green-800 text-white font-extrabold shadow-md"
                >
                  Add Contact
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
