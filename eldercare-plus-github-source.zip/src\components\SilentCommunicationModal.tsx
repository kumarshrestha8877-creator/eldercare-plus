import React, { useState, useEffect } from 'react';
import { 
  X, 
  Check, 
  Volume2, 
  Droplet, 
  Flame, 
  PhoneCall, 
  HelpCircle, 
  Send, 
  Utensils, 
  Thermometer, 
  Pill, 
  Sparkles,
  Bath
} from 'lucide-react';
import { useAccessibility } from '../context/AccessibilityContext';
import { useAuth } from '../context/AuthContext';

interface SilentCommunicationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface AACButton {
  id: string;
  icon: React.ReactNode;
  labelEn: string;
  labelHi: string;
  labelBn: string;
  speechTextEn: string;
  speechTextHi: string;
  speechTextBn: string;
  bgGradient: string;
  textColor: string;
  isUrgent?: boolean;
}

export const SilentCommunicationModal: React.FC<SilentCommunicationModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { speak, playChime, settings } = useAccessibility();
  const { triggerEmergencySos, currentUser } = useAuth();
  const [customText, setCustomText] = useState('');
  const [lastSpokenPhrase, setLastSpokenPhrase] = useState<string | null>(null);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const currentLang = settings.language;

  const aacButtons: AACButton[] = [
    {
      id: 'yes',
      icon: <Check className="w-9 h-9 stroke-[3]" />,
      labelEn: 'YES',
      labelHi: 'हाँ (YES)',
      labelBn: 'হ্যাঁ (YES)',
      speechTextEn: 'Yes, I agree.',
      speechTextHi: 'हाँ, मैं सहमत हूँ।',
      speechTextBn: 'হ্যাঁ, আমি সম্মত।',
      bgGradient: 'from-emerald-500 to-emerald-700',
      textColor: 'text-white',
    },
    {
      id: 'no',
      icon: <X className="w-9 h-9 stroke-[3]" />,
      labelEn: 'NO',
      labelHi: 'नहीं (NO)',
      labelBn: 'না (NO)',
      speechTextEn: 'No, thank you.',
      speechTextHi: 'नहीं, धन्यवाद।',
      speechTextBn: 'না, ধন্যবাদ।',
      bgGradient: 'from-red-500 to-red-700',
      textColor: 'text-white',
    },
    {
      id: 'water',
      icon: <Droplet className="w-9 h-9" />,
      labelEn: 'I NEED WATER',
      labelHi: 'मुझे पानी चाहिए',
      labelBn: 'আমার জল লাগবে',
      speechTextEn: 'Please give me a glass of water.',
      speechTextHi: 'कृपया मुझे एक गिलास पानी दें।',
      speechTextBn: 'দয়া করে আমাকে এক গ্লাস জল দিন।',
      bgGradient: 'from-sky-500 to-blue-700',
      textColor: 'text-white',
    },
    {
      id: 'pain',
      icon: <Flame className="w-9 h-9" />,
      labelEn: 'I AM IN PAIN',
      labelHi: 'मुझे दर्द हो रहा है',
      labelBn: 'আমার শরীরে ব্যথা হচ্ছে',
      speechTextEn: 'I am experiencing pain and need assistance.',
      speechTextHi: 'मुझे तेज दर्द हो रहा है, कृपया मदद करें।',
      speechTextBn: 'আমার শরীরে খুব কষ্ট ও ব্যথা হচ্ছে।',
      bgGradient: 'from-rose-600 to-red-800',
      textColor: 'text-white',
      isUrgent: true,
    },
    {
      id: 'help',
      icon: <HelpCircle className="w-9 h-9" />,
      labelEn: 'I NEED HELP',
      labelHi: 'मुझे मदद चाहिए',
      labelBn: 'আমার সাহায্য দরকার',
      speechTextEn: 'Please come here, I need help right now.',
      speechTextHi: 'कृपया यहाँ आएं, मुझे तुरंत मदद चाहिए।',
      speechTextBn: 'দয়া করে এখানে আসুন, আমার সাহায্য প্রয়োজন।',
      bgGradient: 'from-amber-500 to-amber-700',
      textColor: 'text-white',
      isUrgent: true,
    },
    {
      id: 'call_family',
      icon: <PhoneCall className="w-9 h-9" />,
      labelEn: 'CALL MY FAMILY',
      labelHi: 'मेरे परिवार को फोन करें',
      labelBn: 'আমার পরিবারকে ফোন করুন',
      speechTextEn: 'Please call my family or caregiver.',
      speechTextHi: 'कृपया मेरे परिवार या देखभालकर्ता को फोन लगाएं।',
      speechTextBn: 'দয়া করে আমার পরিবারকে ফোন করুন।',
      bgGradient: 'from-teal-600 to-teal-800',
      textColor: 'text-white',
    },
    {
      id: 'bathroom',
      icon: <Bath className="w-9 h-9" />,
      labelEn: 'BATHROOM',
      labelHi: 'शौचालय जाना है',
      labelBn: 'বাথরুমে যেতে হবে',
      speechTextEn: 'I need to use the bathroom.',
      speechTextHi: 'मुझे शौचालय जाना है।',
      speechTextBn: 'আমাকে বাথরুমে যেতে হবে।',
      bgGradient: 'from-indigo-600 to-indigo-800',
      textColor: 'text-white',
    },
    {
      id: 'food',
      icon: <Utensils className="w-9 h-9" />,
      labelEn: 'HUNGRY / FOOD',
      labelHi: 'मुझे भूख लगी है',
      labelBn: 'আমার খিদে পেয়েছে',
      speechTextEn: 'I am hungry and would like some food.',
      speechTextHi: 'मुझे भूख लगी है, कुछ खाने को दें।',
      speechTextBn: 'আমার খিদে পেয়েছে, খাবার খাব।',
      bgGradient: 'from-orange-500 to-orange-700',
      textColor: 'text-white',
    },
    {
      id: 'medicine',
      icon: <Pill className="w-9 h-9" />,
      labelEn: 'MY MEDICINE',
      labelHi: 'मेरी दवा दें',
      labelBn: 'আমার ওষুধ দিন',
      speechTextEn: 'It is time for my medicine, please bring it.',
      speechTextHi: 'मेरी दवा का समय हो गया है, कृपया दवा दें।',
      speechTextBn: 'আমার ওষুধের সময় হয়েছে, ওষুধ এনে দিন।',
      bgGradient: 'from-emerald-600 to-teal-800',
      textColor: 'text-white',
    },
    {
      id: 'temperature',
      icon: <Thermometer className="w-9 h-9" />,
      labelEn: 'TOO COLD / WARM',
      labelHi: 'ठंड / गर्मी लग रही है',
      labelBn: 'ঠান্ডা / গরম লাগছে',
      speechTextEn: 'I feel uncomfortable with the room temperature.',
      speechTextHi: 'मुझे कमरे का तापमान ठीक नहीं लग रहा।',
      speechTextBn: 'আমার ঘরের তাপমাত্রা স্বস্তিকর লাগছে না।',
      bgGradient: 'from-purple-600 to-purple-800',
      textColor: 'text-white',
    }
  ];

  const handleCardClick = (btn: AACButton) => {
    playChime('click');
    const spoken = currentLang === 'hi' 
      ? btn.speechTextHi 
      : currentLang === 'bn' 
      ? btn.speechTextBn 
      : btn.speechTextEn;
    
    setLastSpokenPhrase(spoken);
    speak(spoken);
  };

  const handleCustomSpeak = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customText.trim()) return;
    setLastSpokenPhrase(customText);
    speak(customText);
    setCustomText('');
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-md p-4 overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="bg-white rounded-3xl max-w-4xl w-full p-6 sm:p-8 shadow-2xl my-6 flex flex-col justify-between max-h-[92vh] border border-slate-200">
        
        {/* Sticky Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-200 sticky top-0 bg-white z-10">
          <div>
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-100 text-amber-900 text-xs font-black uppercase tracking-wider mb-1">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Augmentative & Alternative Communication (AAC)</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900">
              {settings.language === 'hi' ? 'मूक संवाद मोड (AAC)' : settings.language === 'bn' ? 'নীরব যোগাযোগ মোড (AAC)' : 'Silent Communication Mode'}
            </h2>
            <p className="text-slate-500 text-xs sm:text-sm font-semibold mt-0.5">
              {settings.language === 'hi'
                ? 'जो बुज़ुर्ग बोल नहीं सकते (स्ट्रोक या आवाज़ की समस्या), वे इन बटनों को दबाकर तुरंत बोल सकते हैं।'
                : settings.language === 'bn'
                ? 'যেসব বয়োজ্যেষ্ঠ কথা বলতে পারেন না (স্ট্রোক বা কণ্ঠের সমস্যা), তারা এই বোতামে চেপে অবিলম্বে কথা বলতে পারেন।'
                : 'Designed for elderly individuals with speech loss, tracheostomy, or post-stroke aphonia. Tap to speak instantly.'}
            </p>
          </div>

          <button
            onClick={onClose}
            className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 font-extrabold text-xs transition-all shadow-xs cursor-pointer flex-shrink-0"
            title="Close (ESC)"
          >
            <X className="w-5 h-5 stroke-[2.5]" />
            <span>Close ✕</span>
          </button>
        </div>

        {/* Real-time Spoken Announcement Banner */}
        {lastSpokenPhrase && (
          <div className="my-4 p-4 rounded-2xl bg-emerald-50 border-2 border-emerald-300 flex items-center space-x-3 text-emerald-950">
            <Volume2 className="w-6 h-6 text-emerald-700 animate-pulse flex-shrink-0" />
            <div>
              <p className="text-xs uppercase font-extrabold tracking-wider text-emerald-700">
                {settings.language === 'hi' ? 'अभी बोला गया:' : settings.language === 'bn' ? 'এখন বলা হচ্ছে:' : 'Currently Speaking:'}
              </p>
              <p className="text-lg font-black">{lastSpokenPhrase}</p>
            </div>
          </div>
        )}

        {/* Big AAC Buttons Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3 sm:gap-4 my-6">
          {aacButtons.map((btn) => {
            const label = currentLang === 'hi' ? btn.labelHi : currentLang === 'bn' ? btn.labelBn : btn.labelEn;

            return (
              <button
                key={btn.id}
                onClick={() => handleCardClick(btn)}
                className={`min-h-[120px] sm:min-h-[140px] rounded-3xl bg-gradient-to-br ${btn.bgGradient} ${btn.textColor} p-4 flex flex-col items-center justify-center text-center shadow-lg transition-transform active:scale-95 hover:shadow-xl focus:outline-none focus:ring-4 focus:ring-amber-400 group`}
              >
                <div className="p-2.5 rounded-2xl bg-white/20 backdrop-blur group-hover:scale-110 transition-transform">
                  {btn.icon}
                </div>
                <span className="font-black text-sm sm:text-base mt-2 tracking-tight leading-tight">
                  {label}
                </span>
              </button>
            );
          })}
        </div>

        {/* Custom Text Input to Speech */}
        <form onSubmit={handleCustomSpeak} className="pt-4 border-t border-slate-200">
          <label className="block text-xs font-black uppercase text-slate-700 mb-1.5">
            {settings.language === 'hi' 
              ? 'या बोलकर सुनाने के लिए अपनी भाषा में लिखें:' 
              : settings.language === 'bn' 
              ? 'অথবা বলে শোনানোর জন্য আপনার নিজের ভাষায় লিখুন:' 
              : 'Or Type Custom Message to Speak Out Loud:'}
          </label>
          <div className="flex gap-2">
            <input
              type="text"
              placeholder={
                settings.language === 'hi' 
                  ? 'उदा. मुझे खिड़की खोलनी है या पानी का गिलास दें...' 
                  : settings.language === 'bn' 
                  ? 'যেমন: জানলাটা খুলে দিন বা জল দিন...' 
                  : 'e.g. Please open the bedroom window...'
              }
              value={customText}
              onChange={(e) => setCustomText(e.target.value)}
              className="flex-1 px-4 py-3 rounded-2xl border-2 border-slate-300 font-semibold text-base focus:border-amber-500 focus:outline-none"
            />
            <button
              type="submit"
              className="px-6 py-3 rounded-2xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-sm shadow-md transition-all flex items-center gap-2 active:scale-95"
            >
              <Volume2 className="w-5 h-5" />
              <span>
                {settings.language === 'hi' ? 'बोलकर सुनाएं' : settings.language === 'bn' ? 'কথা বলুন' : 'Speak Message'}
              </span>
            </button>
          </div>
        </form>

      </div>
    </div>
  );
};
