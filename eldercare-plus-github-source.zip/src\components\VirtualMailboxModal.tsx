import React, { useState, useEffect } from 'react';
import { 
  X, 
  Mail, 
  Inbox, 
  Trash2, 
  CheckCircle2, 
  Clock, 
  Calendar, 
  AlertTriangle, 
  Pill, 
  ShieldAlert, 
  ExternalLink,
  ChevronRight,
  RefreshCw,
  Eye
} from 'lucide-react';
import { getVirtualEmails, clearVirtualMailbox, markEmailAsRead, VirtualEmail } from '../lib/resend';

interface VirtualMailboxModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenSettingsModal: () => void;
}

export const VirtualMailboxModal: React.FC<VirtualMailboxModalProps> = ({
  isOpen,
  onClose,
  onOpenSettingsModal,
}) => {
  const [emails, setEmails] = useState<VirtualEmail[]>([]);
  const [selectedEmail, setSelectedEmail] = useState<VirtualEmail | null>(null);

  const loadEmails = () => {
    const list = getVirtualEmails();
    setEmails(list);
    if (!selectedEmail && list.length > 0) {
      setSelectedEmail(list[0]);
      markEmailAsRead(list[0].id);
    } else if (selectedEmail) {
      const updated = list.find(e => e.id === selectedEmail.id);
      if (updated) setSelectedEmail(updated);
    }
  };

  useEffect(() => {
    if (isOpen) {
      loadEmails();
    }
  }, [isOpen]);

  // Listen for new emails dispatched anywhere in the app
  useEffect(() => {
    const handleNewEmail = () => loadEmails();
    window.addEventListener('eldercare_new_email', handleNewEmail);
    window.addEventListener('eldercare_mailbox_cleared', handleNewEmail);
    return () => {
      window.removeEventListener('eldercare_new_email', handleNewEmail);
      window.removeEventListener('eldercare_mailbox_cleared', handleNewEmail);
    };
  }, []);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleSelectEmail = (mail: VirtualEmail) => {
    setSelectedEmail(mail);
    markEmailAsRead(mail.id);
    setEmails(prev => prev.map(e => e.id === mail.id ? { ...e, isRead: true } : e));
  };

  const handleClearAll = () => {
    if (confirm('Clear all received emails from the Virtual Mailbox?')) {
      clearVirtualMailbox();
      setEmails([]);
      setSelectedEmail(null);
    }
  };

  const getTypeBadge = (type: string) => {
    switch (type) {
      case 'upcoming_dose':
        return <span className="px-2 py-0.5 rounded-full bg-elder-blue-100 text-elder-blue-800 text-[10px] font-black uppercase">Upcoming Dose</span>;
      case 'missed_medication':
        return <span className="px-2 py-0.5 rounded-full bg-red-100 text-red-800 text-[10px] font-black uppercase">Missed Dose Alert</span>;
      case 'doctor_appointment':
        return <span className="px-2 py-0.5 rounded-full bg-purple-100 text-purple-800 text-[10px] font-black uppercase">Appointment</span>;
      case 'emergency_sos':
        return <span className="px-2 py-0.5 rounded-full bg-rose-600 text-white text-[10px] font-black uppercase animate-pulse">Emergency SOS</span>;
      default:
        return <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-black uppercase">Healthcare</span>;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-3 sm:p-6 overflow-hidden">
      <div className="bg-white rounded-3xl max-w-6xl w-full h-[90vh] shadow-2xl flex flex-col overflow-hidden border border-slate-200">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50 flex-shrink-0">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-elder-green-700 text-white flex items-center justify-center font-bold shadow-md">
              <Inbox className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-xl font-black text-slate-900">
                  ElderCare+ Virtual Email Mailbox
                </h2>
                <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[11px] font-extrabold border border-emerald-300">
                  Interactive Simulator & Viewer
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium">
                Live simulation client for inspecting automated HTML dose reminders, alerts, and doctor consultations.
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            {emails.length > 0 && (
              <button
                onClick={handleClearAll}
                className="px-3 py-1.5 rounded-xl text-xs font-bold text-slate-500 hover:text-red-600 hover:bg-red-50 flex items-center gap-1 transition-all"
                title="Clear mailbox"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Clear All</span>
              </button>
            )}

            <button
              onClick={onClose}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-800 font-extrabold text-xs transition-all cursor-pointer shadow-xs"
              title="Close (ESC)"
            >
              <X className="w-4 h-4 stroke-[2.5]" />
              <span>Close ✕</span>
            </button>
          </div>
        </div>

        {/* Main Body: Two Pane (Inbox list & Email preview) */}
        <div className="flex-1 flex overflow-hidden">
          
          {/* Left: Email List Sidebar */}
          <div className="w-full sm:w-80 md:w-96 border-r border-slate-200 flex flex-col bg-slate-50/50 flex-shrink-0">
            <div className="p-3 border-b border-slate-200 flex items-center justify-between text-xs font-bold text-slate-500">
              <span>Inbox ({emails.length} messages)</span>
              <button onClick={loadEmails} className="hover:text-slate-900 flex items-center gap-1">
                <RefreshCw className="w-3 h-3" /> Refresh
              </button>
            </div>

            <div className="flex-1 overflow-y-auto divide-y divide-slate-100">
              {emails.map((mail) => {
                const isSelected = selectedEmail?.id === mail.id;
                return (
                  <button
                    key={mail.id}
                    onClick={() => handleSelectEmail(mail)}
                    className={`w-full text-left p-4 transition-all flex flex-col justify-between ${
                      isSelected
                        ? 'bg-white border-l-4 border-elder-green-600 shadow-xs'
                        : 'hover:bg-slate-100/70'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between mb-1.5">
                        {getTypeBadge(mail.type)}
                        <span className="text-[11px] text-slate-400 font-mono">
                          {new Date(mail.sentAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>

                      <h4 className={`text-xs font-extrabold text-slate-900 line-clamp-1 ${!mail.isRead ? 'font-black' : ''}`}>
                        {mail.subject}
                      </h4>
                      <p className="text-[11px] text-slate-500 line-clamp-2 mt-0.5">
                        {mail.previewText}
                      </p>
                    </div>

                    <div className="mt-2 text-[10px] text-slate-400 font-semibold flex items-center justify-between">
                      <span>To: {mail.to}</span>
                      <span className="text-emerald-700 font-bold flex items-center gap-0.5">
                        <CheckCircle2 className="w-3 h-3" /> Delivered
                      </span>
                    </div>
                  </button>
                );
              })}

              {emails.length === 0 && (
                <div className="p-8 text-center text-slate-400 space-y-2">
                  <Mail className="w-10 h-10 mx-auto opacity-30" />
                  <p className="text-xs font-bold text-slate-600">Your Virtual Mailbox is Empty</p>
                  <p className="text-[11px] text-slate-400">
                    Trigger reminders from the Dashboard or click "Test Send" in Settings to inspect live delivered HTML emails.
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Right: Email Viewer & Full HTML Rendering */}
          <div className="hidden sm:flex flex-1 flex-col overflow-hidden bg-white">
            {selectedEmail ? (
              <div className="flex-1 flex flex-col overflow-hidden">
                {/* Email Header Bar */}
                <div className="p-6 border-b border-slate-200 bg-white flex-shrink-0">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <h3 className="text-xl font-black text-slate-900 leading-tight">
                        {selectedEmail.subject}
                      </h3>
                      <div className="flex flex-wrap items-center gap-2 mt-2 text-xs">
                        <span className="font-bold text-slate-700">From:</span>
                        <span className="font-mono text-slate-900 bg-slate-100 px-2 py-0.5 rounded">{selectedEmail.from}</span>
                        <span className="font-bold text-slate-700 ml-2">To:</span>
                        <span className="font-mono text-slate-900 bg-slate-100 px-2 py-0.5 rounded">{selectedEmail.to}</span>
                      </div>
                    </div>

                    <div className="text-right flex-shrink-0">
                      <span className="inline-flex items-center px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-extrabold gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Delivered to Inbox
                      </span>
                      <p className="text-xs text-slate-400 mt-1 font-mono">
                        {new Date(selectedEmail.sentAt).toLocaleString()}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Rendered HTML Container */}
                <div className="flex-1 overflow-y-auto p-6 bg-slate-100/50">
                  <div 
                    className="max-w-2xl mx-auto bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden"
                    dangerouslySetInnerHTML={{ __html: selectedEmail.htmlContent }}
                  />
                </div>
              </div>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center text-center p-8 text-slate-400">
                <Mail className="w-16 h-16 opacity-20 mb-3" />
                <h4 className="text-base font-black text-slate-700">Select an email to view</h4>
                <p className="text-xs text-slate-400 max-w-sm mt-1">
                  Choose any message from the left to inspect the responsive email design, dose times, and patient warnings.
                </p>
              </div>
            )}
          </div>

        </div>

      </div>
    </div>
  );
};
