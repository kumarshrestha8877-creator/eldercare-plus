import React, { useState, useEffect } from 'react';
import { 
  X, 
  Mic, 
  Volume2, 
  Sparkles, 
  Check, 
  Calendar, 
  AlertCircle, 
  Pill,
  HelpCircle,
  Globe,
  Sliders
} from 'lucide-react';
import { useAccessibility } from '../context/AccessibilityContext';
import { useAuth } from '../context/AuthContext';

interface VoiceAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const VoiceAssistantModal: React.FC<VoiceAssistantModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { 
    speak, 
    stopSpeaking, 
    isSpeaking, 
    startListening, 
    stopListening, 
    isListening, 
    playChime,
    settings,
    updateSettings,
    t,
    availableVoices,
    selectedVoiceName,
    setSelectedVoiceName
  } = useAccessibility();

  const { schedules, appointments, currentUser, markDoseStatus, triggerEmergencySos } = useAuth();
  const [transcript, setTranscript] = useState('');
  const [assistantReply, setAssistantReply] = useState('');

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const currentLang = settings.language;

  const handleVoiceCommand = (command: string) => {
    const text = command.toLowerCase();
    setTranscript(command);

    // Multilingual command keywords
    const isScheduleInquiry = 
      text.includes('schedule') || text.includes('medicine') || text.includes('pill') ||
      text.includes('दवा') || text.includes('दवाई') || text.includes('समय') || text.includes('सूची') ||
      text.includes('ওষুধ') || text.includes('সময়সূচি') || text.includes('তালিকা');

    const isDoseTakenCommand = 
      text.includes('take') || text.includes('taken') || text.includes('took') ||
      text.includes('ले ली') || text.includes('खा ली') || text.includes('दवा ली') ||
      text.includes('খেয়েছি') || text.includes('নেওয়া হয়েছে') || text.includes('খেয়ে নিয়েছি');

    const isAppointmentInquiry = 
      text.includes('appointment') || text.includes('doctor') ||
      text.includes('डॉक्टर') || text.includes('मुलाकात') || text.includes('अस्पताल') ||
      text.includes('ডাক্তার') || text.includes('অ্যাপয়েন্টমেন্ট') || text.includes('হাসপাতাল');

    const isEmergencyCommand = 
      text.includes('emergency') || text.includes('sos') || text.includes('help') ||
      text.includes('मदद') || text.includes('बचाओ') || text.includes('आपातकाल') || text.includes('एसओएस') ||
      text.includes('সাহায্য') || text.includes('জরুরি') || text.includes('বাঁচাও') || text.includes('এসওএস');

    if (isScheduleInquiry) {
      const pending = schedules.filter(s => s.status === 'pending');
      const taken = schedules.filter(s => s.status === 'taken');
      let response = '';

      if (currentLang === 'hi') {
        response = `आज आपने ${taken.length} दवाइयाँ ले ली हैं। `;
        if (pending.length > 0) {
          response += `आपकी ${pending.length} दवाइयाँ बाकी हैं: ` + pending.map(p => `${p.medicineName} ${p.scheduledTime} पर`).join(', ');
        } else {
          response += `आज की सभी दवाइयाँ पूरी हो चुकी हैं। बहुत बढ़िया!`;
        }
      } else if (currentLang === 'bn') {
        response = `আজকে আপনি ${taken.length}টি ওষুধ খেয়েছেন। `;
        if (pending.length > 0) {
          response += `আপনার ${pending.length}টি ওষুধ বাকি রয়েছে: ` + pending.map(p => `${p.medicineName} (${p.scheduledTime})`).join(', ');
        } else {
          response += `আজকের সমস্ত ওষুধ নেওয়া সম্পন্ন হয়েছে। দারুণ!`;
        }
      } else {
        response = `You have taken ${taken.length} medicines today. `;
        if (pending.length > 0) {
          response += `You have ${pending.length} pending medicines: ` + pending.map(p => `${p.medicineName} at ${p.scheduledTime}`).join(', ');
        } else {
          response += `All your medicines for today are finished. Great job!`;
        }
      }

      setAssistantReply(response);
      speak(response);
    } else if (isAppointmentInquiry) {
      const upcoming = appointments.filter(a => a.status === 'upcoming');
      let response = '';

      if (upcoming.length > 0) {
        const nextApt = upcoming[0];
        if (currentLang === 'hi') {
          response = `आपकी अगली मुलाक़ात डॉक्टर ${nextApt.doctorName}, ${nextApt.specialty} के साथ ${nextApt.hospitalName} में ${nextApt.appointmentDate} को ${nextApt.appointmentTime} बजे है।`;
        } else if (currentLang === 'bn') {
          response = `আপনার পরবর্তী সাক্ষাতকার ডাক্তার ${nextApt.doctorName}, ${nextApt.specialty} এর সাথে ${nextApt.appointmentDate} তারিখে ${nextApt.appointmentTime} সময়ে ${nextApt.hospitalName} এ।`;
        } else {
          response = `Your next appointment is with ${nextApt.doctorName}, ${nextApt.specialty}, at ${nextApt.hospitalName} on ${nextApt.appointmentDate} at ${nextApt.appointmentTime}.`;
        }
      } else {
        if (currentLang === 'hi') {
          response = 'आपकी कोई आगामी डॉक्टर मुलाक़ात निर्धारित नहीं है।';
        } else if (currentLang === 'bn') {
          response = 'আপনার কোনো আসন্ন ডাক্তারের সাক্ষাতকার নির্ধারিত নেই।';
        } else {
          response = 'You have no upcoming doctor appointments scheduled.';
        }
      }

      setAssistantReply(response);
      speak(response);
    } else if (isDoseTakenCommand) {
      const pending = schedules.find(s => s.status === 'pending');
      let response = '';

      if (pending) {
        markDoseStatus(pending.id, 'taken');
        if (currentLang === 'hi') {
          response = `स्वीकृत! ${pending.medicineName} दवा ले ली गई दर्ज कर ली गई है।`;
        } else if (currentLang === 'bn') {
          response = `নিশ্চিত করা হলো! ${pending.medicineName} ওষুধ নেওয়া সম্পন্ন হয়েছে।`;
        } else {
          response = `Confirmed! Marked ${pending.medicineName} as taken.`;
        }
      } else {
        if (currentLang === 'hi') {
          response = 'कोई बकाया दवा नहीं मिली जिसे दर्ज किया जा सके।';
        } else if (currentLang === 'bn') {
          response = 'নেওয়ার মতো কোনো বাকি ওষুধ পাওয়া যায়নি।';
        } else {
          response = 'No pending medicines found to mark as taken.';
        }
      }

      setAssistantReply(response);
      speak(response);
    } else if (isEmergencyCommand) {
      let response = '';
      if (currentLang === 'hi') {
        response = 'आपातकालीन सहायता संकेत तुरंत सक्रिय किया जा रहा है!';
      } else if (currentLang === 'bn') {
        response = 'জরুরি বিপদ সংকেত এখনই চালু করা হচ্ছে!';
      } else {
        response = 'Activating emergency distress signal now!';
      }

      setAssistantReply(response);
      speak(response);
      triggerEmergencySos('Voice command SOS requested');
    } else {
      let response = '';
      if (currentLang === 'hi') {
        response = `मैंने सुना: "${command}"। आप पूछ सकते हैं: "मेरी दवाइयाँ बताओ", "डॉक्टर की मुलाकात कब है", या "दवा ले ली"।`;
      } else if (currentLang === 'bn') {
        response = `আমি শুনেছি: "${command}"। আপনি জিজ্ঞাসা করতে পারেন: "আমার ওষুধগুলো বলো", "ডাক্তারের সময় কখন", অথবা "ওষুধ খেয়েছি"।`;
      } else {
        response = `I heard: "${command}". Try asking: "What are my medicines?", "When is my doctor appointment?", or "Mark dose taken".`;
      }
      setAssistantReply(response);
      speak(response);
    }
  };

  const handleStartMic = () => {
    startListening((result) => {
      handleVoiceCommand(result);
    });
  };

  const handleLanguageSwitch = (lang: 'en' | 'hi' | 'bn') => {
    updateSettings({ language: lang });
    playChime('click');
    if (lang === 'hi') {
      speak('भाषा हिंदी चुनी गई है। एल्डरकेयर+ में आपका स्वागत है।', 'hi-IN');
    } else if (lang === 'bn') {
      speak('ভাষা বাংলা নির্বাচন করা হয়েছে। এল্ডারকেয়ার+ এ আপনাকে স্বাগতম।', 'bn-IN');
    } else {
      speak('Language set to English. Welcome to ElderCare+.', 'en-US');
    }
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-md p-4 overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl my-6 flex flex-col justify-between max-h-[92vh] border border-slate-200">
        
        {/* Sticky Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-200 sticky top-0 bg-white z-10">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 rounded-2xl bg-elder-green-700 text-white flex items-center justify-center font-bold shadow-md">
              <Volume2 className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <h2 className="text-2xl font-black text-slate-900">
                {t('voiceAssistant')}
              </h2>
              <p className="text-xs text-slate-500 font-semibold">
                Multilingual Voice Control (English, हिंदी, বাংলা) for hands-free elderly assistance.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 font-extrabold text-xs transition-all shadow-xs cursor-pointer flex-shrink-0"
            title="Close (ESC)"
          >
            <X className="w-5 h-5 stroke-[2.5]" />
            <span>Close ✕</span>
          </button>
        </div>

        {/* Language Tabs inside Voice Assistant */}
        <div className="flex items-center justify-between bg-slate-100 p-1.5 rounded-2xl my-4 text-xs font-bold">
          <span className="text-slate-600 px-3 flex items-center gap-1">
            <Globe className="w-3.5 h-3.5" /> Language / भाषा:
          </span>
          <div className="flex gap-1">
            <button
              onClick={() => handleLanguageSwitch('en')}
              className={`px-3 py-1.5 rounded-xl transition-all ${
                currentLang === 'en' ? 'bg-white text-elder-green-800 shadow-sm font-black' : 'text-slate-600'
              }`}
            >
              English
            </button>
            <button
              onClick={() => handleLanguageSwitch('hi')}
              className={`px-3 py-1.5 rounded-xl transition-all ${
                currentLang === 'hi' ? 'bg-white text-elder-green-800 shadow-sm font-black' : 'text-slate-600'
              }`}
            >
              हिंदी (Hindi)
            </button>
            <button
              onClick={() => handleLanguageSwitch('bn')}
              className={`px-3 py-1.5 rounded-xl transition-all ${
                currentLang === 'bn' ? 'bg-white text-elder-green-800 shadow-sm font-black' : 'text-slate-600'
              }`}
            >
              বাংলা (Bengali)
            </button>
          </div>
        </div>

        {/* Center: Interactive Mic Button & Speech Visualizer */}
        <div className="py-6 flex flex-col items-center justify-center text-center space-y-5">
          <div className="relative">
            {isListening && (
              <div className="absolute -inset-4 rounded-full bg-emerald-400/30 animate-ping" />
            )}
            <button
              onClick={handleStartMic}
              disabled={isListening}
              className={`w-28 h-28 rounded-full flex flex-col items-center justify-center text-white font-black shadow-xl transition-all active:scale-95 ${
                isListening
                  ? 'bg-rose-600 scale-105 ring-4 ring-rose-300'
                  : 'bg-elder-green-700 hover:bg-elder-green-800'
              }`}
            >
              <Mic className="w-10 h-10 mb-1" />
              <span className="text-xs tracking-wider uppercase">
                {isListening ? (currentLang === 'hi' ? 'सुन रहे हैं...' : currentLang === 'bn' ? 'শুনছি...' : 'Listening...') : (currentLang === 'hi' ? 'बोलने के लिए दबाएं' : currentLang === 'bn' ? 'বলতে চাপুন' : 'Tap to Speak')}
              </span>
            </button>
          </div>

          <div className="max-w-md space-y-2">
            <p className="text-base font-black text-slate-800">
              {isListening 
                ? (currentLang === 'hi' ? 'अपनी आवाज़ में निर्देश बोलें...' : currentLang === 'bn' ? 'আপনার ভয়েস কমান্ড বলুন...' : 'Listening to your voice command...') 
                : (currentLang === 'hi' ? 'माइक दबाकर अपनी भाषा में बात करें' : currentLang === 'bn' ? 'মাইক চেপে আপনার ভাষায় কথা বলুন' : 'Tap the microphone and speak your request')}
            </p>
            {transcript && (
              <p className="text-sm font-semibold text-slate-600 bg-slate-100 px-4 py-2 rounded-xl">
                {currentLang === 'hi' ? 'आपने कहा:' : currentLang === 'bn' ? 'আপনি বলেছেন:' : 'You said:'} <strong className="text-slate-900">"{transcript}"</strong>
              </p>
            )}
          </div>

          {assistantReply && (
            <div className="w-full p-4 rounded-2xl bg-elder-green-50 border-2 border-elder-green-300 text-left text-elder-green-950">
              <p className="text-xs uppercase font-extrabold tracking-wider text-elder-green-700 mb-1">
                {currentLang === 'hi' ? 'सहायक का उत्तर:' : currentLang === 'bn' ? 'সহকারীর উত্তর:' : 'Assistant Response:'}
              </p>
              <p className="text-base font-bold leading-relaxed">{assistantReply}</p>
            </div>
          )}
        </div>

        {/* Quick Voice Prompt Shortcuts */}
        <div className="pt-4 border-t border-slate-200">
          <p className="text-xs font-black uppercase text-slate-500 mb-3 flex items-center gap-1.5">
            <HelpCircle className="w-4 h-4 text-elder-green-700" />
            {currentLang === 'hi' ? 'या इन त्वरित सवालों पर क्लिक करें:' : currentLang === 'bn' ? 'অথবা নিচের যেকোনো প্রশ্নে ক্লিক করুন:' : 'Or click a quick spoken inquiry:'}
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
            {currentLang === 'hi' ? (
              <>
                <button
                  onClick={() => handleVoiceCommand('आज की मेरी दवाइयां बताओ')}
                  className="p-3 text-left rounded-xl bg-slate-50 hover:bg-elder-green-50 hover:border-elder-green-300 border border-slate-200 font-bold text-slate-800 transition-all"
                >
                  💊 "आज की मेरी दवाइयां बताओ"
                </button>
                <button
                  onClick={() => handleVoiceCommand('डॉक्टर की अगली मुलाक़ात कब है')}
                  className="p-3 text-left rounded-xl bg-slate-50 hover:bg-elder-green-50 hover:border-elder-green-300 border border-slate-200 font-bold text-slate-800 transition-all"
                >
                  📅 "डॉक्टर की अगली मुलाक़ात कब है?"
                </button>
                <button
                  onClick={() => handleVoiceCommand('मेरी दवा ले ली गई दर्ज करो')}
                  className="p-3 text-left rounded-xl bg-slate-50 hover:bg-elder-green-50 hover:border-elder-green-300 border border-slate-200 font-bold text-slate-800 transition-all"
                >
                  ✅ "मेरी दवा ले ली गई दर्ज करो"
                </button>
                <button
                  onClick={() => handleVoiceCommand('आपातकालीन सहायता एसओएस')}
                  className="p-3 text-left rounded-xl bg-red-50 hover:bg-red-100 border border-red-200 font-bold text-red-900 transition-all"
                >
                  🚨 "आपातकालीन सहायता (SOS) शुरू करो"
                </button>
              </>
            ) : currentLang === 'bn' ? (
              <>
                <button
                  onClick={() => handleVoiceCommand('আজকের আমার ওষুধগুলো বলো')}
                  className="p-3 text-left rounded-xl bg-slate-50 hover:bg-elder-green-50 hover:border-elder-green-300 border border-slate-200 font-bold text-slate-800 transition-all"
                >
                  💊 "আজকের আমার ওষুধগুলো বলো"
                </button>
                <button
                  onClick={() => handleVoiceCommand('ডাক্তারের পরবর্তী অ্যাপয়েন্টমেন্ট কখন')}
                  className="p-3 text-left rounded-xl bg-slate-50 hover:bg-elder-green-50 hover:border-elder-green-300 border border-slate-200 font-bold text-slate-800 transition-all"
                >
                  📅 "ডাক্তারের পরবর্তী অ্যাপয়েন্টমেন্ট কখন?"
                </button>
                <button
                  onClick={() => handleVoiceCommand('আমার ওষুধ খেয়েছি চিহ্নিত করো')}
                  className="p-3 text-left rounded-xl bg-slate-50 hover:bg-elder-green-50 hover:border-elder-green-300 border border-slate-200 font-bold text-slate-800 transition-all"
                >
                  ✅ "আমার ওষুধ খেয়েছি চিহ্নিত করো"
                </button>
                <button
                  onClick={() => handleVoiceCommand('জরুরি সাহায্য এসওএস')}
                  className="p-3 text-left rounded-xl bg-red-50 hover:bg-red-100 border border-red-200 font-bold text-red-900 transition-all"
                >
                  🚨 "জরুরি সাহায্য (SOS) চালু করো"
                </button>
              </>
            ) : (
              <>
                <button
                  onClick={() => handleVoiceCommand('Read my medication schedule')}
                  className="p-3 text-left rounded-xl bg-slate-50 hover:bg-elder-green-50 hover:border-elder-green-300 border border-slate-200 font-bold text-slate-800 transition-all"
                >
                  💊 "What are my medicines for today?"
                </button>
                <button
                  onClick={() => handleVoiceCommand('When is my doctor appointment?')}
                  className="p-3 text-left rounded-xl bg-slate-50 hover:bg-elder-green-50 hover:border-elder-green-300 border border-slate-200 font-bold text-slate-800 transition-all"
                >
                  📅 "When is my next doctor appointment?"
                </button>
                <button
                  onClick={() => handleVoiceCommand('Mark dose as taken')}
                  className="p-3 text-left rounded-xl bg-slate-50 hover:bg-elder-green-50 hover:border-elder-green-300 border border-slate-200 font-bold text-slate-800 transition-all"
                >
                  ✅ "Mark my pending medicine as taken"
                </button>
                <button
                  onClick={() => handleVoiceCommand('Emergency SOS help')}
                  className="p-3 text-left rounded-xl bg-red-50 hover:bg-red-100 border border-red-200 font-bold text-red-900 transition-all"
                >
                  🚨 "Trigger emergency assistance SOS"
                </button>
              </>
            )}
          </div>
        </div>

      </div>
    </div>
  );
};
