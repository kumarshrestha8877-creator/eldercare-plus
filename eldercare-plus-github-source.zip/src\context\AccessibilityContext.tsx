// Accessibility & Multilingual Voice Assistance Engine
// Complete native speech synthesis & recognition for English, Hindi (हिंदी), and Bengali (বাংলা)

import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { AccessibilitySettings } from '../types';

export interface SpokenPhraseParams {
  userName?: string;
  takenCount?: number;
  pendingCount?: number;
  medName?: string;
  dosage?: string;
  time?: string;
  doctorName?: string;
  hospitalName?: string;
  date?: string;
  passcode?: string;
}

interface AccessibilityContextType {
  settings: AccessibilitySettings;
  updateSettings: (newSettings: Partial<AccessibilitySettings>) => void;
  speak: (text: string, customLang?: string) => void;
  speakKey: (phraseKey: string, params?: SpokenPhraseParams) => void;
  stopSpeaking: () => void;
  isSpeaking: boolean;
  isListening: boolean;
  startListening: (onCommand: (transcript: string) => void) => void;
  stopListening: () => void;
  playChime: (type: 'success' | 'alert' | 'emergency' | 'click') => void;
  t: (key: string) => string;
  availableVoices: SpeechSynthesisVoice[];
  selectedVoiceName: string;
  setSelectedVoiceName: (voiceName: string) => void;
}

const DEFAULT_SETTINGS: AccessibilitySettings = {
  fontSizeScale: 100,
  highContrast: false,
  nightBlindnessMode: false,
  voiceAssistanceEnabled: true,
  speechRate: 0.92, // Measured cadence for clear elderly comprehension
  soundEffects: true,
  language: 'en',
  silentMode: false,
};

// Comprehensive Multilingual Dictionaries for UI & Audio Speech
export const TRANSLATIONS: Record<'en' | 'hi' | 'bn', Record<string, string>> = {
  en: {
    appName: 'ElderCare+',
    tagline: 'Healthcare Without Communication or Accessibility Barriers',
    dashboard: 'Dashboard',
    myCareDashboard: 'My Care Dashboard',
    familyOverview: 'Family Overview',
    nurseConsole: 'Nurse Care Console',
    medicationManagement: 'Medication Management',
    doctorAppointments: 'Doctor Appointments',
    sharedProfile: 'Shared Profile & Passcodes',
    mailbox: 'Virtual Mailbox',
    goodMorning: 'Good morning',
    goodAfternoon: 'Good afternoon',
    goodEvening: 'Good evening',
    todaysSchedule: "Today's Medicine Schedule",
    nextPill: 'Next Medication',
    taken: 'Taken',
    pending: 'Pending',
    missed: 'Missed',
    markTaken: 'Mark as Taken',
    markSkipped: 'Skip Dose',
    iTookThisPill: 'I Took This Pill',
    streak: 'Day Streak',
    adherenceRate: 'Adherence Rate',
    todaysAdherence: "Today's Adherence",
    upcomingAppointments: 'Upcoming Doctor Appointments',
    silentCommunication: 'Silent Communication (AAC)',
    voiceAssistant: 'Voice Assistant',
    emergencySos: 'EMERGENCY SOS',
    lowVisionMode: 'High Contrast Mode',
    fontSize: 'Text Size',
    familyAccessCode: 'Family Access Code',
    generateCode: 'Generate New Passcode',
    connectedFamily: 'Connected Family & Caregivers',
    addMedicine: 'Add Medicine',
    addAppointment: 'Book Appointment',
    settings: 'Settings',
    logout: 'Log Out',
    readSchedule: "Read Today's Schedule",
    voiceHelp: 'Voice Help',
    yes: 'YES',
    no: 'NO',
    needWater: 'I NEED WATER',
    inPain: 'I AM IN PAIN',
    needHelp: 'I NEED HELP',
    callFamily: 'CALL MY FAMILY',
    bathroom: 'I NEED THE BATHROOM',
    dizzy: 'I FEEL DIZZY',
    hungry: 'I AM HUNGRY',
    myMedicine: 'I NEED MY MEDICINE',
    tempDiscomfort: 'TOO COLD / WARM',
    typeMessagePlaceholder: 'Type what you want to say...',
    speakAndAlert: 'Speak Message',
    confirmSosTitle: 'Emergency Assistance Alert',
    confirmSosDesc: 'Are you sure you want to broadcast an emergency distress signal to all your contacts?',
    cancel: 'Cancel',
    sendSosNow: 'ACTIVATE EMERGENCY SOS NOW',
    allDosesCompleted: 'All Scheduled Doses Completed!',
    allDosesCompletedSub: 'You have taken all your scheduled medications for today. Wonderful health habit!',
    nextUpcomingDose: 'Next Upcoming Dose',
    dueAt: 'Scheduled for',
    instructions: 'Instructions',
    dosage: 'Dosage',
    frequency: 'Frequency',
    actions: 'Actions',
    activePrescriptions: 'Active Prescriptions',
    weeklyOverview: 'Weekly Overview',
    scheduleTimes: 'Scheduled Times',
    foodInstruction: 'Food Instruction',
    prescribingDoctor: 'Prescribing Doctor',
    specialInstructions: 'Special Instructions',
    consultations: 'Doctor Consultations',
    scheduleConsultation: 'Schedule Appointment',
    upcomingConsultations: 'Upcoming Consultations',
    pastCompleted: 'Past & Completed',
    prepNotes: 'Preparation Notes',
    sendEmailReminder: 'Send Email Reminder',
    markCompleted: 'Mark Completed',
    activePasscodes: 'Active Access Passcodes',
    generatePasscode: 'Generate Passcode',
    targetRole: 'Target Member Role',
    familyMember: 'Family Member',
    caregiverNurse: 'Caregiver / Nurse',
    permissions: 'Configurable Permissions',
    allowMeds: 'Allow managing medications',
    allowApts: 'Allow managing doctor appointments',
    allowHistory: 'Allow viewing full medical history',
    passcodeExpiry: 'Passcode Expiration',
    copyPasscode: 'Copy Passcode',
    passcodeCopied: 'Passcode copied to clipboard!',
    redeemPasscode: 'Enter / Redeem Passcode',
    connectToLovedOne: 'Connect to an Elderly Loved One',
    enterPasscodePlaceholder: 'e.g. FAMILY-8492',
    connect: 'Connect',
    connectedTeam: 'Connected Healthcare Team & Family',
    emergencyContacts: 'Registered Emergency Contacts',
    primaryPatient: 'Primary Patient',
    documentedAllergies: 'Documented Allergies',
    chronicConditions: 'Chronic Conditions',
    primaryPhysician: 'Primary Physician',
    clinicalAlerts: 'Clinical Summary',
    emarRecord: 'Electronic Medication Administration Record (eMAR)',
    administerDose: 'Administer Dose',
    printReport: 'Print Daily Care Report',
    auditTrail: 'Healthcare Audit & Modification History',
    withBreakfast: 'With Breakfast',
    afterLunch: 'After Lunch',
    withDinner: 'With Dinner',
    bedtime: 'Bedtime',
    morningRoutine: 'Morning Routine',
    eveningRoutine: 'Evening Routine',
    withFood: 'With Food / Meal',
    afterFood: 'After Food',
    beforeFood: 'Before Food',
    emptyStomach: 'Empty Stomach',
    anytime: 'Anytime',
    nightBlindness: 'Night Blindness (Nyctalopia) Mode',
    nightBlindnessShort: 'Night Vision',
    nightBlindnessDesc: 'Scotopic amber theme for vision in low light without glare',
    bedtimeMedications: 'Bedtime & Night Medications',
    amberTorch: 'Bedside Amber Lantern',
    nightSafeGuidance: 'Night Safe Audio Guidance',
  },
  hi: {
    appName: 'एल्डरकेयर+',
    tagline: 'बिना किसी भाषा या पहुँच की बाधा के स्वास्थ्य देखभाल',
    dashboard: 'डैशबोर्ड',
    myCareDashboard: 'मेरा स्वास्थ्य डैशबोर्ड',
    familyOverview: 'परिवार अवलोकन',
    nurseConsole: 'नर्स केयर कंसोल',
    medicationManagement: 'दवा प्रबंधन व समय',
    doctorAppointments: 'डॉक्टर की मुलाकातें',
    sharedProfile: 'साझा प्रोफाइल व पासकोड',
    mailbox: 'वर्चुअल मेलबॉक्स',
    goodMorning: 'सुप्रभात',
    goodAfternoon: 'शुभ दोपहर',
    goodEvening: 'शुभ संध्या',
    todaysSchedule: 'आज की दवाओं का समय',
    nextPill: 'अगली दवा',
    taken: 'ले ली',
    pending: 'बाकी है',
    missed: 'छूट गई',
    markTaken: 'दवा ले ली',
    markSkipped: 'दवा छोड़ी',
    iTookThisPill: 'मैंने यह दवा ले ली',
    streak: 'दिनों का क्रम',
    adherenceRate: 'दवा लेने की दर',
    todaysAdherence: 'आज की दवा दर',
    upcomingAppointments: 'डॉक्टर की आगामी मुलाकातें',
    silentCommunication: 'मूक संवाद (AAC)',
    voiceAssistant: 'ध्वनि सहायक',
    emergencySos: 'आपातकालीन सहायता (SOS)',
    lowVisionMode: 'उच्च कंट्रास्ट मोड',
    fontSize: 'अक्षर का आकार',
    familyAccessCode: 'पारिवारिक पासकोड',
    generateCode: 'नया पासकोड बनाएं',
    connectedFamily: 'जुड़े हुए परिवार व देखभालकर्ता',
    addMedicine: 'दवा जोड़ें',
    addAppointment: 'मुलाकात तय करें',
    settings: 'सेटिंग्स',
    logout: 'लॉग आउट',
    readSchedule: 'आज का समय बोलकर सुनाएं',
    voiceHelp: 'ध्वनि सहायता',
    yes: 'हाँ (YES)',
    no: 'नहीं (NO)',
    needWater: 'मुझे पानी चाहिए',
    inPain: 'मुझे दर्द हो रहा है',
    needHelp: 'मुझे मदद चाहिए',
    callFamily: 'मेरे परिवार को फोन करें',
    bathroom: 'मुझे शौचालय जाना है',
    dizzy: 'मुझे चक्कर आ रहे हैं',
    hungry: 'मुझे भूख लगी है',
    myMedicine: 'मेरी दवा का समय हो गया',
    tempDiscomfort: 'ठंड या गर्मी लग रही है',
    typeMessagePlaceholder: 'यहाँ लिखें जो आप कहना चाहते हैं...',
    speakAndAlert: 'संदेश बोलें',
    confirmSosTitle: 'आपातकालीन सहायता चेतावनी',
    confirmSosDesc: 'क्या आप अपने सभी आपातकालीन संपर्कों को तत्काल संदेश भेजना चाहते हैं?',
    cancel: 'रद्द करें',
    sendSosNow: 'अभी आपातकालीन SOS भेजें',
    allDosesCompleted: 'आज की सभी दवाएं पूरी हो गईं!',
    allDosesCompletedSub: 'आपने आज की सभी निर्धारित दवाएं ले ली हैं। बहुत बढ़िया स्वास्थ्य नियम!',
    nextUpcomingDose: 'अगली आने वाली दवा',
    dueAt: 'निर्धारित समय:',
    instructions: 'निर्देश',
    dosage: 'मात्रा',
    frequency: 'आवृत्ति',
    actions: 'कार्रवाई',
    activePrescriptions: 'सक्रिय दवाइयाँ',
    weeklyOverview: 'साप्ताहिक विवरण',
    scheduleTimes: 'दवा लेने का समय',
    foodInstruction: 'भोजन निर्देश',
    prescribingDoctor: 'सलाहकार डॉक्टर',
    specialInstructions: 'विशेष सावधानियाँ',
    consultations: 'डॉक्टर से परामर्श',
    scheduleConsultation: 'मुलाकात का समय लें',
    upcomingConsultations: 'आगामी मुलाकातें',
    pastCompleted: 'पिछली व संपन्न',
    prepNotes: 'जांच से पहले के निर्देश',
    sendEmailReminder: 'स्मरण ईमेल भेजें',
    markCompleted: 'पूर्ण चिह्नित करें',
    activePasscodes: 'सक्रिय पारिवारिक पासकोड',
    generatePasscode: 'नया पासकोड बनाएं',
    targetRole: 'सदस्य की भूमिका',
    familyMember: 'परिवार का सदस्य',
    caregiverNurse: 'देखभालकर्ता / नर्स',
    permissions: 'दी जाने वाली अनुमतियाँ',
    allowMeds: 'दवाइयाँ जोड़ने व बदलने की अनुमति',
    allowApts: 'डॉक्टर की मुलाक़ात तय करने की अनुमति',
    allowHistory: 'पूरी मेडिकल हिस्ट्री देखने की अनुमति',
    passcodeExpiry: 'पासकोड समाप्ति समय',
    copyPasscode: 'पासकोड कॉपी करें',
    passcodeCopied: 'पासकोड कॉपी हो गया!',
    redeemPasscode: 'पासकोड दर्ज करें व जुड़ें',
    connectToLovedOne: 'बुज़ुर्ग परिजन की प्रोफाइल से जुड़ें',
    enterPasscodePlaceholder: 'उदा. FAMILY-8492',
    connect: 'जुड़ें',
    connectedTeam: 'जुड़ा हुआ स्वास्थ्य दल व परिजन',
    emergencyContacts: 'आपातकालीन संपर्क सूची',
    primaryPatient: 'मुख्य मरीज़',
    documentedAllergies: 'ज्ञात एलर्जी',
    chronicConditions: 'दीर्घकालिक बीमारियां',
    primaryPhysician: 'मुख्य चिकित्सक (डॉक्टर)',
    clinicalAlerts: 'चिकित्सीय सारांश',
    emarRecord: 'इलेक्ट्रॉनिक दवा प्रशासन रिकॉर्ड (eMAR)',
    administerDose: 'दवा दी गई दर्ज करें',
    printReport: 'दैनिक रिपोर्ट प्रिंट करें',
    auditTrail: 'स्वास्थ्य परिवर्तन व ऑडिट हिस्ट्री',
    withBreakfast: 'सुबह नाश्ते के साथ',
    afterLunch: 'दोपहर खाने के बाद',
    withDinner: 'रात के खाने के साथ',
    bedtime: 'सोते समय',
    morningRoutine: 'सुबह के समय',
    eveningRoutine: 'शाम के समय',
    withFood: 'भोजन के साथ',
    afterFood: 'भोजन के बाद',
    beforeFood: 'भोजन से पहले',
    emptyStomach: 'खाली पेट',
    anytime: 'कभी भी',
    nightBlindness: 'रतौंधी (रात का विज़न) मोड',
    nightBlindnessShort: 'रात का विज़न',
    nightBlindnessDesc: 'कम रोशनी में बिना चमक के देखने के लिए एम्बर थीम',
    bedtimeMedications: 'सोने से पहले की रात की दवाइयाँ',
    amberTorch: 'बिस्तर के पास एम्बर लालटेन',
    nightSafeGuidance: 'रात के लिए सुरक्षित ध्वनि निर्देश',
  },
  bn: {
    appName: 'এল্ডারকেয়ার+',
    tagline: 'যোগাযোগ ও অ্যাক্সেসযোগ্যতার কোনো বাধা ছাড়া স্বাস্থ্যসেবা',
    dashboard: 'ড্যাশবোর্ড',
    myCareDashboard: 'আমার যত্ন ড্যাশবোর্ড',
    familyOverview: 'পারিবারিক বিবরণ',
    nurseConsole: 'নার্স কেয়ার কনসোল',
    medicationManagement: 'ওষুধ ব্যবস্থাপনা ও সময়সূচি',
    doctorAppointments: 'ডাক্তারের সাথে সাক্ষাত',
    sharedProfile: 'শেয়ার্ড প্রোফাইল ও পাসকোড',
    mailbox: 'ভার্চুয়াল মেলবক্স',
    goodMorning: 'সুপ্রভাত',
    goodAfternoon: 'শুভ দুপুর',
    goodEvening: 'শুভ সন্ধ্যা',
    todaysSchedule: 'আজকের ওষুধের সময়সূচি',
    nextPill: 'পরবর্তী ওষুধ',
    taken: 'নেওয়া হয়েছে',
    pending: 'বাকি আছে',
    missed: 'বাদ পড়েছে',
    markTaken: 'ওষুধ খেয়েছি',
    markSkipped: 'ওষুধ বাদ দিন',
    iTookThisPill: 'আমি এই ওষুধটি খেয়েছি',
    streak: 'টানা খাওয়ার দিন',
    adherenceRate: 'ওষুধ গ্রহণের হার',
    todaysAdherence: 'আজকের গ্রহণের হার',
    upcomingAppointments: 'ডাক্তারের আসন্ন সাক্ষাতকার',
    silentCommunication: 'নীরব যোগাযোগ (AAC)',
    voiceAssistant: 'ভয়েস সহকারী',
    emergencySos: 'জরুরি সাহায্য (SOS)',
    lowVisionMode: 'উচ্চ বৈসাদৃশ্য মোড',
    fontSize: 'অক্ষরের মাপ',
    familyAccessCode: 'পারিবারিক পাসকোড',
    generateCode: 'নতুন পাসকোড তৈরি করুন',
    connectedFamily: 'সংযুক্ত পরিবার ও সেবাদানকারী',
    addMedicine: 'ওষুধ যোগ করুন',
    addAppointment: 'অ্যাপয়েন্টমেন্ট নিন',
    settings: 'সেটিংস',
    logout: 'লগ আউট',
    readSchedule: 'আজকের সময়সূচি শুনুন',
    voiceHelp: 'ভয়েস সাহায্য',
    yes: 'হ্যাঁ (YES)',
    no: 'না (NO)',
    needWater: 'আমার জল লাগবে',
    inPain: 'আমার শরীরে ব্যথা হচ্ছে',
    needHelp: 'আমার সাহায্য দরকার',
    callFamily: 'আমার পরিবারকে কল করুন',
    bathroom: 'আমাকে বাথরুমে যেতে হবে',
    dizzy: 'আমার মাথা ঘুরছে',
    hungry: 'আমার খিদে পেয়েছে',
    myMedicine: 'আমার ওষুধের সময় হয়েছে',
    tempDiscomfort: 'খুব ঠান্ডা বা গরম লাগছে',
    typeMessagePlaceholder: 'আপনি যা বলতে চান তা টাইপ করুন...',
    speakAndAlert: 'কথা বলুন',
    confirmSosTitle: 'জরুরি সাহায্য সতর্কতা',
    confirmSosDesc: 'আপনি কি নিশ্চিত যে আপনার সমস্ত জরুরি পরিচিতিতে সতর্কবার্তা পাঠাতে চান?',
    cancel: 'বাতিল করুন',
    sendSosNow: 'এখনই জরুরি SOS চালু করুন',
    allDosesCompleted: 'আজকের সমস্ত ওষুধ খাওয়া শেষ হয়েছে!',
    allDosesCompletedSub: 'আপনি আজকের জন্য নির্ধারিত সমস্ত ওষুধ সময়মতো নিয়েছেন। দারুণ স্বাস্থ্য সচেতনতা!',
    nextUpcomingDose: 'পরবর্তী আসন্ন ওষুধ',
    dueAt: 'সময়:',
    instructions: 'নির্দেশনা',
    dosage: 'মাত্রা (ডোজ)',
    frequency: 'নিয়ম',
    actions: 'পদক্ষেপ',
    activePrescriptions: 'চালু প্রেসক্রিপশন',
    weeklyOverview: 'সাপ্তাহিক বিবরণ',
    scheduleTimes: 'ওষুধের সময়সমূহ',
    foodInstruction: 'খাবারের নিয়ম',
    prescribingDoctor: 'প্রেসক্রাইবকারী ডাক্তার',
    specialInstructions: 'বিশেষ সতর্কতা',
    consultations: 'ডাক্তারের পরামর্শ',
    scheduleConsultation: 'সাক্ষাতের দিন নির্ধারণ করুন',
    upcomingConsultations: 'আসন্ন সাক্ষাতকার',
    pastCompleted: 'বিগত ও সম্পন্ন',
    prepNotes: 'প্রস্তুতির নোট',
    sendEmailReminder: 'ইমেল রিমাইন্ডার পাঠান',
    markCompleted: 'সম্পন্ন চিহ্নিত করুন',
    activePasscodes: 'সক্রিয় পারিবারিক পাসকোড',
    generatePasscode: 'নতুন পাসকোড তৈরি করুন',
    targetRole: 'সদস্যের ভূমিকা',
    familyMember: 'পরিবারের সদস্য',
    caregiverNurse: 'সেবাদানকারী / নার্স',
    permissions: 'অনুমতিসমূহ নির্ধারণ',
    allowMeds: 'ওষুধ যোগ ও সম্পাদনার অনুমতি',
    allowApts: 'ডাক্তারের সাক্ষাতকার নির্ধারণের অনুমতি',
    allowHistory: 'সম্পূর্ণ চিকিৎসার ইতিহাস দেখার অনুমতি',
    passcodeExpiry: 'পাসকোডের মেয়াদ',
    copyPasscode: 'পাসকোড কপি করুন',
    passcodeCopied: 'পাসকোড কপি হয়েছে!',
    redeemPasscode: 'পাসকোড দিয়ে যুক্ত হন',
    connectToLovedOne: 'বয়োজ্যেষ্ঠ প্রিয়জনের সাথে যুক্ত হন',
    enterPasscodePlaceholder: 'যেমন: FAMILY-8492',
    connect: 'যুক্ত হন',
    connectedTeam: 'সংযুক্ত স্বাস্থ্য দল ও পরিবার',
    emergencyContacts: 'জরুরি যোগাযোগের তালিকা',
    primaryPatient: 'মূল রোগী',
    documentedAllergies: 'অ্যালার্জির তথ্য',
    chronicConditions: 'দীর্ঘস্থায়ী রোগ',
    primaryPhysician: 'প্রধান চিকিৎসক',
    clinicalAlerts: 'ক্লিনিক্যাল সারাংশ',
    emarRecord: 'ইলেকট্রনিক ওষুধ প্রশাসন রেকর্ড (eMAR)',
    administerDose: 'ওষুধ প্রদান রেকর্ড করুন',
    printReport: 'দৈনিক যত্ন রিপোর্ট প্রিন্ট করুন',
    auditTrail: 'স্বাস্থ্য তথ্য পরিবর্তনের ইতিহাস',
    withBreakfast: 'সকালের নাস্তার সাথে',
    afterLunch: 'দুপুরের খাবারের পর',
    withDinner: 'রাতের খাবারের সাথে',
    bedtime: 'ঘুমানোর আগে',
    morningRoutine: 'সকালের নিয়ম',
    eveningRoutine: 'সন্ধ্যার নিয়ম',
    withFood: 'খাবারের সাথে',
    afterFood: 'খাবারের পর',
    beforeFood: 'খাবারের আগে',
    emptyStomach: 'খালি পেটে',
    anytime: 'যেকোনো সময়',
    nightBlindness: 'রাতকানা (রাতের দৃষ্টি) মোড',
    nightBlindnessShort: 'রাতের দৃষ্টি',
    nightBlindnessDesc: 'অল্প আলোতে চোখের চমক ছাড়া দেখার জন্য অ্যাম্বার থিম',
    bedtimeMedications: 'ঘুমানোর আগের রাতের ওষুধ',
    amberTorch: 'বিছানার পাশের অ্যাম্বার আলো',
    nightSafeGuidance: 'রাতের জন্য নিরাপদ ভয়েস গাইডেন্স',
  }
};

const AccessibilityContext = createContext<AccessibilityContextType | undefined>(undefined);

export const AccessibilityProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [settings, setSettings] = useState<AccessibilitySettings>(() => {
    try {
      const saved = localStorage.getItem('eldercare_accessibility');
      if (saved) return { ...DEFAULT_SETTINGS, ...JSON.parse(saved) };
    } catch (e) {
      console.error(e);
    }
    return DEFAULT_SETTINGS;
  });

  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [selectedVoiceName, setSelectedVoiceName] = useState<string>('');

  // Load available speech voices
  useEffect(() => {
    const updateVoiceList = () => {
      if ('speechSynthesis' in window) {
        const voices = window.speechSynthesis.getVoices();
        setAvailableVoices(voices);
      }
    };

    updateVoiceList();
    if ('speechSynthesis' in window) {
      window.speechSynthesis.onvoiceschanged = updateVoiceList;
    }
  }, []);

  // Apply root styling for font size and high contrast
  useEffect(() => {
    try {
      localStorage.setItem('eldercare_accessibility', JSON.stringify(settings));
    } catch (e) {
      console.error(e);
    }

    const root = document.documentElement;
    if (settings.fontSizeScale === 125) {
      root.style.fontSize = '18px';
    } else if (settings.fontSizeScale === 150) {
      root.style.fontSize = '20px';
    } else if (settings.fontSizeScale === 175) {
      root.style.fontSize = '22px';
    } else {
      root.style.fontSize = '16px';
    }

    if (settings.highContrast) {
      root.classList.add('high-contrast');
    } else {
      root.classList.remove('high-contrast');
    }

    if (settings.nightBlindnessMode) {
      root.classList.add('night-blindness-mode');
    } else {
      root.classList.remove('night-blindness-mode');
    }
  }, [settings]);

  const updateSettings = useCallback((newSettings: Partial<AccessibilitySettings>) => {
    setSettings((prev) => ({ ...prev, ...newSettings }));
  }, []);

  // Web Audio Synthesizer for pleasant chimes and emergency siren
  const playChime = useCallback((type: 'success' | 'alert' | 'emergency' | 'click') => {
    if (!settings.soundEffects && type !== 'emergency') return;

    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();

      if (type === 'success') {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.type = 'sine';
        osc.frequency.setValueAtTime(523.25, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(783.99, ctx.currentTime + 0.15);
        gain.gain.setValueAtTime(0.3, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.4);
        osc.start();
        osc.stop(ctx.currentTime + 0.4);
      } else if (type === 'alert') {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(440, ctx.currentTime);
        osc.frequency.setValueAtTime(330, ctx.currentTime + 0.15);
        gain.gain.setValueAtTime(0.3, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.35);
        osc.start();
        osc.stop(ctx.currentTime + 0.35);
      } else if (type === 'click') {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.type = 'sine';
        osc.frequency.setValueAtTime(800, ctx.currentTime);
        gain.gain.setValueAtTime(0.1, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.05);
        osc.start();
        osc.stop(ctx.currentTime + 0.05);
      } else if (type === 'emergency') {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(880, ctx.currentTime);
        osc.frequency.linearRampToValueAtTime(520, ctx.currentTime + 0.3);
        osc.frequency.linearRampToValueAtTime(880, ctx.currentTime + 0.6);
        osc.frequency.linearRampToValueAtTime(520, ctx.currentTime + 0.9);
        gain.gain.setValueAtTime(0.5, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 1.2);
        osc.start();
        osc.stop(ctx.currentTime + 1.2);
      }
    } catch (e) {
      console.warn('Audio synthesis failed or blocked by browser', e);
    }
  }, [settings.soundEffects]);

  // Multilingual Speech Synthesis
  const speak = useCallback((text: string, customLang?: string) => {
    if (!('speechSynthesis' in window)) {
      console.warn('Text-to-speech not supported on this browser.');
      return;
    }

    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = settings.speechRate || 0.92;
    utterance.pitch = 1.0;

    // Detect language code
    const langCode = customLang || (
      settings.language === 'hi' ? 'hi-IN' : settings.language === 'bn' ? 'bn-IN' : 'en-US'
    );
    utterance.lang = langCode;

    // Smart voice selection for Hindi, Bengali, or English
    const voices = window.speechSynthesis.getVoices();
    if (voices.length > 0) {
      if (selectedVoiceName) {
        const found = voices.find(v => v.name === selectedVoiceName);
        if (found) utterance.voice = found;
      } else {
        // Find best match for current language
        const prefix = langCode.substring(0, 2);
        const matched = voices.find(v => v.lang.toLowerCase().startsWith(prefix));
        if (matched) {
          utterance.voice = matched;
        }
      }
    }

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.speak(utterance);
  }, [settings.speechRate, settings.language, selectedVoiceName]);

  // Spoken key helper that builds native sentences in English, Hindi, or Bengali!
  const speakKey = useCallback((phraseKey: string, params: SpokenPhraseParams = {}) => {
    const lang = settings.language;
    let spokenText = '';

    if (phraseKey === 'read_schedule') {
      const name = params.userName || 'Eleanor';
      const taken = params.takenCount || 0;
      const pending = params.pendingCount || 0;

      if (lang === 'hi') {
        spokenText = `नमस्ते ${name}। आज आपने ${taken} दवाइयाँ ले ली हैं, और ${pending} दवाइयाँ बाकी हैं। `;
        if (params.medName) {
          spokenText += `आपकी अगली दवा ${params.medName} ${params.dosage || ''} है, जिसका समय ${params.time || ''} पर है।`;
        } else {
          spokenText += 'आज की सभी निर्धारित दवाइयाँ पूरी हो चुकी हैं। बहुत बढ़िया!';
        }
      } else if (lang === 'bn') {
        spokenText = `সুপ্রভাত ${name}। আজকে আপনি ${taken}টি ওষুধ নিয়েছেন এবং ${pending}টি ওষুধ বাকি রয়েছে। `;
        if (params.medName) {
          spokenText += `আপনার পরবর্তী ওষুধ ${params.medName} ${params.dosage || ''}, সময় ${params.time || ''}।`;
        } else {
          spokenText += 'আজকের সমস্ত ওষুধ নেওয়া সম্পন্ন হয়েছে। দারুণ!';
        }
      } else {
        spokenText = `Hello ${name}. Today you have taken ${taken} medicines, and you have ${pending} remaining. `;
        if (params.medName) {
          spokenText += `Your next medicine is ${params.medName} ${params.dosage || ''}, scheduled for ${params.time || ''}.`;
        } else {
          spokenText += 'All your medicines for today are completed. Well done!';
        }
      }
    } else if (phraseKey === 'dose_taken') {
      const med = params.medName || 'Medicine';
      if (lang === 'hi') {
        spokenText = `${med} सफलतापूर्वक ले ली गई है। बहुत अच्छा!`;
      } else if (lang === 'bn') {
        spokenText = `${med} খাওয়া সম্পন্ন হয়েছে। খুব ভালো!`;
      } else {
        spokenText = `${med} confirmed taken. Great job!`;
      }
    } else if (phraseKey === 'dose_skipped') {
      const med = params.medName || 'Medicine';
      if (lang === 'hi') {
        spokenText = `${med} छोड़ दी गई है। परिवार को सूचित कर दिया गया है।`;
      } else if (lang === 'bn') {
        spokenText = `${med} বাদ দেওয়া হয়েছে। পরিবারকে জানানো হয়েছে।`;
      } else {
        spokenText = `${med} marked as skipped.`;
      }
    } else if (phraseKey === 'emergency_sos') {
      if (lang === 'hi') {
        spokenText = 'आपातकालीन सहायता चेतावनी सक्रिय कर दी गई है। आपके परिवार और संपर्कों को तुरंत संदेश भेजा जा रहा है।';
      } else if (lang === 'bn') {
        spokenText = 'জরুরি সাহায্য সতর্কতা চালু করা হয়েছে। আপনার পরিবার ও পরিচিতিদের অবিলম্বে সতর্কবার্তা পাঠানো হচ্ছে।';
      } else {
        spokenText = 'Emergency assistance alert activated. Notifying all registered emergency contacts immediately.';
      }
    } else if (phraseKey === 'passcode_generated') {
      const code = params.passcode || '';
      const formattedCode = code.split('').join(' ');
      if (lang === 'hi') {
        spokenText = `नया पारिवारिक पासकोड तैयार है। पासकोड है: ${formattedCode}। इसे अपने परिवार के साथ साझा करें।`;
      } else if (lang === 'bn') {
        spokenText = `নতুন পারিবারিক পাসকোড তৈরি হয়েছে। কোডটি হলো: ${formattedCode}। এটি আপনার পরিবারের সাথে শেয়ার করুন।`;
      } else {
        spokenText = `Access passcode generated. The code is: ${formattedCode}. Share this with your family member.`;
      }
    } else if (phraseKey === 'appointment_reminder_sent') {
      const doc = params.doctorName || 'Doctor';
      if (lang === 'hi') {
        spokenText = `डॉक्टर ${doc} की मुलाक़ात का स्मरण संदेश भेज दिया गया है।`;
      } else if (lang === 'bn') {
        spokenText = `ডাক্তার ${doc} এর সাথে সাক্ষাতের রিমাইন্ডার পাঠানো হয়েছে।`;
      } else {
        spokenText = `Appointment reminder sent for ${doc}.`;
      }
    }

    if (spokenText) {
      speak(spokenText);
    }
  }, [settings.language, speak]);

  const stopSpeaking = useCallback(() => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    }
  }, []);

  // Web Speech Recognition for English, Hindi, and Bengali
  const startListening = useCallback((onCommand: (transcript: string) => void) => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      const msg = settings.language === 'hi' 
        ? 'आपके ब्राउज़र में आवाज़ पहचान समर्थित नहीं है। कृपया गूगल क्रोम या एज का उपयोग करें।'
        : settings.language === 'bn'
        ? 'আপনার ব্রাউজারে ভয়েস রিকগনিশন কাজ করছে না। দয়া করে গুগল ক্রোম ব্যবহার করুন।'
        : 'Voice recognition is not supported in this browser. Please use Chrome, Edge, or Safari.';
      speak(msg);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = settings.language === 'hi' ? 'hi-IN' : settings.language === 'bn' ? 'bn-IN' : 'en-US';

      recognition.onstart = () => {
        setIsListening(true);
        playChime('click');
      };

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setIsListening(false);
        onCommand(transcript);
      };

      recognition.onerror = () => {
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognition.start();
    } catch (e) {
      console.error('Speech recognition error', e);
      setIsListening(false);
    }
  }, [settings.language, speak, playChime]);

  const stopListening = useCallback(() => {
    setIsListening(false);
  }, []);

  const t = useCallback((key: string): string => {
    const lang = settings.language;
    return TRANSLATIONS[lang]?.[key] || TRANSLATIONS.en[key] || key;
  }, [settings.language]);

  return (
    <AccessibilityContext.Provider
      value={{
        settings,
        updateSettings,
        speak,
        speakKey,
        stopSpeaking,
        isSpeaking,
        isListening,
        startListening,
        stopListening,
        playChime,
        t,
        availableVoices,
        selectedVoiceName,
        setSelectedVoiceName,
      }}
    >
      {children}
    </AccessibilityContext.Provider>
  );
};

export const useAccessibility = (): AccessibilityContextType => {
  const context = useContext(AccessibilityContext);
  if (!context) {
    throw new Error('useAccessibility must be used within an AccessibilityProvider');
  }
  return context;
};
