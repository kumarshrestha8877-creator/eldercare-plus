// Authentication, Role-Based Access, and Healthcare State Manager
// Complete ecosystem for Elderly individuals, Family members, and Caregivers.

import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import confetti from 'canvas-confetti';
import { 
  UserProfile, 
  UserRole, 
  HealthcareProfile, 
  Medicine, 
  MedicationScheduleItem, 
  DoctorAppointment, 
  EmergencyContact, 
  AccessPasscode, 
  FamilyCaregiverRelation, 
  NotificationLog, 
  AuditLog,
  AuthCredentials,
  RegisterPayload
} from '../types';
import { localStore, UserSession, INITIAL_MEDICINES, INITIAL_SCHEDULES } from '../lib/supabase';
import { sendEmailNotification } from '../lib/resend';
import { useAccessibility } from './AccessibilityContext';

interface AuthContextType {
  // Authentication & Session
  isAuthenticated: boolean;
  login: (credentials: AuthCredentials) => Promise<{ success: boolean; error?: string }>;
  signup: (payload: RegisterPayload) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  quickSignIn: (role: UserRole) => void;

  // Guided Onboarding Tour
  isTourOpen: boolean;
  setTourOpen: (open: boolean) => void;

  // Starter Template Helpers
  loadSampleMedicines: () => void;
  clearMedicines: () => void;

  currentUser: UserProfile;
  currentRole: UserRole;
  setCurrentRole: (role: UserRole) => void;
  switchUser: (role: UserRole) => void;
  
  // Data state
  healthcareProfile: HealthcareProfile;
  updateHealthcareProfile: (profile: HealthcareProfile) => void;
  medicines: Medicine[];
  schedules: MedicationScheduleItem[];
  appointments: DoctorAppointment[];
  emergencyContacts: EmergencyContact[];
  passcodes: AccessPasscode[];
  relations: FamilyCaregiverRelation[];
  notifications: NotificationLog[];
  auditLogs: AuditLog[];
  
  // Medication actions
  markDoseStatus: (scheduleId: string, status: 'taken' | 'skipped' | 'pending', reason?: string) => Promise<void>;
  addMedicine: (med: Omit<Medicine, 'id' | 'createdAt'>) => void;
  updateMedicine: (id: string, med: Partial<Medicine>) => void;
  deleteMedicine: (id: string) => void;
  
  // Appointment actions
  addAppointment: (apt: Omit<DoctorAppointment, 'id' | 'createdAt' | 'reminderSent'>) => void;
  updateAppointment: (id: string, apt: Partial<DoctorAppointment>) => void;
  deleteAppointment: (id: string) => void;
  sendAppointmentReminder: (aptId: string) => Promise<boolean>;

  // Emergency contact actions
  addEmergencyContact: (contact: Omit<EmergencyContact, 'id'>) => void;
  deleteEmergencyContact: (id: string) => void;
  
  // Passcode-based Family Access actions
  generatePasscode: (opts: {
    targetRole: 'family' | 'caregiver';
    label: string;
    canManageMedications: boolean;
    canManageAppointments: boolean;
    canViewMedicalHistory: boolean;
    expiryDays?: number;
  }) => AccessPasscode;
  redeemPasscode: (code: string) => Promise<{ success: boolean; message: string }>;
  revokePasscode: (codeId: string) => void;
  updateRelationPermissions: (relationId: string, perms: {
    canManageMedications: boolean;
    canManageAppointments: boolean;
    canViewMedicalHistory: boolean;
    notifyOnMissedDose: boolean;
    notifyOnSos: boolean;
  }) => void;
  revokeRelation: (relationId: string) => void;

  // Emergency SOS
  triggerEmergencySos: (customNote?: string) => Promise<{ success: boolean; contactCount: number }>;

  // Automated Email Trigger
  triggerScheduledEmailCheck: () => Promise<number>;

  // Metrics
  adherencePercentage: number;
  adherenceStreak: number;
  stats: {
    totalScheduled: number;
    takenCount: number;
    pendingCount: number;
    missedCount: number;
  };
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { playChime, speak, speakKey } = useAccessibility();

  // Active Session & Authentication
  const [session, setSession] = useState<UserSession | null>(() => localStore.getSession());
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => Boolean(localStore.getSession()));

  // Guided Onboarding Tour State
  const [isTourOpen, setTourOpen] = useState<boolean>(false);

  // Active Role and Current User (restored from session if authenticated)
  const [currentRole, setCurrentRoleState] = useState<UserRole>(() => {
    const active = localStore.getSession();
    return active ? active.role : 'elderly';
  });

  const [currentUser, setCurrentUser] = useState<UserProfile>(() => {
    const active = localStore.getSession();
    if (active) {
      const found = localStore.findUserByEmail(active.email);
      if (found) return found;
      if (active.role === 'elderly') return localStore.getElderlyUser();
      if (active.role === 'family') return localStore.getFamilyUser();
      return localStore.getCaregiverUser();
    }
    return localStore.getElderlyUser();
  });

  // Core Data
  const [healthcareProfile, setHealthcareProfile] = useState<HealthcareProfile>(() => localStore.getHealthcareProfile());
  const [medicines, setMedicines] = useState<Medicine[]>(() => localStore.getMedicines());
  const [schedules, setSchedules] = useState<MedicationScheduleItem[]>(() => localStore.getSchedules());
  const [appointments, setAppointments] = useState<DoctorAppointment[]>(() => localStore.getAppointments());
  const [emergencyContacts, setEmergencyContacts] = useState<EmergencyContact[]>(() => localStore.getEmergencyContacts());
  const [passcodes, setPasscodes] = useState<AccessPasscode[]>(() => localStore.getPasscodes());
  const [relations, setRelations] = useState<FamilyCaregiverRelation[]>(() => localStore.getRelations());
  const [notifications, setNotifications] = useState<NotificationLog[]>(() => localStore.getNotifications());
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(() => localStore.getAuditLogs());

  // Starter Template Helpers
  const loadSampleMedicines = useCallback(() => {
    localStore.saveMedicines(INITIAL_MEDICINES);
    localStore.saveSchedules(INITIAL_SCHEDULES);
    setMedicines(INITIAL_MEDICINES);
    setSchedules(INITIAL_SCHEDULES);
    playChime('success');
    speak('Sample prescription schedule loaded.');
  }, [playChime, speak]);

  const clearMedicines = useCallback(() => {
    localStore.saveMedicines([]);
    localStore.saveSchedules([]);
    setMedicines([]);
    setSchedules([]);
    playChime('click');
    speak('Medication schedule cleared.');
  }, [playChime, speak]);

  // Role switching
  const switchUser = useCallback((role: UserRole) => {
    setCurrentRoleState(role);
    let targetUser: UserProfile;
    if (role === 'elderly') {
      targetUser = localStore.findUserByEmail('eleanor.vance@eldercare.plus') || localStore.getElderlyUser();
    } else if (role === 'family') {
      targetUser = localStore.findUserByEmail('priya.vance@familycare.org') || localStore.getFamilyUser();
    } else {
      targetUser = localStore.findUserByEmail('sarah.nurse@elderhealth.net') || localStore.getCaregiverUser();
    }
    setCurrentUser(targetUser);

    if (session) {
      const updatedSession: UserSession = {
        userId: targetUser.id,
        role: targetUser.role,
        email: targetUser.email,
        fullName: targetUser.fullName,
        token: session.token,
        loginTime: session.loginTime,
      };
      localStore.saveSession(updatedSession);
      setSession(updatedSession);
    }
    playChime('click');
  }, [session, playChime]);

  const setCurrentRole = useCallback((role: UserRole) => {
    switchUser(role);
  }, [switchUser]);

  // Authentication: Login
  const login = useCallback(async (credentials: AuthCredentials): Promise<{ success: boolean; error?: string }> => {
    const email = credentials.email.trim();
    const password = credentials.password || '';

    if (!email) {
      return { success: false, error: 'Email address is required.' };
    }
    if (!password) {
      return { success: false, error: 'Password is required.' };
    }

    const user = localStore.findUserByEmail(email);
    if (!user) {
      return { 
        success: false, 
        error: 'No account found with this email. You can register a new account or use Quick Demo Sign-in below.' 
      };
    }

    if (user.password && user.password !== password) {
      return { success: false, error: 'Invalid password. Please check your credentials.' };
    }

    const newSession: UserSession = {
      userId: user.id,
      role: user.role,
      email: user.email,
      fullName: user.fullName,
      token: `sess_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`,
      loginTime: new Date().toISOString(),
    };

    localStore.saveSession(newSession);
    setSession(newSession);
    setIsAuthenticated(true);
    setCurrentRoleState(user.role);
    setCurrentUser(user);

    playChime('success');
    speak(`Welcome back, ${(user.fullName || 'User').split(' ')[0]}`);

    return { success: true };
  }, [playChime, speak]);

  // Authentication: Signup
  const signup = useCallback(async (payload: RegisterPayload): Promise<{ success: boolean; error?: string }> => {
    if (!payload.email || !payload.fullName || !payload.password) {
      return { success: false, error: 'Full name, email, and password are required.' };
    }

    const existing = localStore.findUserByEmail(payload.email);
    if (existing) {
      return { success: false, error: 'An account with this email already exists. Please sign in.' };
    }

    const newUser: UserProfile & { password?: string } = {
      id: `usr-${payload.role}-${Date.now().toString(36)}`,
      fullName: payload.fullName.trim(),
      email: payload.email.trim().toLowerCase(),
      password: payload.password,
      role: payload.role,
      phone: payload.phone || '+1 (555) 000-0000',
      relationshipLabel: payload.relationshipLabel || (payload.role === 'elderly' ? 'Self' : payload.role === 'family' ? 'Family Member' : 'Nurse'),
      languagePreference: payload.languagePreference || 'en',
      avatarUrl: payload.role === 'elderly'
        ? 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=256'
        : payload.role === 'family'
        ? 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=256'
        : 'https://images.unsplash.com/photo-1594824813589-399081e792e8?auto=format&fit=crop&q=80&w=256',
      createdAt: new Date().toISOString(),
    };

    localStore.createUserAccount(newUser);

    // If family or caregiver registers, link them to the active healthcare profile
    if (payload.role === 'family' || payload.role === 'caregiver') {
      const newRelation: FamilyCaregiverRelation = {
        id: `rel-${Date.now().toString(36)}`,
        elderlyUserId: healthcareProfile.elderlyUserId || 'usr-elderly-01',
        elderlyName: 'Eleanor Vance',
        memberUserId: newUser.id,
        memberName: newUser.fullName,
        memberEmail: newUser.email,
        memberRole: payload.role,
        relationshipLabel: newUser.relationshipLabel || (payload.role === 'family' ? 'Family Member' : 'Visiting Nurse'),
        status: 'active',
        canManageMedications: true,
        canManageAppointments: true,
        canViewMedicalHistory: true,
        notifyOnMissedDose: true,
        notifyOnSos: true,
        joinedAt: new Date().toISOString(),
      };
      const currentRels = localStore.getRelations();
      localStore.saveRelations([newRelation, ...currentRels]);
      setRelations([newRelation, ...currentRels]);
    }

    const newSession: UserSession = {
      userId: newUser.id,
      role: newUser.role,
      email: newUser.email,
      fullName: newUser.fullName,
      token: `sess_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`,
      loginTime: new Date().toISOString(),
    };

    localStore.saveSession(newSession);
    setSession(newSession);
    setIsAuthenticated(true);
    setCurrentRoleState(newUser.role);
    setCurrentUser(newUser);

    confetti({ particleCount: 60, spread: 70, origin: { y: 0.6 } });
    playChime('success');
    speak(`Account created. Welcome to ElderCare Plus, ${(newUser.fullName || 'User').split(' ')[0]}`);
    setTourOpen(true);

    return { success: true };
  }, [healthcareProfile.elderlyUserId, playChime, speak]);

  // Authentication: Logout
  const logout = useCallback(() => {
    localStore.clearSession();
    setSession(null);
    setIsAuthenticated(false);
    playChime('click');
    speak('You have been logged out.');
  }, [playChime, speak]);

  // Authentication: Quick Role Sign-in
  const quickSignIn = useCallback((role: UserRole) => {
    let user: (UserProfile & { password?: string }) | undefined;
    if (role === 'elderly') {
      user = localStore.findUserByEmail('eleanor.vance@eldercare.plus') || localStore.getElderlyUser();
    } else if (role === 'family') {
      user = localStore.findUserByEmail('priya.vance@familycare.org') || localStore.getFamilyUser();
    } else {
      user = localStore.findUserByEmail('sarah.nurse@elderhealth.net') || localStore.getCaregiverUser();
    }

    if (user) {
      const newSession: UserSession = {
        userId: user.id,
        role: user.role,
        email: user.email,
        fullName: user.fullName,
        token: `sess_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`,
        loginTime: new Date().toISOString(),
      };
      localStore.saveSession(newSession);
      setSession(newSession);
      setIsAuthenticated(true);
      setCurrentRoleState(user.role);
      setCurrentUser(user);
      playChime('success');
      speak(`Logged in as ${(user.fullName || 'User').split(' ')[0]}`);
    }
  }, [playChime, speak]);

  // Record Audit Log Helper
  const logAudit = useCallback((action: string, details: string) => {
    const newLog: AuditLog = {
      id: `aud-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      elderlyUserId: healthcareProfile.elderlyUserId,
      actorName: currentUser.fullName,
      actorRole: currentRole,
      action,
      details,
      timestamp: new Date().toISOString(),
    };
    localStore.addAuditLog(newLog);
    setAuditLogs(prev => [newLog, ...prev]);
  }, [currentUser, currentRole, healthcareProfile.elderlyUserId]);

  // Record Notification Log Helper
  const logNotification = useCallback((log: Omit<NotificationLog, 'id' | 'elderlyUserId' | 'sentAt'>) => {
    const newNotif: NotificationLog = {
      ...log,
      id: `notif-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      elderlyUserId: healthcareProfile.elderlyUserId,
      sentAt: new Date().toISOString(),
    };
    localStore.addNotification(newNotif);
    setNotifications(prev => [newNotif, ...prev]);
  }, [healthcareProfile.elderlyUserId]);

  // Update Healthcare Profile
  const updateHealthcareProfile = useCallback((newProfile: HealthcareProfile) => {
    setHealthcareProfile(newProfile);
    localStore.updateHealthcareProfile(newProfile);
    logAudit('PROFILE_UPDATED', `Healthcare profile updated by ${currentUser.fullName}`);
  }, [currentUser, logAudit]);

  // -------------------------------------------------------------
  // MEDICATION MANAGEMENT & ADHERENCE
  // -------------------------------------------------------------
  const markDoseStatus = useCallback(async (scheduleId: string, status: 'taken' | 'skipped' | 'pending', reason?: string) => {
    const updatedSchedules = schedules.map(item => {
      if (item.id === scheduleId) {
        return {
          ...item,
          status,
          takenAt: status === 'taken' ? new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : undefined,
          skippedReason: reason,
        };
      }
      return item;
    });

    setSchedules(updatedSchedules);
    localStore.saveSchedules(updatedSchedules);

    const affectedItem = schedules.find(s => s.id === scheduleId);
    const medName = affectedItem?.medicineName || 'Medicine';

    if (status === 'taken') {
      playChime('success');
      // Confetti celebration for taking pills!
      try {
        confetti({
          particleCount: 50,
          spread: 60,
          origin: { y: 0.8 },
          colors: ['#10B981', '#3B82F6', '#F59E0B'],
        });
      } catch (e) {
        // ignore if canvas-confetti is not loaded yet
      }
      speakKey('dose_taken', { medName });
      logAudit('CONFIRMED_DOSE', `Marked ${medName} as Taken by ${currentUser.fullName}`);
    } else if (status === 'skipped') {
      playChime('alert');
      speakKey('dose_skipped', { medName });
      logAudit('SKIPPED_DOSE', `Skipped ${medName}. Reason: ${reason || 'Not specified'} by ${currentUser.fullName}`);

      // Check if family/caregivers should receive missed dose notification
      const activeRelationsToNotify = relations.filter(r => r.status === 'active' && r.notifyOnMissedDose);
      for (const rel of activeRelationsToNotify) {
        const sendResult = await sendEmailNotification({
          to: rel.memberEmail,
          recipientName: rel.memberName,
          subject: `⚠️ Missed Medication Alert: ${healthcareProfile.emergencyNotes ? 'Eleanor Vance' : 'Elderly Patient'}`,
          type: 'missed_medication',
          patientName: 'Eleanor Vance',
          details: {
            medicineName: medName,
            dosage: affectedItem?.dosage || 'Prescribed dose',
            time: affectedItem?.scheduledTime || 'Today',
          },
        });

        logNotification({
          recipientEmail: rel.memberEmail,
          recipientName: rel.memberName,
          type: 'missed_medication',
          subject: `Missed Medication Alert: ${medName}`,
          bodyPreview: `Automated alert for ${rel.memberName} that ${medName} was missed or skipped.`,
          status: sendResult.status,
          errorMessage: sendResult.error,
        });
      }
    } else {
      logAudit('RESET_DOSE', `Reset ${medName} to pending status`);
    }
  }, [schedules, relations, currentUser, healthcareProfile, playChime, speak, logAudit, logNotification]);

  const addMedicine = useCallback((newMed: Omit<Medicine, 'id' | 'createdAt'>) => {
    const med: Medicine = {
      ...newMed,
      id: `med-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    const updatedMeds = [med, ...medicines];
    setMedicines(updatedMeds);
    localStore.saveMedicines(updatedMeds);

    // Also generate schedule entries for today
    const newScheduleEntries: MedicationScheduleItem[] = med.scheduleTimes.map((time, idx) => ({
      id: `sch-${Date.now()}-${idx}`,
      medicineId: med.id,
      medicineName: med.name,
      dosage: med.dosage,
      form: med.form,
      colorCode: med.colorCode,
      foodInstruction: med.foodInstruction,
      scheduledTime: time,
      status: 'pending',
      instructions: med.instructions,
    }));

    const updatedSchedules = [...schedules, ...newScheduleEntries];
    setSchedules(updatedSchedules);
    localStore.saveSchedules(updatedSchedules);

    logAudit('MEDICATION_ADDED', `Added new medicine: ${med.name} (${med.dosage}) by ${currentUser.fullName}`);
    playChime('success');
    speak(`Added ${med.name} to medication schedule.`);
  }, [medicines, schedules, currentUser, logAudit, playChime, speak]);

  const updateMedicine = useCallback((id: string, updates: Partial<Medicine>) => {
    const updated = medicines.map(m => m.id === id ? { ...m, ...updates } : m);
    setMedicines(updated);
    localStore.saveMedicines(updated);
    logAudit('MEDICATION_UPDATED', `Updated medicine ID ${id} by ${currentUser.fullName}`);
  }, [medicines, currentUser, logAudit]);

  const deleteMedicine = useCallback((id: string) => {
    const medToDelete = medicines.find(m => m.id === id);
    const updatedMeds = medicines.filter(m => m.id !== id);
    const updatedSchedules = schedules.filter(s => s.medicineId !== id);
    setMedicines(updatedMeds);
    setSchedules(updatedSchedules);
    localStore.saveMedicines(updatedMeds);
    localStore.saveSchedules(updatedSchedules);
    logAudit('MEDICATION_DELETED', `Deleted medicine ${medToDelete?.name || id} by ${currentUser.fullName}`);
  }, [medicines, schedules, currentUser, logAudit]);

  // -------------------------------------------------------------
  // DOCTOR APPOINTMENTS
  // -------------------------------------------------------------
  const addAppointment = useCallback((aptData: Omit<DoctorAppointment, 'id' | 'createdAt' | 'reminderSent'>) => {
    const apt: DoctorAppointment = {
      ...aptData,
      id: `apt-${Date.now()}`,
      reminderSent: false,
      createdAt: new Date().toISOString(),
    };
    const updated = [apt, ...appointments];
    setAppointments(updated);
    localStore.saveAppointments(updated);
    logAudit('APPOINTMENT_ADDED', `Scheduled appointment with ${apt.doctorName} on ${apt.appointmentDate}`);
    playChime('success');
  }, [appointments, logAudit, playChime]);

  const updateAppointment = useCallback((id: string, updates: Partial<DoctorAppointment>) => {
    const updated = appointments.map(a => a.id === id ? { ...a, ...updates } : a);
    setAppointments(updated);
    localStore.saveAppointments(updated);
    logAudit('APPOINTMENT_UPDATED', `Updated appointment ID ${id} by ${currentUser.fullName}`);
  }, [appointments, currentUser, logAudit]);

  const deleteAppointment = useCallback((id: string) => {
    const updated = appointments.filter(a => a.id !== id);
    setAppointments(updated);
    localStore.saveAppointments(updated);
    logAudit('APPOINTMENT_DELETED', `Cancelled appointment ID ${id}`);
  }, [appointments, logAudit]);

  const sendAppointmentReminder = useCallback(async (aptId: string): Promise<boolean> => {
    const apt = appointments.find(a => a.id === aptId);
    if (!apt) return false;

    // Send to primary emergency contact & family members
    const recipientEmails = emergencyContacts.filter(c => c.canReceiveSosEmail && c.email).map(c => ({
      email: c.email,
      name: c.contactName,
    }));

    let atLeastOneSuccess = false;
    for (const recipient of recipientEmails) {
      const result = await sendEmailNotification({
        to: recipient.email,
        recipientName: recipient.name,
        subject: `Reminder: Doctor Appointment with ${apt.doctorName} for Eleanor Vance`,
        type: 'doctor_appointment',
        patientName: 'Eleanor Vance',
        details: {
          doctorName: apt.doctorName,
          hospitalName: apt.hospitalName,
          appointmentDate: apt.appointmentDate,
          appointmentTime: apt.appointmentTime,
        },
      });

      logNotification({
        recipientEmail: recipient.email,
        recipientName: recipient.name,
        type: 'doctor_appointment',
        subject: `Appointment Reminder: ${apt.doctorName}`,
        bodyPreview: `Consultation on ${apt.appointmentDate} at ${apt.hospitalName}.`,
        status: result.status,
        errorMessage: result.error,
      });

      if (result.success) atLeastOneSuccess = true;
    }

    // Mark reminder sent
    updateAppointment(aptId, { reminderSent: true });
    speakKey('appointment_reminder_sent', { doctorName: apt.doctorName });
    return atLeastOneSuccess;
  }, [appointments, emergencyContacts, logNotification, updateAppointment]);

  // -------------------------------------------------------------
  // EMERGENCY CONTACTS
  // -------------------------------------------------------------
  const addEmergencyContact = useCallback((contactData: Omit<EmergencyContact, 'id'>) => {
    const newContact: EmergencyContact = {
      ...contactData,
      id: `em-${Date.now()}`,
    };
    const updated = [...emergencyContacts, newContact];
    setEmergencyContacts(updated);
    localStore.saveEmergencyContacts(updated);
    logAudit('CONTACT_ADDED', `Added emergency contact: ${newContact.contactName} (${newContact.relationship})`);
  }, [emergencyContacts, logAudit]);

  const deleteEmergencyContact = useCallback((id: string) => {
    const updated = emergencyContacts.filter(c => c.id !== id);
    setEmergencyContacts(updated);
    localStore.saveEmergencyContacts(updated);
    logAudit('CONTACT_DELETED', `Removed emergency contact ID ${id}`);
  }, [emergencyContacts, logAudit]);

  // -------------------------------------------------------------
  // PASSCODE-BASED FAMILY ACCESS SYSTEM (MANDATORY REQUIREMENT)
  // -------------------------------------------------------------
  const generatePasscode = useCallback((opts: {
    targetRole: 'family' | 'caregiver';
    label: string;
    canManageMedications: boolean;
    canManageAppointments: boolean;
    canViewMedicalHistory: boolean;
    expiryDays?: number;
  }): AccessPasscode => {
    const prefix = opts.targetRole === 'caregiver' ? 'NURSE' : 'FAMILY';
    const randomDigits = Math.floor(1000 + Math.random() * 9000);
    const codeString = `${prefix}-${randomDigits}`;

    const newCode: AccessPasscode = {
      id: `code-${Date.now()}`,
      elderlyUserId: healthcareProfile.elderlyUserId,
      passcode: codeString,
      targetRole: opts.targetRole,
      label: opts.label || `Access Code for ${opts.targetRole}`,
      canManageMedications: opts.canManageMedications,
      canManageAppointments: opts.canManageAppointments,
      canViewMedicalHistory: opts.canViewMedicalHistory,
      expiresAt: new Date(Date.now() + 86400000 * (opts.expiryDays || 14)).toISOString(),
      isRevoked: false,
      maxUses: 3,
      usedCount: 0,
      createdAt: new Date().toISOString(),
    };

    const updated = [newCode, ...passcodes];
    setPasscodes(updated);
    localStore.savePasscodes(updated);

    logAudit('PASSCODE_GENERATED', `Generated passcode ${codeString} (${opts.label}) by ${currentUser.fullName}`);
    playChime('success');
    speakKey('passcode_generated', { passcode: codeString });

    return newCode;
  }, [passcodes, healthcareProfile.elderlyUserId, currentUser, logAudit, playChime, speakKey]);

  const redeemPasscode = useCallback(async (enteredCode: string): Promise<{ success: boolean; message: string }> => {
    const cleanCode = enteredCode.trim().toUpperCase();
    const foundCode = passcodes.find(c => c.passcode.toUpperCase() === cleanCode);

    if (!foundCode) {
      return { success: false, message: 'Invalid passcode. Please verify the code provided by the elderly family member.' };
    }

    if (foundCode.isRevoked) {
      return { success: false, message: 'This passcode has been revoked by the elderly user.' };
    }

    if (new Date(foundCode.expiresAt) < new Date()) {
      return { success: false, message: 'This passcode has expired. Please ask the elderly user to generate a new code.' };
    }

    if (foundCode.usedCount >= foundCode.maxUses) {
      return { success: false, message: 'This passcode has reached its maximum connection limit.' };
    }

    // Check if already paired
    const alreadyConnected = relations.some(r => r.memberEmail === currentUser.email && r.status === 'active');
    if (alreadyConnected) {
      return { success: false, message: 'You are already connected to this healthcare profile!' };
    }

    // Increment used count
    const updatedCodes = passcodes.map(c => c.id === foundCode.id ? { ...c, usedCount: c.usedCount + 1 } : c);
    setPasscodes(updatedCodes);
    localStore.savePasscodes(updatedCodes);

    // Create active relation
    const newRelation: FamilyCaregiverRelation = {
      id: `rel-${Date.now()}`,
      elderlyUserId: foundCode.elderlyUserId,
      elderlyName: 'Eleanor Vance',
      memberUserId: currentUser.id,
      memberName: currentUser.fullName,
      memberEmail: currentUser.email,
      memberRole: foundCode.targetRole,
      relationshipLabel: foundCode.label || (foundCode.targetRole === 'caregiver' ? 'Visiting Caregiver' : 'Family Member'),
      status: 'active',
      canManageMedications: foundCode.canManageMedications,
      canManageAppointments: foundCode.canManageAppointments,
      canViewMedicalHistory: foundCode.canViewMedicalHistory,
      notifyOnMissedDose: true,
      notifyOnSos: true,
      joinedAt: new Date().toISOString(),
    };

    const updatedRelations = [newRelation, ...relations];
    setRelations(updatedRelations);
    localStore.saveRelations(updatedRelations);

    logAudit('ACCESS_CONNECTED', `${currentUser.fullName} (${currentUser.role}) connected via passcode ${cleanCode}`);

    // Send access notification email
    const emailResult = await sendEmailNotification({
      to: currentUser.email,
      recipientName: currentUser.fullName,
      subject: `Connected to Eleanor Vance's Healthcare Profile on ElderCare+`,
      type: 'access_granted',
      patientName: 'Eleanor Vance',
      details: {},
    });

    logNotification({
      recipientEmail: currentUser.email,
      recipientName: currentUser.fullName,
      type: 'access_granted',
      subject: `Access Connected to Eleanor Vance`,
      bodyPreview: `Passcode ${cleanCode} verified. Connected with permissions: Meds=${foundCode.canManageMedications}, Appointments=${foundCode.canManageAppointments}.`,
      status: emailResult.status,
      errorMessage: emailResult.error,
    });

    playChime('success');
    return { success: true, message: `Access successfully granted to Eleanor Vance's healthcare profile!` };
  }, [passcodes, relations, currentUser, logAudit, logNotification, playChime]);

  const revokePasscode = useCallback((codeId: string) => {
    const updated = passcodes.map(c => c.id === codeId ? { ...c, isRevoked: true } : c);
    setPasscodes(updated);
    localStore.savePasscodes(updated);
    logAudit('PASSCODE_REVOKED', `Revoked passcode ID ${codeId}`);
  }, [passcodes, logAudit]);

  const updateRelationPermissions = useCallback((relationId: string, perms: {
    canManageMedications: boolean;
    canManageAppointments: boolean;
    canViewMedicalHistory: boolean;
    notifyOnMissedDose: boolean;
    notifyOnSos: boolean;
  }) => {
    const updated = relations.map(r => r.id === relationId ? { ...r, ...perms } : r);
    setRelations(updated);
    localStore.saveRelations(updated);
    logAudit('PERMISSIONS_UPDATED', `Updated permissions for connected member relation ${relationId}`);
  }, [relations, logAudit]);

  const revokeRelation = useCallback((relationId: string) => {
    const rel = relations.find(r => r.id === relationId);
    const updated = relations.filter(r => r.id !== relationId);
    setRelations(updated);
    localStore.saveRelations(updated);
    logAudit('ACCESS_REVOKED', `Revoked access for ${rel?.memberName || relationId}`);
    playChime('alert');
  }, [relations, logAudit, playChime]);

  // -------------------------------------------------------------
  // EMERGENCY SOS BROADCAST
  // -------------------------------------------------------------
  const triggerEmergencySos = useCallback(async (customNote?: string): Promise<{ success: boolean; contactCount: number }> => {
    playChime('emergency');
    speakKey('emergency_sos');

    logAudit('EMERGENCY_SOS_TRIGGERED', `SOS Emergency broadcast activated by ${currentUser.fullName}. Note: ${customNote || 'No extra note'}`);

    // Gather recipients: emergency contacts with email + relations with notifyOnSos
    const recipientsMap = new Map<string, string>();
    emergencyContacts.forEach(c => {
      if (c.email && c.canReceiveSosEmail) {
        recipientsMap.set(c.email, c.contactName);
      }
    });
    relations.forEach(r => {
      if (r.notifyOnSos && r.status === 'active' && r.memberEmail) {
        recipientsMap.set(r.memberEmail, r.memberName);
      }
    });

    let successCount = 0;
    const recipientEntries = Array.from(recipientsMap.entries());

    for (const [email, name] of recipientEntries) {
      const result = await sendEmailNotification({
        to: email,
        recipientName: name,
        subject: `🚨 EMERGENCY SOS: Immediate Assistance Needed for Eleanor Vance`,
        type: 'emergency_sos',
        patientName: 'Eleanor Vance',
        details: {
          emergencyMessage: customNote || 'Emergency SOS button activated from ElderCare+ app.',
          bloodGroup: healthcareProfile.bloodGroup,
          allergies: healthcareProfile.knownAllergies,
          emergencyPhone: emergencyContacts.find(c => c.isPrimary)?.phone || '+1 (555) 987-6543',
        },
      });

      logNotification({
        recipientEmail: email,
        recipientName: name,
        type: 'emergency_sos',
        subject: `🚨 EMERGENCY SOS for Eleanor Vance`,
        bodyPreview: `Immediate alert broadcasted to ${name}. Patient note: ${customNote || 'Emergency button pressed'}.`,
        status: result.status,
        errorMessage: result.error,
      });

      if (result.success) successCount++;
    }

    return {
      success: successCount > 0 || recipientEntries.length === 0,
      contactCount: recipientEntries.length,
    };
  }, [playChime, speak, currentUser, healthcareProfile, emergencyContacts, relations, logAudit, logNotification]);

  // -------------------------------------------------------------
  // AUTOMATED EMAIL CHECK TRIGGER
  // -------------------------------------------------------------
  const triggerScheduledEmailCheck = useCallback(async (): Promise<number> => {
    // Finds upcoming pending meds for today and triggers reminders
    const pendingMeds = schedules.filter(s => s.status === 'pending');
    let emailsSent = 0;

    for (const item of pendingMeds) {
      const result = await sendEmailNotification({
        to: currentUser.email,
        recipientName: currentUser.fullName,
        subject: `ElderCare+ Dose Reminder: ${item.medicineName} (${item.scheduledTime})`,
        type: 'upcoming_dose',
        patientName: 'Eleanor Vance',
        details: {
          medicineName: item.medicineName,
          dosage: item.dosage,
          time: item.scheduledTime,
          foodInstruction: item.foodInstruction,
        },
      });

      logNotification({
        recipientEmail: currentUser.email,
        recipientName: currentUser.fullName,
        type: 'upcoming_dose',
        subject: `Dose Reminder: ${item.medicineName}`,
        bodyPreview: `Scheduled for ${item.scheduledTime}. ${item.foodInstruction}`,
        status: result.status,
        errorMessage: result.error,
      });

      if (result.success) emailsSent++;
    }

    return emailsSent;
  }, [schedules, currentUser, logNotification]);

  // Adherence Calculations
  const totalScheduled = schedules.length;
  const takenCount = schedules.filter(s => s.status === 'taken').length;
  const pendingCount = schedules.filter(s => s.status === 'pending').length;
  const missedCount = schedules.filter(s => s.status === 'skipped').length;
  const adherencePercentage = totalScheduled > 0 ? Math.round((takenCount / totalScheduled) * 100) : 100;
  const adherenceStreak = 8; // 8 consecutive days of >85% adherence

  return (
    <AuthContext.Provider
      value={{
        isAuthenticated,
        login,
        signup,
        logout,
        quickSignIn,
        isTourOpen,
        setTourOpen,
        loadSampleMedicines,
        clearMedicines,
        currentUser,
        currentRole,
        setCurrentRole,
        switchUser,
        healthcareProfile,
        updateHealthcareProfile,
        medicines,
        schedules,
        appointments,
        emergencyContacts,
        passcodes,
        relations,
        notifications,
        auditLogs,
        markDoseStatus,
        addMedicine,
        updateMedicine,
        deleteMedicine,
        addAppointment,
        updateAppointment,
        deleteAppointment,
        sendAppointmentReminder,
        addEmergencyContact,
        deleteEmergencyContact,
        generatePasscode,
        redeemPasscode,
        revokePasscode,
        updateRelationPermissions,
        revokeRelation,
        triggerEmergencySos,
        triggerScheduledEmailCheck,
        adherencePercentage,
        adherenceStreak,
        stats: {
          totalScheduled,
          takenCount,
          pendingCount,
          missedCount,
        },
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
