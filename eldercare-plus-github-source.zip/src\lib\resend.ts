// Automated Email Service Integration (Resend API + Built-in Virtual Mailbox Sandbox)
// Provides dual-mode operation:
// 1. Live Resend API delivery (when user provides a Resend API key)
// 2. Built-in Virtual Mailbox Sandbox (enables full testing, HTML rendering, and evaluation without external API keys)

export interface SendEmailPayload {
  to: string;
  recipientName?: string;
  subject: string;
  type: 'upcoming_dose' | 'missed_medication' | 'doctor_appointment' | 'emergency_sos' | 'access_granted';
  patientName: string;
  details: {
    medicineName?: string;
    dosage?: string;
    time?: string;
    foodInstruction?: string;
    doctorName?: string;
    hospitalName?: string;
    appointmentDate?: string;
    appointmentTime?: string;
    emergencyMessage?: string;
    allergies?: string[];
    bloodGroup?: string;
    emergencyPhone?: string;
    passcode?: string;
  };
}

export interface VirtualEmail {
  id: string;
  to: string;
  recipientName: string;
  from: string;
  subject: string;
  type: string;
  htmlContent: string;
  previewText: string;
  sentAt: string;
  deliveryStatus: 'delivered' | 'sent' | 'failed';
  isRead: boolean;
}

export interface EmailSendResult {
  success: boolean;
  status: 'sent' | 'delivered' | 'failed';
  messageId?: string;
  error?: string;
  isSandbox?: boolean;
}

// Storage helpers
export const getStoredResendKey = (): string => {
  return localStorage.getItem('eldercare_resend_api_key') || import.meta.env.VITE_RESEND_API_KEY || '';
};

export const setStoredResendKey = (key: string) => {
  if (key) {
    localStorage.setItem('eldercare_resend_api_key', key.trim());
  } else {
    localStorage.removeItem('eldercare_resend_api_key');
  }
};

export const isSandboxMailMode = (): boolean => {
  const stored = localStorage.getItem('eldercare_mail_mode');
  // Default to sandbox mode if no live key is set, so testing works immediately!
  if (!stored) {
    return !getStoredResendKey();
  }
  return stored === 'sandbox';
};

export const setMailMode = (mode: 'sandbox' | 'live') => {
  localStorage.setItem('eldercare_mail_mode', mode);
};

// Virtual Mailbox Store
const VIRTUAL_MAILBOX_KEY = 'eldercare_virtual_mailbox';

export const getVirtualEmails = (): VirtualEmail[] => {
  try {
    const raw = localStorage.getItem(VIRTUAL_MAILBOX_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error(e);
  }
  return [];
};

export const saveVirtualEmail = (email: VirtualEmail) => {
  const current = getVirtualEmails();
  const updated = [email, ...current];
  localStorage.setItem(VIRTUAL_MAILBOX_KEY, JSON.stringify(updated));
  // Dispatch custom window event so any open modal/inbox updates immediately
  window.dispatchEvent(new CustomEvent('eldercare_new_email', { detail: email }));
};

export const clearVirtualMailbox = () => {
  localStorage.removeItem(VIRTUAL_MAILBOX_KEY);
  window.dispatchEvent(new CustomEvent('eldercare_mailbox_cleared'));
};

export const markEmailAsRead = (id: string) => {
  const current = getVirtualEmails();
  const updated = current.map(e => e.id === id ? { ...e, isRead: true } : e);
  localStorage.setItem(VIRTUAL_MAILBOX_KEY, JSON.stringify(updated));
};

export const generateHtmlTemplate = (payload: SendEmailPayload): string => {
  const { type, patientName, details } = payload;
  const year = new Date().getFullYear();

  let headerColor = '#15803d'; // Green
  let badgeTitle = 'ElderCare+ Notification';
  let mainContent = '';

  if (type === 'upcoming_dose') {
    headerColor = '#0284c7';
    badgeTitle = 'Upcoming Medication Reminder';
    mainContent = `
      <div style="background-color: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 12px; padding: 20px; margin: 20px 0;">
        <h2 style="margin-top: 0; color: #166534; font-size: 20px;">Time to take medicine for ${patientName}</h2>
        <table style="width: 100%; border-collapse: collapse; margin-top: 12px;">
          <tr>
            <td style="padding: 8px 0; color: #64748b; font-weight: 600; width: 140px;">Medicine:</td>
            <td style="padding: 8px 0; color: #0f172a; font-size: 18px; font-weight: bold;">${details.medicineName || 'Prescribed Medicine'}</td>
          </tr>
          <tr>
            <td style="padding: 8px 0; color: #64748b; font-weight: 600;">Dosage:</td>
            <td style="padding: 8px 0; color: #0f172a;">${details.dosage || 'As prescribed'}</td>
          </tr>
          <tr>
            <td style="padding: 8px 0; color: #64748b; font-weight: 600;">Scheduled Time:</td>
            <td style="padding: 8px 0; color: #0f172a; font-weight: 600;">${details.time || 'Scheduled now'}</td>
          </tr>
          <tr>
            <td style="padding: 8px 0; color: #64748b; font-weight: 600;">Instructions:</td>
            <td style="padding: 8px 0; color: #0f172a;">${details.foodInstruction || 'Take with water'}</td>
          </tr>
        </table>
      </div>
      <p style="color: #475569; font-size: 15px;">Please log in to ElderCare+ to confirm taking this dose and maintain your streak!</p>
    `;
  } else if (type === 'missed_medication') {
    headerColor = '#dc2626'; // Alert Red
    badgeTitle = 'URGENT: Missed Medication Alert';
    mainContent = `
      <div style="background-color: #fef2f2; border: 2px solid #fecaca; border-radius: 12px; padding: 20px; margin: 20px 0;">
        <h2 style="margin-top: 0; color: #991b1b; font-size: 20px;">Dose Missed by ${patientName}</h2>
        <p style="color: #7f1d1d; font-size: 15px; line-height: 1.5;">
          This is an automated alert for family and caregivers. The following prescribed dose was not confirmed within the scheduled window:
        </p>
        <table style="width: 100%; border-collapse: collapse; margin-top: 12px;">
          <tr>
            <td style="padding: 8px 0; color: #991b1b; font-weight: 600; width: 140px;">Medicine:</td>
            <td style="padding: 8px 0; color: #450a0a; font-size: 18px; font-weight: bold;">${details.medicineName}</td>
          </tr>
          <tr>
            <td style="padding: 8px 0; color: #991b1b; font-weight: 600;">Dosage:</td>
            <td style="padding: 8px 0; color: #450a0a;">${details.dosage}</td>
          </tr>
          <tr>
            <td style="padding: 8px 0; color: #991b1b; font-weight: 600;">Scheduled For:</td>
            <td style="padding: 8px 0; color: #450a0a; font-weight: bold;">${details.time}</td>
          </tr>
        </table>
      </div>
      <p style="color: #475569; font-size: 15px;">Please check in with ${patientName} to verify their well-being.</p>
    `;
  } else if (type === 'doctor_appointment') {
    headerColor = '#0284c7'; // Blue
    badgeTitle = 'Doctor Appointment Reminder';
    mainContent = `
      <div style="background-color: #f0f9ff; border: 1px solid #bae6fd; border-radius: 12px; padding: 20px; margin: 20px 0;">
        <h2 style="margin-top: 0; color: #0369a1; font-size: 20px;">Upcoming Medical Consultation</h2>
        <table style="width: 100%; border-collapse: collapse; margin-top: 12px;">
          <tr>
            <td style="padding: 8px 0; color: #64748b; font-weight: 600; width: 140px;">Doctor:</td>
            <td style="padding: 8px 0; color: #0f172a; font-size: 17px; font-weight: bold;">${details.doctorName}</td>
          </tr>
          <tr>
            <td style="padding: 8px 0; color: #64748b; font-weight: 600;">Hospital/Clinic:</td>
            <td style="padding: 8px 0; color: #0f172a;">${details.hospitalName}</td>
          </tr>
          <tr>
            <td style="padding: 8px 0; color: #64748b; font-weight: 600;">Date & Time:</td>
            <td style="padding: 8px 0; color: #0f172a; font-weight: bold;">${details.appointmentDate} at ${details.appointmentTime}</td>
          </tr>
        </table>
      </div>
      <p style="color: #475569; font-size: 15px;">Remember to bring prior medical records, allergy information, and current prescription bottles.</p>
    `;
  } else if (type === 'emergency_sos') {
    headerColor = '#b91c1c'; // Strong Crimson
    badgeTitle = 'EMERGENCY SOS ALERT — IMMEDIATE ATTENTION';
    mainContent = `
      <div style="background-color: #fee2e2; border: 3px solid #ef4444; border-radius: 12px; padding: 22px; margin: 20px 0;">
        <h1 style="margin-top: 0; color: #991b1b; font-size: 22px; text-transform: uppercase;">⚠️ SOS Emergency Triggered by ${patientName}</h1>
        <p style="color: #7f1d1d; font-size: 16px; font-weight: 600;">
          An emergency assistance signal was activated on ElderCare+. Please reach out or dispatch emergency services immediately.
        </p>
        <div style="background: white; border-radius: 8px; padding: 14px; margin-top: 14px;">
          <p style="margin: 4px 0; color: #0f172a;"><strong>Emergency Contact Phone:</strong> ${details.emergencyPhone || 'Check app profile'}</p>
          <p style="margin: 4px 0; color: #0f172a;"><strong>Blood Group:</strong> ${details.bloodGroup || 'Not specified'}</p>
          <p style="margin: 4px 0; color: #0f172a;"><strong>Known Allergies:</strong> ${details.allergies?.join(', ') || 'None listed'}</p>
          <p style="margin: 4px 0; color: #0f172a;"><strong>Patient Notes:</strong> ${details.emergencyMessage || 'Immediate assistance requested via SOS button.'}</p>
        </div>
      </div>
    `;
  } else if (type === 'access_granted') {
    headerColor = '#15803d';
    badgeTitle = 'Profile Access Approved';
    mainContent = `
      <div style="background-color: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 12px; padding: 20px; margin: 20px 0;">
        <h2 style="margin-top: 0; color: #166534; font-size: 20px;">Access Connected with ${patientName}</h2>
        <p style="color: #14532d; font-size: 15px;">
          You have successfully connected to ${patientName}'s healthcare profile on ElderCare+ using their secure family access passcode.
        </p>
        <p style="color: #475569; font-size: 14px;">
          You can now monitor medication schedules, check adherence logs, and coordinate medical appointments.
        </p>
      </div>
    `;
  }

  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>${payload.subject}</title>
    </head>
    <body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #f8fafc; margin: 0; padding: 24px; color: #1e293b;">
      <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width: 600px; background-color: #ffffff; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1); border: 1px solid #e2e8f0;">
        <!-- Header -->
        <tr>
          <td style="background-color: ${headerColor}; padding: 24px 32px; text-align: left;">
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td>
                  <span style="display: inline-block; background-color: rgba(255,255,255,0.2); color: #ffffff; font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; padding: 4px 10px; border-radius: 20px; margin-bottom: 8px;">
                    ${badgeTitle}
                  </span>
                  <h1 style="color: #ffffff; margin: 4px 0 0 0; font-size: 24px; font-weight: 800;">ElderCare+</h1>
                  <p style="color: rgba(255,255,255,0.85); margin: 4px 0 0 0; font-size: 13px;">Healthcare Without Communication or Accessibility Barriers</p>
                </td>
              </tr>
            </table>
          </td>
        </tr>

        <!-- Body -->
        <tr>
          <td style="padding: 32px;">
            ${payload.recipientName ? `<p style="font-size: 16px; color: #334155; margin-top: 0;">Hello <strong>${payload.recipientName}</strong>,</p>` : ''}
            ${mainContent}
            
            <div style="margin-top: 32px; padding-top: 20px; border-top: 1px solid #e2e8f0; font-size: 13px; color: #94a3b8; text-align: center;">
              <p style="margin: 0 0 8px 0;">ElderCare+ Platform • Built for accessibility, dignity, and family connection.</p>
              <p style="margin: 0;">© ${year} ElderCare+. All healthcare rights reserved.</p>
            </div>
          </td>
        </tr>
      </table>
    </body>
    </html>
  `;
};

/**
 * Dispatches an automated email notification.
 * If user has enabled Virtual Mailbox Sandbox (or has no live Resend key),
 * the email is rendered in full HTML and safely delivered to the in-app Virtual Mailbox.
 * If a live Resend key is provided, it attempts real API delivery.
 */
export async function sendEmailNotification(payload: SendEmailPayload): Promise<EmailSendResult> {
  const isSandbox = isSandboxMailMode();
  const apiKey = getStoredResendKey();
  const htmlContent = generateHtmlTemplate(payload);

  // If in sandbox mode or no live key configured, deliver to Virtual Mailbox Sandbox
  if (isSandbox || !apiKey) {
    const virtualEmail: VirtualEmail = {
      id: `mail-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      to: payload.to,
      recipientName: payload.recipientName || 'ElderCare+ User',
      from: 'ElderCare+ <reminders@eldercare.plus>',
      subject: payload.subject,
      type: payload.type,
      htmlContent,
      previewText: payload.details.medicineName 
        ? `${payload.details.medicineName} (${payload.details.time || ''}) - ${payload.details.foodInstruction || ''}`
        : payload.details.doctorName 
        ? `Appointment with ${payload.details.doctorName} on ${payload.details.appointmentDate}`
        : 'Important ElderCare+ notification.',
      sentAt: new Date().toISOString(),
      deliveryStatus: 'delivered',
      isRead: false,
    };

    saveVirtualEmail(virtualEmail);

    return {
      success: true,
      status: 'delivered',
      messageId: virtualEmail.id,
      isSandbox: true,
    };
  }

  // Live Resend API delivery
  try {
    // Try sending through Vite server proxy / backend if available, or direct Resend endpoint
    const response = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        from: 'ElderCare+ <onboarding@resend.dev>',
        to: [payload.to],
        subject: payload.subject,
        html: htmlContent,
      }),
    });

    const data = await response.json();

    if (!response.ok) {
      const errorDetail = data?.message || data?.error || `HTTP ${response.status}`;
      return {
        success: false,
        status: 'failed',
        error: `Resend error: ${errorDetail}`,
      };
    }

    return {
      success: true,
      status: 'delivered',
      messageId: data.id,
      isSandbox: false,
    };
  } catch (err: any) {
    return {
      success: false,
      status: 'failed',
      error: `Network error delivering email: ${err?.message || 'Connection failed'}`,
    };
  }
}
