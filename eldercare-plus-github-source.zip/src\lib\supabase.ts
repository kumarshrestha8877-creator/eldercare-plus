// ElderCare+ Database & Data Store Layer
// Dual-Mode Architecture: Supabase Cloud Client + Resilient Local State Store

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { 
  UserProfile, 
  HealthcareProfile, 
  Medicine, 
  MedicationScheduleItem, 
  MedicationAdherenceLog, 
  DoctorAppointment, 
  EmergencyContact, 
  AccessPasscode, 
  FamilyCaregiverRelation, 
  NotificationLog, 
  AuditLog 
} from '../types';

export const getSupabaseConfig = () => {
  const url = localStorage.getItem('eldercare_supabase_url') || import.meta.env.VITE_SUPABASE_URL || '';
  const key = localStorage.getItem('eldercare_supabase_key') || import.meta.env.VITE_SUPABASE_ANON_KEY || '';
  return { url, key, isConfigured: Boolean(url && key) };
};

export const setSupabaseConfig = (url: string, key: string) => {
  if (url && key) {
    localStorage.setItem('eldercare_supabase_url', url.trim());
    localStorage.setItem('eldercare_supabase_key', key.trim());
  } else {
    localStorage.removeItem('eldercare_supabase_url');
    localStorage.removeItem('eldercare_supabase_key');
  }
};

let supabaseInstance: SupabaseClient | null = null;

export const getSupabaseClient = (): SupabaseClient | null => {
  const { url, key, isConfigured } = getSupabaseConfig();
  if (!isConfigured) return null;
  if (!supabaseInstance) {
    try {
      supabaseInstance = createClient(url, key);
    } catch (e) {
      console.error('Failed to create Supabase client', e);
      return null;
    }
  }
  return supabaseInstance;
};

// ==============================================================================
// INITIAL REALISTIC DEMONSTRATION DATA (PERSISTENT VIA LOCALSTORAGE)
// ==============================================================================

const INITIAL_ELDERLY_USER: UserProfile = {
  id: 'usr-elderly-01',
  email: 'eleanor.vance@eldercare.plus',
  fullName: 'Eleanor Vance',
  phone: '+1 (555) 234-5678',
  role: 'elderly',
  avatarUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=256',
  languagePreference: 'en',
  createdAt: '2026-01-10T08:00:00Z',
};

const INITIAL_FAMILY_USER: UserProfile = {
  id: 'usr-family-01',
  email: 'priya.vance@familycare.org',
  fullName: 'Priya Vance',
  phone: '+1 (555) 987-6543',
  role: 'family',
  avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=256',
  languagePreference: 'en',
  createdAt: '2026-01-12T09:30:00Z',
};

const INITIAL_CAREGIVER_USER: UserProfile = {
  id: 'usr-caregiver-01',
  email: 'sarah.nurse@elderhealth.net',
  fullName: 'Nurse Sarah Jenkins, RN',
  phone: '+1 (555) 456-7890',
  role: 'caregiver',
  avatarUrl: 'https://images.unsplash.com/photo-1594824813589-399081e792e8?auto=format&fit=crop&q=80&w=256',
  languagePreference: 'en',
  createdAt: '2026-01-15T11:00:00Z',
};

export interface UserSession {
  userId: string;
  role: 'elderly' | 'family' | 'caregiver';
  email: string;
  fullName: string;
  token: string;
  loginTime: string;
}

export const INITIAL_REGISTERED_USERS: (UserProfile & { password?: string })[] = [
  {
    ...INITIAL_ELDERLY_USER,
    password: 'Pass1234!',
  },
  {
    ...INITIAL_FAMILY_USER,
    password: 'Pass1234!',
  },
  {
    ...INITIAL_CAREGIVER_USER,
    password: 'Pass1234!',
  },
];

const INITIAL_HEALTHCARE_PROFILE: HealthcareProfile = {
  id: 'hp-01',
  elderlyUserId: 'usr-elderly-01',
  dateOfBirth: '1952-04-18',
  bloodGroup: 'O Positive (O+)',
  medicalHistory: [
    'Type 2 Diabetes Mellitus (Diagnosed 2018)',
    'Essential Hypertension (Diagnosed 2015)',
    'Mild Osteoarthritis in knees',
    'Cataract Surgery (Both eyes, 2024)',
  ],
  knownAllergies: [
    'Penicillin (Severe - Causes anaphylaxis/rash)',
    'Sulfa Antibiotics (Moderate - hives)',
    'Peanuts (Mild allergy)',
  ],
  chronicConditions: [
    'Hypertension',
    'Diabetes (HbA1c: 6.8%)',
    'Osteoarthritis',
  ],
  primaryPhysicianName: 'Dr. Rajesh Sharma, MD',
  primaryPhysicianPhone: '+1 (555) 345-8901',
  hospitalPreference: 'St. Jude Memorial Hospital / Fortis Healthcare',
  insuranceDetails: 'Medicare Advantage Plus #MED-84920119-A',
  emergencyNotes: 'Keep inhaler accessible. Prefers morning medication with warm oatmeal. Allergic to Penicillin.',
  updatedAt: new Date().toISOString(),
};

const INITIAL_EMERGENCY_CONTACTS: EmergencyContact[] = [
  {
    id: 'em-01',
    elderlyUserId: 'usr-elderly-01',
    contactName: 'Priya Vance',
    relationship: 'Daughter (Primary)',
    phone: '+1 (555) 987-6543',
    email: 'priya.vance@familycare.org',
    isPrimary: true,
    canReceiveSosEmail: true,
  },
  {
    id: 'em-02',
    elderlyUserId: 'usr-elderly-01',
    contactName: 'Nurse Sarah Jenkins',
    relationship: 'Primary Home Care Nurse',
    phone: '+1 (555) 456-7890',
    email: 'sarah.nurse@elderhealth.net',
    isPrimary: false,
    canReceiveSosEmail: true,
  },
  {
    id: 'em-03',
    elderlyUserId: 'usr-elderly-01',
    contactName: 'Emergency Medical Dispatch (EMS)',
    relationship: 'Local Emergency Hotline',
    phone: '911',
    email: 'dispatch@local-ems.gov',
    isPrimary: false,
    canReceiveSosEmail: false,
  },
];

export const INITIAL_MEDICINES: Medicine[] = [
  {
    id: 'med-01',
    elderlyUserId: 'usr-elderly-01',
    name: 'Metformin Hydrochloride',
    dosage: '500 mg',
    form: 'Tablet',
    colorCode: '#10B981', // Green
    frequency: 'Twice Daily',
    scheduleTimes: ['08:00 AM', '08:00 PM'],
    foodInstruction: 'With Food',
    startDate: '2026-01-01',
    prescribedBy: 'Dr. Rajesh Sharma (Endocrinology)',
    instructions: 'Take during or immediately after meals to avoid gastrointestinal upset.',
    isActive: true,
    createdAt: '2026-01-01T08:00:00Z',
  },
  {
    id: 'med-02',
    elderlyUserId: 'usr-elderly-01',
    name: 'Lisinopril',
    dosage: '10 mg',
    form: 'Tablet',
    colorCode: '#3B82F6', // Blue
    frequency: 'Once Daily',
    scheduleTimes: ['08:00 AM'],
    foodInstruction: 'After Food',
    startDate: '2026-01-01',
    prescribedBy: 'Dr. Rajesh Sharma (Cardiology)',
    instructions: 'Controls high blood pressure. Take with a glass of water.',
    isActive: true,
    createdAt: '2026-01-01T08:00:00Z',
  },
  {
    id: 'med-03',
    elderlyUserId: 'usr-elderly-01',
    name: 'Atorvastatin Calcium',
    dosage: '20 mg',
    form: 'Tablet',
    colorCode: '#8B5CF6', // Purple
    frequency: 'Once Daily',
    scheduleTimes: ['09:30 PM'],
    foodInstruction: 'Anytime',
    startDate: '2026-01-01',
    prescribedBy: 'Dr. Rajesh Sharma (Cardiology)',
    instructions: 'Lowers cholesterol. Take at bedtime with water.',
    isActive: true,
    createdAt: '2026-01-01T08:00:00Z',
  },
  {
    id: 'med-04',
    elderlyUserId: 'usr-elderly-01',
    name: 'Vitamin D3 & Calcium',
    dosage: '1000 IU / 500 mg',
    form: 'Capsule',
    colorCode: '#F59E0B', // Amber
    frequency: 'Once Daily',
    scheduleTimes: ['01:00 PM'],
    foodInstruction: 'After Food',
    startDate: '2026-01-01',
    prescribedBy: 'Dr. Sarah Jenkins',
    instructions: 'Supports bone density and joint mobility.',
    isActive: true,
    createdAt: '2026-01-01T08:00:00Z',
  },
  {
    id: 'med-05',
    elderlyUserId: 'usr-elderly-01',
    name: 'Carboxymethylcellulose Eye Drops',
    dosage: '2 drops',
    form: 'Drops',
    colorCode: '#06B6D4', // Cyan
    frequency: 'Twice Daily',
    scheduleTimes: ['09:00 AM', '07:00 PM'],
    foodInstruction: 'Anytime',
    startDate: '2026-01-05',
    prescribedBy: 'Dr. Maya Patel (Ophthalmology)',
    instructions: 'Dry eye relief. Instill 1-2 drops in each eye.',
    isActive: true,
    createdAt: '2026-01-05T08:00:00Z',
  }
];

export const INITIAL_SCHEDULES: MedicationScheduleItem[] = [
  {
    id: 'sch-01',
    medicineId: 'med-01',
    medicineName: 'Metformin Hydrochloride',
    dosage: '500 mg',
    form: 'Tablet',
    colorCode: '#10B981',
    foodInstruction: 'With Breakfast',
    scheduledTime: '08:00 AM',
    status: 'taken',
    takenAt: '08:15 AM',
    instructions: 'Take during or immediately after meals.',
  },
  {
    id: 'sch-02',
    medicineId: 'med-02',
    medicineName: 'Lisinopril',
    dosage: '10 mg',
    form: 'Tablet',
    colorCode: '#3B82F6',
    foodInstruction: 'After Breakfast',
    scheduledTime: '08:00 AM',
    status: 'taken',
    takenAt: '08:16 AM',
    instructions: 'Take with a glass of water.',
  },
  {
    id: 'sch-03',
    medicineId: 'med-05',
    medicineName: 'Carboxymethylcellulose Eye Drops',
    dosage: '2 drops',
    form: 'Drops',
    colorCode: '#06B6D4',
    foodInstruction: 'Morning Routine',
    scheduledTime: '09:00 AM',
    status: 'taken',
    takenAt: '09:05 AM',
    instructions: '1-2 drops in each eye.',
  },
  {
    id: 'sch-04',
    medicineId: 'med-04',
    medicineName: 'Vitamin D3 & Calcium',
    dosage: '1000 IU / 500 mg',
    form: 'Capsule',
    colorCode: '#F59E0B',
    foodInstruction: 'After Lunch',
    scheduledTime: '01:00 PM',
    status: 'pending',
    instructions: 'Take after your afternoon lunch.',
  },
  {
    id: 'sch-05',
    medicineId: 'med-05',
    medicineName: 'Carboxymethylcellulose Eye Drops',
    dosage: '2 drops',
    form: 'Drops',
    colorCode: '#06B6D4',
    foodInstruction: 'Evening Routine',
    scheduledTime: '07:00 PM',
    status: 'pending',
    instructions: '1-2 drops in each eye before evening dinner.',
  },
  {
    id: 'sch-06',
    medicineId: 'med-01',
    medicineName: 'Metformin Hydrochloride',
    dosage: '500 mg',
    form: 'Tablet',
    colorCode: '#10B981',
    foodInstruction: 'With Dinner',
    scheduledTime: '08:00 PM',
    status: 'pending',
    instructions: 'Take during or immediately after dinner.',
  },
  {
    id: 'sch-07',
    medicineId: 'med-03',
    medicineName: 'Atorvastatin Calcium',
    dosage: '20 mg',
    form: 'Tablet',
    colorCode: '#8B5CF6',
    foodInstruction: 'Bedtime',
    scheduledTime: '09:30 PM',
    status: 'pending',
    instructions: 'Take at bedtime with water.',
  },
];

const INITIAL_APPOINTMENTS: DoctorAppointment[] = [
  {
    id: 'apt-01',
    elderlyUserId: 'usr-elderly-01',
    doctorName: 'Dr. Rajesh Sharma, MD',
    specialty: 'Cardiologist & General Medicine',
    hospitalName: 'St. Jude Memorial Hospital - Suite 402',
    hospitalAddress: '742 Evergreen Terrace, Medical District',
    appointmentDate: new Date(Date.now() + 86400000 * 3).toISOString().split('T')[0], // 3 days from now
    appointmentTime: '10:30 AM',
    notes: 'Quarterly blood pressure review and HbA1c blood test evaluation. Bring past 30 days blood sugar logs.',
    status: 'upcoming',
    reminderSent: false,
    createdBy: 'Priya Vance',
    createdAt: '2026-02-01T10:00:00Z',
  },
  {
    id: 'apt-02',
    elderlyUserId: 'usr-elderly-01',
    doctorName: 'Dr. Maya Patel, MD',
    specialty: 'Ophthalmologist',
    hospitalName: 'City Vision & Eye Care Institute',
    hospitalAddress: '120 Park Avenue, 2nd Floor',
    appointmentDate: new Date(Date.now() + 86400000 * 12).toISOString().split('T')[0], // 12 days from now
    appointmentTime: '02:00 PM',
    notes: 'Post-cataract surgery annual vision screening & intraocular pressure check.',
    status: 'upcoming',
    reminderSent: false,
    createdBy: 'Eleanor Vance',
    createdAt: '2026-02-05T14:30:00Z',
  },
  {
    id: 'apt-03',
    elderlyUserId: 'usr-elderly-01',
    doctorName: 'Dr. Kenneth Cole, DDS',
    specialty: 'Dental Surgeon',
    hospitalName: 'Gentle Smiles Dental Clinic',
    hospitalAddress: '55 Pine Ridge Blvd',
    appointmentDate: new Date(Date.now() - 86400000 * 14).toISOString().split('T')[0], // 14 days ago
    appointmentTime: '11:00 AM',
    notes: 'Routine dental prophylaxis and denture fitting inspection. Completed with no issues.',
    status: 'completed',
    reminderSent: true,
    createdBy: 'Eleanor Vance',
    createdAt: '2026-01-15T09:00:00Z',
  }
];

const INITIAL_PASSCODES: AccessPasscode[] = [
  {
    id: 'code-01',
    elderlyUserId: 'usr-elderly-01',
    passcode: 'FAMILY-8492',
    targetRole: 'family',
    label: 'Daughter Priya Access',
    canManageMedications: true,
    canManageAppointments: true,
    canViewMedicalHistory: true,
    expiresAt: new Date(Date.now() + 86400000 * 30).toISOString(),
    isRevoked: false,
    maxUses: 5,
    usedCount: 1,
    createdAt: '2026-01-12T08:00:00Z',
  },
  {
    id: 'code-02',
    elderlyUserId: 'usr-elderly-01',
    passcode: 'CARE-5120',
    targetRole: 'caregiver',
    label: 'Visiting Nurse Jenkins Access',
    canManageMedications: true,
    canManageAppointments: true,
    canViewMedicalHistory: true,
    expiresAt: new Date(Date.now() + 86400000 * 30).toISOString(),
    isRevoked: false,
    maxUses: 3,
    usedCount: 1,
    createdAt: '2026-01-15T08:00:00Z',
  }
];

const INITIAL_RELATIONS: FamilyCaregiverRelation[] = [
  {
    id: 'rel-01',
    elderlyUserId: 'usr-elderly-01',
    elderlyName: 'Eleanor Vance',
    memberUserId: 'usr-family-01',
    memberName: 'Priya Vance',
    memberEmail: 'priya.vance@familycare.org',
    memberRole: 'family',
    relationshipLabel: 'Daughter & Primary Family Caregiver',
    status: 'active',
    canManageMedications: true,
    canManageAppointments: true,
    canViewMedicalHistory: true,
    notifyOnMissedDose: true,
    notifyOnSos: true,
    joinedAt: '2026-01-12T09:35:00Z',
  },
  {
    id: 'rel-02',
    elderlyUserId: 'usr-elderly-01',
    elderlyName: 'Eleanor Vance',
    memberUserId: 'usr-caregiver-01',
    memberName: 'Nurse Sarah Jenkins, RN',
    memberEmail: 'sarah.nurse@elderhealth.net',
    memberRole: 'caregiver',
    relationshipLabel: 'Registered Visiting Nurse',
    status: 'active',
    canManageMedications: true,
    canManageAppointments: true,
    canViewMedicalHistory: true,
    notifyOnMissedDose: true,
    notifyOnSos: true,
    joinedAt: '2026-01-15T11:05:00Z',
  }
];

const INITIAL_NOTIFICATIONS: NotificationLog[] = [
  {
    id: 'notif-01',
    elderlyUserId: 'usr-elderly-01',
    recipientEmail: 'priya.vance@familycare.org',
    recipientName: 'Priya Vance',
    type: 'upcoming_dose',
    subject: 'ElderCare+ Morning Medication Reminder for Eleanor Vance',
    bodyPreview: 'Time for Eleanor Vance to take Metformin 500mg and Lisinopril 10mg with breakfast.',
    status: 'delivered',
    sentAt: new Date(Date.now() - 3600000 * 3).toISOString(),
  },
  {
    id: 'notif-02',
    elderlyUserId: 'usr-elderly-01',
    recipientEmail: 'sarah.nurse@elderhealth.net',
    recipientName: 'Nurse Sarah Jenkins',
    type: 'doctor_appointment',
    subject: 'Appointment Reminder: Dr. Rajesh Sharma on ' + new Date(Date.now() + 86400000 * 3).toLocaleDateString(),
    bodyPreview: 'Cardiology checkup scheduled at St. Jude Memorial Hospital Suite 402 at 10:30 AM.',
    status: 'delivered',
    sentAt: new Date(Date.now() - 86400000).toISOString(),
  },
  {
    id: 'notif-03',
    elderlyUserId: 'usr-elderly-01',
    recipientEmail: 'priya.vance@familycare.org',
    recipientName: 'Priya Vance',
    type: 'access_granted',
    subject: 'Passcode Verified: Access granted to Eleanor Vance healthcare profile',
    bodyPreview: 'You have been granted full medication & appointment management privileges.',
    status: 'delivered',
    sentAt: '2026-01-12T09:35:00Z',
  }
];

const INITIAL_AUDIT_LOGS: AuditLog[] = [
  {
    id: 'aud-01',
    elderlyUserId: 'usr-elderly-01',
    actorName: 'Eleanor Vance',
    actorRole: 'elderly',
    action: 'CONFIRMED_DOSE',
    details: 'Marked Metformin 500mg as Taken at 08:15 AM',
    timestamp: new Date(Date.now() - 3600000 * 2.5).toISOString(),
  },
  {
    id: 'aud-02',
    elderlyUserId: 'usr-elderly-01',
    actorName: 'Eleanor Vance',
    actorRole: 'elderly',
    action: 'CONFIRMED_DOSE',
    details: 'Marked Lisinopril 10mg as Taken at 08:16 AM',
    timestamp: new Date(Date.now() - 3600000 * 2.5).toISOString(),
  },
  {
    id: 'aud-03',
    elderlyUserId: 'usr-elderly-01',
    actorName: 'Priya Vance',
    actorRole: 'family',
    action: 'APPOINTMENT_SCHEDULED',
    details: 'Added appointment with Dr. Rajesh Sharma for 3 days from now',
    timestamp: '2026-02-01T10:00:00Z',
  },
  {
    id: 'aud-04',
    elderlyUserId: 'usr-elderly-01',
    actorName: 'Eleanor Vance',
    actorRole: 'elderly',
    action: 'PASSCODE_GENERATED',
    details: 'Generated passcode CARE-5120 for Nurse Sarah Jenkins',
    timestamp: '2026-01-15T08:00:00Z',
  }
];

// Helper to get or set local storage
function getStorage<T>(key: string, defaultVal: T): T {
  try {
    const raw = localStorage.getItem(`eldercare_${key}`);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (typeof defaultVal === 'object' && defaultVal !== null && !Array.isArray(defaultVal)) {
        const merged = { ...defaultVal, ...parsed } as any;
        if (!merged.fullName && merged.name) merged.fullName = merged.name;
        return merged;
      }
      return parsed;
    }
  } catch (e) {
    console.error(`Error reading ${key} from storage`, e);
  }
  return defaultVal;
}

function setStorage<T>(key: string, val: T): void {
  try {
    localStorage.setItem(`eldercare_${key}`, JSON.stringify(val));
  } catch (e) {
    console.error(`Error writing ${key} to storage`, e);
  }
}

// ==============================================================================
// LOCAL REPOSITORY (Single Source of Truth with Supabase sync capability)
// ==============================================================================

export const localStore = {
  getElderlyUser: (): UserProfile => getStorage('elderly_user', INITIAL_ELDERLY_USER),
  getFamilyUser: (): UserProfile => getStorage('family_user', INITIAL_FAMILY_USER),
  getCaregiverUser: (): UserProfile => getStorage('caregiver_user', INITIAL_CAREGIVER_USER),

  getHealthcareProfile: (): HealthcareProfile => getStorage('health_profile', INITIAL_HEALTHCARE_PROFILE),
  updateHealthcareProfile: (profile: HealthcareProfile): void => {
    setStorage('health_profile', profile);
  },

  getEmergencyContacts: (): EmergencyContact[] => getStorage('emergency_contacts', INITIAL_EMERGENCY_CONTACTS),
  saveEmergencyContacts: (contacts: EmergencyContact[]): void => {
    setStorage('emergency_contacts', contacts);
  },

  getMedicines: (): Medicine[] => getStorage('medicines', INITIAL_MEDICINES),
  saveMedicines: (meds: Medicine[]): void => {
    setStorage('medicines', meds);
  },

  getSchedules: (): MedicationScheduleItem[] => getStorage('schedules', INITIAL_SCHEDULES),
  saveSchedules: (schedules: MedicationScheduleItem[]): void => {
    setStorage('schedules', schedules);
  },

  getAppointments: (): DoctorAppointment[] => getStorage('appointments', INITIAL_APPOINTMENTS),
  saveAppointments: (apts: DoctorAppointment[]): void => {
    setStorage('appointments', apts);
  },

  getPasscodes: (): AccessPasscode[] => getStorage('passcodes', INITIAL_PASSCODES),
  savePasscodes: (codes: AccessPasscode[]): void => {
    setStorage('passcodes', codes);
  },

  getRelations: (): FamilyCaregiverRelation[] => getStorage('relations', INITIAL_RELATIONS),
  saveRelations: (relations: FamilyCaregiverRelation[]): void => {
    setStorage('relations', relations);
  },

  getNotifications: (): NotificationLog[] => getStorage('notifications', INITIAL_NOTIFICATIONS),
  addNotification: (log: NotificationLog): void => {
    const list = getStorage('notifications', INITIAL_NOTIFICATIONS);
    setStorage('notifications', [log, ...list]);
  },

  getAuditLogs: (): AuditLog[] => getStorage('audit_logs', INITIAL_AUDIT_LOGS),
  addAuditLog: (log: AuditLog): void => {
    const list = getStorage('audit_logs', INITIAL_AUDIT_LOGS);
    setStorage('audit_logs', [log, ...list]);
  },

  // Full Authentication & User Registry
  getRegisteredUsers: (): (UserProfile & { password?: string })[] => {
    return getStorage('registered_users', INITIAL_REGISTERED_USERS);
  },
  saveRegisteredUsers: (users: (UserProfile & { password?: string })[]): void => {
    setStorage('registered_users', users);
  },
  findUserByEmail: (email: string): (UserProfile & { password?: string }) | undefined => {
    const users = localStore.getRegisteredUsers();
    return users.find(u => u.email.toLowerCase().trim() === email.toLowerCase().trim());
  },
  createUserAccount: (newUser: UserProfile & { password?: string }): UserProfile => {
    const users = localStore.getRegisteredUsers();
    const existingIndex = users.findIndex(u => u.email.toLowerCase().trim() === newUser.email.toLowerCase().trim());
    if (existingIndex >= 0) {
      users[existingIndex] = { ...users[existingIndex], ...newUser };
    } else {
      users.push(newUser);
    }
    localStore.saveRegisteredUsers(users);

    // Also update role-specific fallback if needed
    if (newUser.role === 'elderly') {
      setStorage('elderly_user', newUser);
    } else if (newUser.role === 'family') {
      setStorage('family_user', newUser);
    } else if (newUser.role === 'caregiver') {
      setStorage('caregiver_user', newUser);
    }

    return newUser;
  },

  // Active Session Persistence
  getSession: (): UserSession | null => {
    return getStorage<UserSession | null>('session', null);
  },
  saveSession: (session: UserSession): void => {
    setStorage('session', session);
  },
  clearSession: (): void => {
    try {
      localStorage.removeItem('eldercare_session');
    } catch (e) {
      console.error('Failed to clear session', e);
    }
  },

  resetToDefault: (): void => {
    localStorage.removeItem('eldercare_registered_users');
    localStorage.removeItem('eldercare_session');
    localStorage.removeItem('eldercare_elderly_user');
    localStorage.removeItem('eldercare_family_user');
    localStorage.removeItem('eldercare_caregiver_user');
    localStorage.removeItem('eldercare_health_profile');
    localStorage.removeItem('eldercare_emergency_contacts');
    localStorage.removeItem('eldercare_medicines');
    localStorage.removeItem('eldercare_schedules');
    localStorage.removeItem('eldercare_appointments');
    localStorage.removeItem('eldercare_passcodes');
    localStorage.removeItem('eldercare_relations');
    localStorage.removeItem('eldercare_notifications');
    localStorage.removeItem('eldercare_audit_logs');
  }
};

