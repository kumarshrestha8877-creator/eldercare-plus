/**
 * Speech Engine for ElderCare+
 * Provides Web Speech API Text-to-Speech (TTS) and Speech-to-Text (STT)
 */

export function speak(text, lang = 'en') {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    console.warn('Speech synthesis is not supported on this browser.');
    return;
  }

  // Cancel any ongoing speech
  window.speechSynthesis.cancel();

  if (!text) return;

  const utterance = new SpeechSynthesisUtterance(text);
  
  // Set voice language
  const langMap = {
    en: 'en-US',
    hi: 'hi-IN',
    bn: 'bn-IN',
  };
  utterance.lang = langMap[lang] || 'en-US';
  utterance.rate = 0.9; // Slightly slower, clearer rate for elderly users
  utterance.pitch = 1.0;

  // Try to find matching installed voice
  const voices = window.speechSynthesis.getVoices();
  const matchedVoice = voices.find(v => v.lang.startsWith(utterance.lang) || v.lang.startsWith(lang));
  if (matchedVoice) {
    utterance.voice = matchedVoice;
  }

  window.speechSynthesis.speak(utterance);
}

export function stopSpeech() {
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    window.speechSynthesis.cancel();
  }
}

export function isSpeechRecognitionSupported() {
  if (typeof window === 'undefined') return false;
  return Boolean(window.SpeechRecognition || window.webkitSpeechRecognition);
}

export function initSpeechRecognition({ onResult, onError, onEnd, lang = 'en' }) {
  if (!isSpeechRecognitionSupported()) {
    console.warn('Speech recognition is not supported in this browser.');
    return null;
  }

  const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;
  const recognition = new SpeechRec();

  const langMap = {
    en: 'en-US',
    hi: 'hi-IN',
    bn: 'bn-IN',
  };

  recognition.lang = langMap[lang] || 'en-US';
  recognition.continuous = false;
  recognition.interimResults = false;

  recognition.onresult = (event) => {
    const transcript = event.results[0][0].transcript;
    if (onResult) onResult(transcript);
  };

  recognition.onerror = (event) => {
    console.error('Speech recognition error:', event.error);
    if (onError) onError(event.error);
  };

  recognition.onend = () => {
    if (onEnd) onEnd();
  };

  return recognition;
}

/**
 * Intelligent voice command parser for ElderCare+
 */
export function interpretVoiceCommand(transcript) {
  const t = transcript.toLowerCase().trim();

  // Schedule commands
  if (t.includes('schedule') || t.includes('medicine') || t.includes('today') || t.includes('दवा') || t.includes('ওষুধ')) {
    return { action: 'READ_SCHEDULE', text: transcript };
  }

  // Next dose command
  if (t.includes('next') || t.includes('अगली') || t.includes('পরবর্তী')) {
    return { action: 'NEXT_DOSE', text: transcript };
  }

  // Appointment command
  if (t.includes('appointment') || t.includes('doctor') || t.includes('डॉक्टर') || t.includes('অ্যাপয়েন্টমেন্ট')) {
    return { action: 'READ_APPOINTMENTS', text: transcript };
  }

  // Emergency SOS command
  if (t.includes('emergency') || t.includes('sos') || t.includes('help') || t.includes('मदद') || t.includes('সাহায্য') || t.includes('danger')) {
    return { action: 'EMERGENCY_SOS', text: transcript };
  }

  // Call family
  if (t.includes('family') || t.includes('call') || t.includes('फोन') || t.includes('পরিবার')) {
    return { action: 'CALL_FAMILY', text: transcript };
  }

  // Silent mode toggle
  if (t.includes('silent') || t.includes('मौन') || t.includes('নীরব')) {
    return { action: 'TOGGLE_SILENT_MODE', text: transcript };
  }

  return { action: 'UNKNOWN', text: transcript };
}
