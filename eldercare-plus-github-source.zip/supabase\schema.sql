-- ====================================================================
-- ElderCare+ Database Schema for Supabase / PostgreSQL
-- Tagline: Healthcare Without Communication or Accessibility Barriers
-- ====================================================================

-- 1. Enable UUID Extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 2. User Roles Enum
CREATE TYPE user_role AS ENUM ('elderly', 'family', 'caregiver');
CREATE TYPE connection_status AS ENUM ('pending', 'approved', 'rejected', 'revoked');
CREATE TYPE medication_status AS ENUM ('pending', 'taken', 'skipped', 'missed');
CREATE TYPE notification_type AS ENUM ('dose_reminder', 'missed_dose', 'appointment', 'emergency_sos', 'access_request', 'access_granted', 'health_update');
CREATE TYPE email_status AS ENUM ('delivered', 'failed', 'pending_config');

-- 3. Profiles Table (extends Supabase auth.users)
CREATE TABLE profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT UNIQUE NOT NULL,
    full_name TEXT NOT NULL,
    role user_role NOT NULL,
    phone TEXT,
    avatar_url TEXT,
    preferred_language TEXT DEFAULT 'en', -- 'en', 'hi', 'bn'
    accessibility_prefs JSONB DEFAULT '{"fontSize": "normal", "contrast": "default", "voiceAssistance": false, "silentMode": false}'::jsonb,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. Elderly Healthcare Profile
CREATE TABLE healthcare_profiles (
    elderly_id UUID PRIMARY KEY REFERENCES profiles(id) ON DELETE CASCADE,
    date_of_birth DATE,
    blood_group TEXT,
    gender TEXT,
    primary_physician TEXT,
    physician_phone TEXT,
    hospital_affiliation TEXT,
    medical_conditions TEXT[] DEFAULT '{}',
    allergies TEXT[] DEFAULT '{}',
    emergency_instructions TEXT,
    insurance_provider TEXT,
    insurance_policy_number TEXT,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. Family Access Passcodes
CREATE TABLE family_access_passcodes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    elderly_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    passcode TEXT NOT NULL,
    label TEXT DEFAULT 'Family Access Code',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    expires_at TIMESTAMPTZ,
    UNIQUE(elderly_id, passcode)
);

-- 6. Family & Caregiver Connections
CREATE TABLE family_connections (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    elderly_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    member_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    member_role user_role NOT NULL,
    relationship_label TEXT NOT NULL, -- e.g. 'Daughter', 'Son', 'Primary Nurse'
    status connection_status DEFAULT 'pending',
    permissions JSONB DEFAULT '{
        "canViewMeds": true,
        "canEditMeds": false,
        "canViewAppointments": true,
        "canEditAppointments": false,
        "canViewProfile": true,
        "canEditProfile": false,
        "canReceiveAlerts": true
    }'::jsonb,
    requested_at TIMESTAMPTZ DEFAULT NOW(),
    approved_at TIMESTAMPTZ,
    revoked_at TIMESTAMPTZ,
    UNIQUE(elderly_id, member_id)
);

-- 7. Medications
CREATE TABLE medications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    elderly_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    dosage TEXT NOT NULL, -- e.g. "500 mg", "1 tablet"
    form TEXT DEFAULT 'tablet', -- tablet, capsule, liquid, injection, inhaler
    instructions TEXT, -- e.g. "Take after breakfast with plenty of water"
    with_food TEXT DEFAULT 'after', -- 'before', 'after', 'with', 'any'
    frequency TEXT DEFAULT 'daily', -- 'daily', 'twice_daily', 'three_times_daily', 'as_needed'
    times_of_day TEXT[] NOT NULL, -- e.g. ['08:00', '20:00']
    start_date DATE NOT NULL,
    end_date DATE,
    remaining_pills INT DEFAULT 30,
    refill_threshold INT DEFAULT 5,
    is_active BOOLEAN DEFAULT TRUE,
    created_by UUID REFERENCES profiles(id),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 8. Medication Adherence Logs
CREATE TABLE medication_adherence_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    medicine_id UUID NOT NULL REFERENCES medications(id) ON DELETE CASCADE,
    elderly_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    scheduled_date DATE NOT NULL,
    scheduled_time TEXT NOT NULL,
    status medication_status DEFAULT 'pending',
    taken_at TIMESTAMPTZ,
    recorded_by UUID REFERENCES profiles(id),
    recorded_by_name TEXT,
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(medicine_id, scheduled_date, scheduled_time)
);

-- 9. Doctor Appointments
CREATE TABLE doctor_appointments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    elderly_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    doctor_name TEXT NOT NULL,
    specialty TEXT,
    hospital_clinic TEXT NOT NULL,
    appointment_date DATE NOT NULL,
    appointment_time TEXT NOT NULL,
    location_address TEXT,
    notes TEXT,
    status TEXT DEFAULT 'upcoming', -- upcoming, completed, cancelled
    reminder_sent BOOLEAN DEFAULT FALSE,
    created_by UUID REFERENCES profiles(id),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 10. Emergency Contacts
CREATE TABLE emergency_contacts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    elderly_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    relationship TEXT NOT NULL,
    phone TEXT NOT NULL,
    email TEXT,
    is_primary BOOLEAN DEFAULT FALSE,
    notify_on_sos BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 11. Notifications and Email Logs
CREATE TABLE notifications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    elderly_id UUID REFERENCES profiles(id) ON DELETE SET NULL,
    type notification_type NOT NULL,
    title TEXT NOT NULL,
    message TEXT NOT NULL,
    channel TEXT DEFAULT 'both', -- 'in_app', 'email', 'both'
    email_recipient TEXT,
    email_status email_status DEFAULT 'pending_config',
    email_id TEXT,
    error_message TEXT,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 12. Audit Logs
CREATE TABLE audit_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    elderly_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    actor_id UUID REFERENCES profiles(id) ON DELETE SET NULL,
    actor_name TEXT NOT NULL,
    actor_role user_role NOT NULL,
    action TEXT NOT NULL,
    details JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable Row Level Security (RLS) on all tables
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE healthcare_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE family_access_passcodes ENABLE ROW LEVEL SECURITY;
ALTER TABLE family_connections ENABLE ROW LEVEL SECURITY;
ALTER TABLE medications ENABLE ROW LEVEL SECURITY;
ALTER TABLE medication_adherence_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE doctor_appointments ENABLE ROW LEVEL SECURITY;
ALTER TABLE emergency_contacts ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;

-- Helper RLS Policies (Elderly can see and manage their own data; authorized members can see according to permissions)
CREATE POLICY "Users can view own profile" ON profiles
    FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Elderly can view own healthcare profile" ON healthcare_profiles
    FOR SELECT USING (auth.uid() = elderly_id);

CREATE POLICY "Authorized family and caregivers can view healthcare profile" ON healthcare_profiles
    FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM family_connections fc
            WHERE fc.elderly_id = healthcare_profiles.elderly_id
            AND fc.member_id = auth.uid()
            AND fc.status = 'approved'
            AND (fc.permissions->>'canViewProfile')::boolean = true
        )
    );
